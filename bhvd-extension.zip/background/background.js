// NORM — Background Service Worker

var API_URL = "https://bhvd-signal-api.fly.dev";

var tabResults = {};
var tabStates = {};

// ── Auth token helpers ────────────────────────────────────────
function getToken() {
  return new Promise(function(resolve) {
    chrome.storage.local.get('bhvd_token', function(r) {
      resolve(r.bhvd_token || null);
    });
  });
}

function authHeaders(token) {
  var h = { 'Content-Type': 'application/json' };
  if (token) h['Authorization'] = 'Bearer ' + token;
  return h;
}

function getUserTierCached() {
  return new Promise(function(resolve) {
    chrome.storage.local.get(['bhvd_token', 'bhvd_tier', 'bhvd_tier_ts'], function(r) {
      var tok = r.bhvd_token;
      var tier = r.bhvd_tier || 'free';
      var ts = r.bhvd_tier_ts || 0;
      // Cache tier for 5 minutes
      if (!tok) { resolve('free'); return; }
      if (Date.now() - ts < 5 * 60 * 1000) { resolve(tier); return; }
      fetch(API_URL + '/api/stripe/subscription', {
        headers: { 'Authorization': 'Bearer ' + tok }
      })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        var t = (d && d.data && d.data.tier) || 'free';
        chrome.storage.local.set({ bhvd_tier: t, bhvd_tier_ts: Date.now() });
        resolve(t);
      })
      .catch(function() { resolve(tier); });
    });
  });
}

// Leaderboard index: domain → entry. Refreshed once per session.
var _lbIndex = null;
var _lbIndexPromise = null;

function getLbIndex() {
  if (_lbIndex) return Promise.resolve(_lbIndex);
  if (_lbIndexPromise) return _lbIndexPromise;
  _lbIndexPromise = fetch(API_URL + "/api/leaderboard/all?limit=500&offset=0")
    .then(function(r) { return r.json(); })
    .then(function(d) {
      _lbIndex = {};
      var entries = d && d.data && Array.isArray(d.data.entries) ? d.data.entries : [];
      entries.forEach(function(e) { if (e.domain) _lbIndex[e.domain] = e; });
      return _lbIndex;
    })
    .catch(function() { _lbIndex = {}; return _lbIndex; });
  return _lbIndexPromise;
}

// Merge leaderboard entry into a lookup result.
// Leaderboard entries come from the seeder pipeline and have the full leaderboard_data.
// Always prefer the leaderboard record's leaderboard_data — it is the authoritative scored record.
function mergeLeaderboardScore(data) {
  if (!data || !data.domain) return data;
  var domain = data.domain.replace(/^www\./, "");
  if (!_lbIndex) return data;
  var lbEntry = _lbIndex[domain] || _lbIndex["www." + domain];
  if (!lbEntry) return data;
  var lbLd = lbEntry.leaderboard_data || {};
  if (!lbLd.total_score) return data;  // no scored leaderboard entry
  data = JSON.parse(JSON.stringify(data));
  // Full merge: leaderboard_data wins on every field it has (it's the seeder record)
  data.leaderboard_data = Object.assign({}, data.leaderboard_data || {}, lbLd);
  data.signal_color = lbEntry.signal_color || data.signal_color;
  return data;
}

// Strip the fat from the full API response before passing through chrome messaging.
// The full lookup response can be 5-6MB; the sidebar only needs ~10KB of it.
function slimForSidebar(full) {
  if (!full || !full.data) return full;
  var d = full.data;
  var ld = d.leaderboard_data || {};
  var evidLen = Array.isArray(ld.extraction_evidence) ? ld.extraction_evidence.length : 0;
  return {
    success: full.success,
    status: full.status,
    data: {
      page_id: d.page_id,
      url: d.url,
      canonical_url: d.canonical_url,
      domain: d.domain,
      brand_name: d.brand_name,
      product_name: d.product_name,
      category: d.category,
      signal_color: d.signal_color,
      claim_support_risk: d.claim_support_risk,
      confidence: d.confidence,
      dimension_scores: d.dimension_scores,
      is_provisional: d.is_provisional,
      scan_status: d.scan_status,
      tab_state: d.tab_state,
      consumer_summary: d.consumer_summary,
      last_scanned_at: d.last_scanned_at,
      last_verified: d.last_verified,
      date_scanned: d.date_scanned,
      verdict_label: d.verdict_label,
      rank_number: d.rank_number,
      rank_total: d.rank_total,
      category_standing: d.category_standing,
      category_percentile: d.category_percentile,
      category_standing_band: d.category_standing_band,
      category_peer_count: d.category_peer_count,
      why_flagged_top_reasons: d.why_flagged_top_reasons,
      evidence_snapshot: d.evidence_snapshot,
      leaderboard_data: {
        total_score: ld.total_score,
        signal_color: ld.signal_color,
        gap_map: ld.gap_map,
        why_this_verdict: ld.why_this_verdict,
        data_integrity: ld.data_integrity,
        data_visibility: ld.data_visibility,
        visibility_index: ld.visibility_index,
        capture_method: ld.capture_method,
        reviewed_at: ld.reviewed_at,
        model_used: ld.model_used,
        escalated: ld.escalated,
        extraction_evidence: new Array(evidLen),
        extraction_claim_count: ld.extraction_claim_count,
        limitations: ld.limitations,
        strengths: ld.strengths,
        scrape_status: ld.scrape_status,
      }
    }
  };
}

console.log("[BHVD Background] Service worker started");

function getIconPath(state) {
  var s = (state === "red" || state === "yellow" || state === "green" || state === "scanning") ? state : "dormant";
  return {
    "16":  "icons/" + s + "16.png",
    "32":  "icons/" + s + "32.png",
    "48":  "icons/" + s + "48.png",
    "128": "icons/" + s + "128.png"
  };
}

function setIcon(tabId, state) {
  tabStates[tabId] = state;
  chrome.action.setIcon({ tabId: tabId, path: getIconPath(state) }).catch(function(){});
}

function isWellness(url) {
  var wellness = ["supplement","vitamin","protein","collagen","skincare","serum",
    "moisturizer","retinol","fitness","workout","sleep","recovery","wearable",
    "tracker","probiotic","omega","magnesium","whey","nootropic","adaptogen",
    "mushroom","greens","electrolyte","infrared","sauna","massage","pemf",
    "ag1.com","ritual.com","thorne.com","onnit.com","whoop.com","ouraring.com",
    "joovv.com","therabody.com","hyperice.com","neurohacker.com","eightsleep.com",
    "momentouslabs.com","bulletproof.com","foursigmatic.com","higherdose.com",
    "blueprint.bryanjohnson.com","bryanjohnson.co"];
  var u = url.toLowerCase();
  for (var i = 0; i < wellness.length; i++) {
    if (u.indexOf(wellness[i]) !== -1) return true;
  }
  return false;
}

function doScan(tabId, msg) {
  var url = msg.url || "";
  if (!isWellness(url)) {
    console.log("[BHVD] Not wellness:", url);
    return;
  }

  console.log("[BHVD] Scanning:", url);
  setIcon(tabId, "scanning");

  // Send scanning state to sidebar
  chrome.tabs.sendMessage(tabId, { type: "BHVD_SCANNING" }).catch(function(){});

  // Clear any cached provisional result so we get the latest from API
  delete tabResults[tabId];

  // Pre-fetch leaderboard index (no-op if already cached), then lookup with auth token
  Promise.all([getLbIndex(), getToken()]).then(function(results) {
    var token = results[1];
    var hdrs = token ? { 'Authorization': 'Bearer ' + token } : {};
    return fetch(API_URL + "/api/lookup?url=" + encodeURIComponent(url), { headers: hdrs });
  })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d.status === "found" && d.data) {
        handleResult(tabId, mergeLeaderboardScore(d.data));
      } else {
        // Queue and do provisional scan
        fetch(API_URL + "/api/scan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            url: url,
            page_text: msg.pageText || "",
            claims: msg.claims || [],
            evidence: msg.evidence || [],
            product_info: msg.productInfo || {}
          })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
          if (d.success && d.data) {
            handleResult(tabId, d.data);
          } else {
            setIcon(tabId, "dormant");
          }
        })
        .catch(function(e) {
          console.log("[BHVD] Scan error:", e);
          setIcon(tabId, "dormant");
        });
      }
    })
    .catch(function(e) {
      console.log("[BHVD] Lookup error:", e);
      setIcon(tabId, "dormant");
    });
}

function handleResult(tabId, data) {
  tabResults[tabId] = data;
  var sig = data.signal_color || "dormant";
  setIcon(tabId, sig);
  console.log("[BHVD] Result:", sig, data.claim_support_risk);
  chrome.tabs.sendMessage(tabId, { type: "BHVD_RESULT", result: data }).catch(function(){});
}

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  console.log("[BHVD] Message received:", msg && msg.type);
  var tabId = sender.tab ? sender.tab.id : null;

  if (msg.type === "PAGE_CONTENT" && tabId) {
    doScan(tabId, msg);
    return false;
  }

  if (msg.type === "GET_RESULT") {
    sendResponse({ result: tabResults[msg.tabId], state: tabStates[msg.tabId] || "dormant" });
    return true;
  }

  if (msg.type === "GET_SIDEBAR_STATE") {
    var tid = sender.tab ? sender.tab.id : null;
    sendResponse({ result: tabResults[tid], state: tabStates[tid] || "dormant" });
    return true;
  }

  if (msg.type === "LOOKUP_URL") {
    var lookupTarget = msg.url;
    console.log("[BHVD] LOOKUP_URL for:", lookupTarget);
    fetch(API_URL + "/api/lookup?slim=true&url=" + encodeURIComponent(lookupTarget))
      .then(function(r) { return r.json(); })
      .then(function(d) {
        console.log("[BHVD] Lookup result:", d && d.status, d && d.data && d.data.signal_color);
        sendResponse(d);
        if (d && d.status === "found" && d.data && tabId) {
          tabResults[tabId] = d.data;
          setIcon(tabId, d.data.signal_color || "dormant");
        }
      })
      .catch(function(e) {
        console.log("[BHVD] Lookup fetch error:", e);
        sendResponse(null);
      });
    return true;
  }

  if (msg.type === "GET_LEADERBOARD") {
    fetch(API_URL + "/api/leaderboard/" + msg.category + "?limit=50")
      .then(function(r) { return r.json(); })
      .then(function(d) { sendResponse({ success: true, data: d.data }); })
      .catch(function(e) { sendResponse({ success: false, error: e.message }); });
    return true;
  }

  if (msg.type === "SCAN_URL") {
    fetch(API_URL + "/api/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(msg.payload)
    })
      .then(function(r) { return r.json(); })
      .then(function(d) { sendResponse(d); })
      .catch(function(e) { sendResponse(null); });
    return true;
  }

  if (msg.type === "QUEUE_URL") {
    fetch(API_URL + "/api/queue", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: msg.url })
    })
      .then(function(r) { return r.json(); })
      .then(function(d) { sendResponse(d); })
      .catch(function() { sendResponse(null); });
    return true;
  }

  // DOM capture — extension sends rendered page text when crawler can't access site
  if (msg.type === "DOM_CAPTURE") {
    console.log("[BHVD] DOM_CAPTURE for:", msg.url, "— chars:", msg.dom_text && msg.dom_text.length);
    fetch(API_URL + "/api/dom-capture", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: msg.url, dom_text: msg.dom_text })
    })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        sendResponse(d);
        if (d && d.data && tabId) {
          tabResults[tabId] = d.data;
          setIcon(tabId, d.data.signal_color || "scanning");
        }
      })
      .catch(function(e) {
        console.log("[BHVD] DOM capture error:", e);
        sendResponse(null);
      });
    return true;
  }
});

chrome.tabs.onRemoved.addListener(function(tabId) {
  delete tabResults[tabId];
  delete tabStates[tabId];
});

chrome.tabs.onUpdated.addListener(function(tabId, info) {
  if (info.status === "loading") {
    delete tabResults[tabId];
    setIcon(tabId, "dormant");
  }
});

console.log("[BHVD Background] Ready");
