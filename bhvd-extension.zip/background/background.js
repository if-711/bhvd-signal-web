// NORM by BHVD — Background Service Worker

var API_URL = "https://bhvd-signal-api.fly.dev";

var tabResults = {};
var tabStates = {};

console.log("[BHVD Background] Service worker started");

function getIconPath(state) {
  var s = (state === "red" || state === "yellow" || state === "green" || state === "scanning") ? state : "dormant";
  return {
    "16":  "icons/" + s + "16.png",
    "32":  "icons/" + s + "32.png",
    "48":  "icons/" + s + "48.png",
    "128": "icons/" + s + "128.png"
  };
}

function setIcon(tabId, state) {
  tabStates[tabId] = state;
  chrome.action.setIcon({ tabId: tabId, path: getIconPath(state) }).catch(function(){});
}

function isWellness(url) {
  var wellness = ["supplement","vitamin","protein","collagen","skincare","serum",
    "moisturizer","retinol","fitness","workout","sleep","recovery","wearable",
    "tracker","probiotic","omega","magnesium","whey","nootropic","adaptogen",
    "mushroom","greens","electrolyte","infrared","sauna","massage","pemf",
    "ag1.com","ritual.com","thorne.com","onnit.com","whoop.com","ouraring.com",
    "joovv.com","therabody.com","hyperice.com","neurohacker.com","eightsleep.com",
    "momentouslabs.com","bulletproof.com","foursigmatic.com","higherdose.com"];
  var u = url.toLowerCase();
  for (var i = 0; i < wellness.length; i++) {
    if (u.indexOf(wellness[i]) !== -1) return true;
  }
  return false;
}

function extractDomain(url) {
  try { return new URL(url).hostname.replace(/^www\./, ""); } catch(e) { return null; }
}

// Pick the highest-scored public_safe product from a products array.
// Prefer reviewed products (any data_integrity) — sidebar handles display gating.
function bestProduct(products) {
  if (!products || !products.length) return null;
  var safe = products.filter(function(p) {
    return (p.leaderboard_data || {}).public_safe === true;
  });
  var pool = safe.length ? safe : products;
  // Any reviewed product is a valid candidate — don't filter by data_integrity here
  var reviewed = pool.filter(function(p) {
    var ld = p.leaderboard_data || {};
    return ld.review_status === "reviewed";
  });
  var candidates = reviewed.length ? reviewed : pool;
  return candidates.reduce(function(best, cur) {
    var bld = best.leaderboard_data || {};
    var cld = cur.leaderboard_data || {};
    var bs = bld.total_score != null ? bld.total_score : (100 - (best.claim_support_risk || 50));
    var cs = cld.total_score != null ? cld.total_score : (100 - (cur.claim_support_risk || 50));
    return cs > bs ? cur : best;
  }, candidates[0]);
}

// Domain endpoint → resolves with best-scored product, rejects if nothing found
function domainLookup(url) {
  var domain = extractDomain(url);
  if (!domain) return Promise.reject("no domain");
  return fetch(API_URL + "/api/domain/" + encodeURIComponent(domain))
    .then(function(r) { return r.json(); })
    .then(function(d) {
      var products = (d.data || {}).products || [];
      var best = bestProduct(products);
      if (best) return best;
      return Promise.reject("no products");
    });
}

function doScan(tabId, msg) {
  var url = msg.url || "";
  if (!isWellness(url)) {
    console.log("[BHVD] Not wellness:", url);
    return;
  }

  console.log("[BHVD] Scanning:", url);
  setIcon(tabId, "scanning");
  chrome.tabs.sendMessage(tabId, { type: "BHVD_SCANNING" }).catch(function(){});
  delete tabResults[tabId];

  // Domain lookup first — always returns the best-scored product for the brand
  domainLookup(url)
    .then(function(product) {
      console.log("[BHVD] Domain hit:", product.signal_color, product.claim_support_risk);
      handleResult(tabId, product);
    })
    .catch(function() {
      // Fall back to exact-URL lookup
      fetch(API_URL + "/api/lookup?url=" + encodeURIComponent(url))
        .then(function(r) { return r.json(); })
        .then(function(d) {
          if (d.status === "found" && d.data) {
            handleResult(tabId, d.data);
          } else {
            // Nothing stored — do a live scan
            fetch(API_URL + "/api/scan", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                url: url,
                page_text: msg.pageText || "",
                claims: msg.claims || [],
                evidence: msg.evidence || [],
                product_info: msg.productInfo || {}
              })
            })
            .then(function(r) { return r.json(); })
            .then(function(d) {
              if (d.success && d.data) {
                handleResult(tabId, d.data);
              } else {
                setIcon(tabId, "dormant");
              }
            })
            .catch(function(e) {
              console.log("[BHVD] Scan error:", e);
              setIcon(tabId, "dormant");
            });
          }
        })
        .catch(function(e) {
          console.log("[BHVD] Lookup error:", e);
          setIcon(tabId, "dormant");
        });
    });
}

function handleResult(tabId, data) {
  tabResults[tabId] = data;
  var sig = data.signal_color || "dormant";
  setIcon(tabId, sig);
  console.log("[BHVD] Result:", sig, data.claim_support_risk);
  chrome.tabs.sendMessage(tabId, { type: "BHVD_RESULT", result: data }).catch(function(){});
}

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  console.log("[BHVD] Message received:", msg && msg.type);
  var tabId = sender.tab ? sender.tab.id : null;

  if (msg.type === "PAGE_CONTENT" && tabId) {
    doScan(tabId, msg);
    return false;
  }

  if (msg.type === "GET_RESULT") {
    sendResponse({ result: tabResults[msg.tabId], state: tabStates[msg.tabId] || "dormant" });
    return true;
  }

  if (msg.type === "GET_SIDEBAR_STATE") {
    var tid = sender.tab ? sender.tab.id : null;
    sendResponse({ result: tabResults[tid], state: tabStates[tid] || "dormant" });
    return true;
  }

  if (msg.type === "LOOKUP_URL") {
    var lookupTarget = msg.url;
    console.log("[BHVD] LOOKUP_URL for:", lookupTarget);
    domainLookup(lookupTarget)
      .then(function(product) {
        console.log("[BHVD] LOOKUP_URL domain hit:", product.signal_color);
        sendResponse({ status: "found", data: product });
        if (tabId) {
          tabResults[tabId] = product;
          setIcon(tabId, product.signal_color || "dormant");
        }
      })
      .catch(function() {
        fetch(API_URL + "/api/lookup?url=" + encodeURIComponent(lookupTarget))
          .then(function(r) { return r.json(); })
          .then(function(d) {
            console.log("[BHVD] LOOKUP_URL fallback:", d && d.status, d && d.data && d.data.signal_color);
            sendResponse(d);
            if (d.status === "found" && d.data && tabId) {
              tabResults[tabId] = d.data;
              setIcon(tabId, d.data.signal_color || "dormant");
            }
          })
          .catch(function(e) {
            console.log("[BHVD] Lookup fetch error:", e);
            sendResponse(null);
          });
      });
    return true;
  }

  if (msg.type === "GET_LEADERBOARD") {
    fetch(API_URL + "/api/leaderboard/" + msg.category + "?limit=50")
      .then(function(r) { return r.json(); })
      .then(function(d) { sendResponse({ success: true, data: d.data }); })
      .catch(function(e) { sendResponse({ success: false, error: e.message }); });
    return true;
  }

  if (msg.type === "SCAN_URL") {
    fetch(API_URL + "/api/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(msg.payload)
    })
      .then(function(r) { return r.json(); })
      .then(function(d) { sendResponse(d); })
      .catch(function(e) { sendResponse(null); });
    return true;
  }

  if (msg.type === "QUEUE_URL") {
    fetch(API_URL + "/api/queue", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: msg.url })
    })
      .then(function(r) { return r.json(); })
      .then(function(d) { sendResponse(d); })
      .catch(function() { sendResponse(null); });
    return true;
  }

  if (msg.type === "DOM_CAPTURE") {
    console.log("[BHVD] DOM_CAPTURE for:", msg.url, "— chars:", msg.dom_text && msg.dom_text.length);
    fetch(API_URL + "/api/dom-capture", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: msg.url, dom_text: msg.dom_text })
    })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        sendResponse(d);
        if (d && d.data && tabId) {
          tabResults[tabId] = d.data;
          setIcon(tabId, d.data.signal_color || "scanning");
        }
      })
      .catch(function(e) {
        console.log("[BHVD] DOM capture error:", e);
        sendResponse(null);
      });
    return true;
  }
});

chrome.tabs.onRemoved.addListener(function(tabId) {
  delete tabResults[tabId];
  delete tabStates[tabId];
});

chrome.tabs.onUpdated.addListener(function(tabId, info) {
  if (info.status === "loading") {
    delete tabResults[tabId];
    setIcon(tabId, "dormant");
  }
});

console.log("[BHVD Background] Ready");
