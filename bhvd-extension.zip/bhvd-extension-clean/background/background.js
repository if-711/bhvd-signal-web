// NORM by BHVD — Background Service Worker

var API_URL = "https://bhvd-signal-api.fly.dev";

// ── Auth ────────────────────────────────────────────────────
var SB_URL  = 'https://klhhkjmvxxsmfxpuzfhj.supabase.co';
var SB_KEY  = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtsaGhram12eHhzbWZ4cHV6ZmhqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzcwNTI3NDMsImV4cCI6MjA5MjYyODc0M30.4gIkTBDMaNKemtVIWeQCvaIo4iJIDyh_ztByTlM7bg8';

function getStoredSession() {
  return new Promise(function(resolve) {
    chrome.storage.local.get(['norm_session'], function(r) { resolve(r.norm_session || null); });
  });
}
function saveSession(s) {
  return new Promise(function(resolve) { chrome.storage.local.set({ norm_session: s }, resolve); });
}
function clearSession() {
  return new Promise(function(resolve) { chrome.storage.local.remove(['norm_session'], resolve); });
}
function refreshSession(rt) {
  return fetch(SB_URL + '/auth/v1/token?grant_type=refresh_token', {
    method: 'POST',
    headers: { 'apikey': SB_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ refresh_token: rt })
  }).then(function(r) { return r.json(); }).then(function(d) {
    if (!d.access_token) return null;
    var s = { access_token: d.access_token, refresh_token: d.refresh_token || rt,
              expires_at: Date.now() + ((d.expires_in || 3600) * 1000), user: d.user };
    saveSession(s);
    return s;
  }).catch(function() { return null; });
}
function getValidToken() {
  return getStoredSession().then(function(s) {
    if (!s) return null;
    if (s.expires_at && Date.now() > s.expires_at - 300000) return refreshSession(s.refresh_token);
    return s;
  }).then(function(s) { return s ? s.access_token : null; });
}

var tabResults = {};
var tabStates = {};
var consumerReportCache = {}; // domain → { data, ts }
var CONSUMER_REPORT_TTL = 5 * 60 * 1000; // 5 minutes

console.log("[BHVD Background] Service worker started");

function getIconPath(state) {
  var s = (state === "red" || state === "yellow" || state === "green" || state === "scanning") ? state : "dormant";
  return {
    "16":  "icons/" + s + "16.png",
    "32":  "icons/" + s + "32.png",
    "48":  "icons/" + s + "48.png",
    "128": "icons/" + s + "128.png"
  };
}

function setIcon(tabId, state) {
  tabStates[tabId] = state;
  chrome.action.setIcon({ tabId: tabId, path: getIconPath(state) }).catch(function(){});
}

function isWellness(url) {
  var wellness = ["supplement","vitamin","protein","collagen","skincare","serum",
    "moisturizer","retinol","fitness","workout","sleep","recovery","wearable",
    "tracker","probiotic","omega","magnesium","whey","nootropic","adaptogen",
    "mushroom","greens","electrolyte","infrared","sauna","massage","pemf",
    "ag1.com","ritual.com","thorne.com","onnit.com","whoop.com","ouraring.com",
    "joovv.com","therabody.com","hyperice.com","neurohacker.com","eightsleep.com",
    "momentouslabs.com","bulletproof.com","foursigmatic.com","higherdose.com"];
  var u = url.toLowerCase();
  for (var i = 0; i < wellness.length; i++) {
    if (u.indexOf(wellness[i]) !== -1) return true;
  }
  return false;
}

function extractDomain(url) {
  try { return new URL(url).hostname.replace(/^www\./, ""); } catch(e) { return null; }
}

// Pick the highest-scored public_safe product from a products array.
// Prefer reviewed products (any data_integrity) — sidebar handles display gating.
function bestProduct(products) {
  if (!products || !products.length) return null;
  var safe = products.filter(function(p) {
    return (p.leaderboard_data || {}).public_safe === true;
  });
  var pool = safe.length ? safe : products;
  // Any reviewed product is a valid candidate — don't filter by data_integrity here
  var reviewed = pool.filter(function(p) {
    var ld = p.leaderboard_data || {};
    return ld.review_status === "reviewed" || ld.review_status === "seeder_reviewed";
  });
  var candidates = reviewed.length ? reviewed : pool;
  return candidates.reduce(function(best, cur) {
    var bld = best.leaderboard_data || {};
    var cld = cur.leaderboard_data || {};
    var bs = bld.total_score != null ? bld.total_score : (100 - (best.claim_support_risk || 50));
    var cs = cld.total_score != null ? cld.total_score : (100 - (cur.claim_support_risk || 50));
    return cs > bs ? cur : best;
  }, candidates[0]);
}

// Domain endpoint → resolves with best-scored product, rejects if nothing found
function domainLookup(url) {
  var domain = extractDomain(url);
  if (!domain) return Promise.reject("no domain");
  return getValidToken().then(function(token) {
    var hdrs = {};
    if (token) hdrs['x-consumer-key'] = token;
    return fetch(API_URL + "/api/domain/" + encodeURIComponent(domain), { headers: hdrs });
  }).then(function(r) { return r.json(); }).then(function(d) {
    if (!d || !d.success || !d.data) return Promise.reject("no data");
    var data = d.data || {};

    // API returns a flat brand object (signal, score, verdict, dimensions…) — use it directly
    var merged = Object.assign({}, data);

    // Normalise signal_color — API uses "signal", extension checks signal_color
    if (!merged.signal_color && merged.signal) merged.signal_color = merged.signal;

    if (!merged.signal_color) return Promise.reject("no signal");

    // Build dimension_scores from dimensions array
    if (!merged.dimension_scores || !Object.keys(merged.dimension_scores).length) {
      var dims = {};
      (data.dimensions || []).forEach(function(dim) { if (dim.name) dims[dim.name] = dim.score || 0; });
      if (Object.keys(dims).length) merged.dimension_scores = dims;
    }

    // Synthesize leaderboard_data so sidebar integrity/review checks pass
    var existingLd = merged.leaderboard_data || {};
    merged.leaderboard_data = Object.assign({
      total_score:    merged.score,
      review_status:  "reviewed",
      public_safe:    true,
      data_integrity: "high",
      bhvd_verdict:   merged.verdict,
      why_this_verdict: merged.summary || merged.consumer_summary || null,
    }, existingLd);

    return merged;
  });
}

function doScan(tabId, msg) {
  var url = msg.url || "";
  if (!isWellness(url)) {
    console.log("[BHVD] Not wellness:", url);
    return;
  }

  console.log("[BHVD] Scanning:", url);
  setIcon(tabId, "scanning");
  chrome.tabs.sendMessage(tabId, { type: "BHVD_SCANNING" }).catch(function(){});
  delete tabResults[tabId];

  // Domain lookup first — always returns the best-scored product for the brand
  domainLookup(url)
    .then(function(product) {
      console.log("[BHVD] Domain hit:", product.signal_color, product.claim_support_risk);
      handleResult(tabId, product);
    })
    .catch(function() {
      // Brand not in DB — show dormant, do not trigger live scan
      setIcon(tabId, "dormant");
      return;
      // Unreachable fallback kept for reference only
      fetch(API_URL + "/api/lookup?url=" + encodeURIComponent(url))
        .then(function(r) { return r.json(); })
        .then(function(d) {
          if (d.status === "found" && d.data) {
            handleResult(tabId, d.data);
          } else {
            setIcon(tabId, "dormant");
          }
        })
        .catch(function(e) {
          console.log("[BHVD] Lookup error:", e);
          setIcon(tabId, "dormant");
        });
    });
}

function handleResult(tabId, data) {
  tabResults[tabId] = data;
  var sig = data.signal_color || "dormant";
  setIcon(tabId, sig);
  console.log("[BHVD] Result:", sig, data.claim_support_risk);
  chrome.tabs.sendMessage(tabId, { type: "BHVD_RESULT", result: data }).catch(function(){});
}

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  console.log("[BHVD] Message received:", msg && msg.type);
  var tabId = sender.tab ? sender.tab.id : null;

  if (msg.type === "PAGE_CONTENT" && tabId) {
    doScan(tabId, msg);
    return false;
  }

  if (msg.type === "GET_RESULT") {
    sendResponse({ result: tabResults[msg.tabId], state: tabStates[msg.tabId] || "dormant" });
    return true;
  }

  if (msg.type === "GET_SIDEBAR_STATE") {
    var tid = sender.tab ? sender.tab.id : null;
    sendResponse({ result: tabResults[tid], state: tabStates[tid] || "dormant" });
    return true;
  }

  if (msg.type === "LOOKUP_URL") {
    var lookupTarget = msg.url;
    console.log("[BHVD] LOOKUP_URL for:", lookupTarget);
    domainLookup(lookupTarget)
      .then(function(product) {
        console.log("[BHVD] LOOKUP_URL domain hit:", product.signal_color);
        sendResponse({ status: "found", data: product });
        if (tabId) {
          tabResults[tabId] = product;
          setIcon(tabId, product.signal_color || "dormant");
        }
      })
      .catch(function() {
        fetch(API_URL + "/api/lookup?url=" + encodeURIComponent(lookupTarget))
          .then(function(r) { return r.json(); })
          .then(function(d) {
            console.log("[BHVD] LOOKUP_URL fallback:", d && d.status, d && d.data && d.data.signal_color);
            sendResponse(d);
            if (d.status === "found" && d.data && tabId) {
              tabResults[tabId] = d.data;
              setIcon(tabId, d.data.signal_color || "dormant");
            }
          })
          .catch(function(e) {
            console.log("[BHVD] Lookup fetch error:", e);
            sendResponse(null);
          });
      });
    return true;
  }

  if (msg.type === "GET_LEADERBOARD") {
    fetch(API_URL + "/api/leaderboard/" + msg.category + "?limit=50")
      .then(function(r) { return r.json(); })
      .then(function(d) { sendResponse({ success: true, data: d.data }); })
      .catch(function(e) { sendResponse({ success: false, error: e.message }); });
    return true;
  }

  if (msg.type === "SCAN_URL") {
    fetch(API_URL + "/api/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(msg.payload)
    })
      .then(function(r) { return r.json(); })
      .then(function(d) { sendResponse(d); })
      .catch(function(e) { sendResponse(null); });
    return true;
  }

  if (msg.type === "QUEUE_URL") {
    fetch(API_URL + "/api/queue", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: msg.url })
    })
      .then(function(r) { return r.json(); })
      .then(function(d) { sendResponse(d); })
      .catch(function() { sendResponse(null); });
    return true;
  }

  if (msg.type === "DOM_CAPTURE") {
    console.log("[BHVD] DOM_CAPTURE for:", msg.url, "— chars:", msg.dom_text && msg.dom_text.length);
    fetch(API_URL + "/api/dom-capture", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: msg.url, dom_text: msg.dom_text })
    })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        sendResponse(d);
        if (d && d.data && tabId) {
          tabResults[tabId] = d.data;
          setIcon(tabId, d.data.signal_color || "scanning");
        }
      })
      .catch(function(e) {
        console.log("[BHVD] DOM capture error:", e);
        sendResponse(null);
      });
    return true;
  }

  if (msg.type === 'SAVE_SESSION') {
    saveSession(msg.session).then(function() { sendResponse({ ok: true }); });
    return true;
  }

  if (msg.type === 'CLEAR_SESSION') {
    clearSession().then(function() { sendResponse({ ok: true }); });
    return true;
  }

  if (msg.type === 'GET_SESSION') {
    getStoredSession().then(function(s) { sendResponse({ session: s }); });
    return true;
  }

  if (msg.type === 'FETCH_TIER') {
    getValidToken().then(function(token) {
      if (!token) { sendResponse({ tier: 'free', scansRemaining: null }); return; }
      fetch(API_URL + '/api/stripe/subscription', {
        headers: { 'Authorization': 'Bearer ' + token }
      }).then(function(r) { return r.json(); })
        .then(function(d) { sendResponse({ tier: (d.data || {}).tier || 'free', scansRemaining: (d.data || {}).scansRemaining ?? null }); })
        .catch(function() { sendResponse({ tier: 'free', scansRemaining: null }); });
    });
    return true;
  }

  if (msg.type === 'FETCH_CONSUMER_REPORT') {
    var cached = consumerReportCache[msg.domain];
    if (cached && (Date.now() - cached.ts) < CONSUMER_REPORT_TTL) {
      sendResponse(cached.data);
      return true;
    }
    getValidToken().then(function(token) {
      if (!token) { sendResponse(null); return; }
      fetch(API_URL + '/api/report/consumer/' + encodeURIComponent(msg.domain), {
        headers: { 'x-consumer-key': token }
      }).then(function(r) { return r.json(); })
        .then(function(d) {
          consumerReportCache[msg.domain] = { data: d, ts: Date.now() };
          sendResponse(d);
        })
        .catch(function() { sendResponse(null); });
    });
    return true;
  }
});

chrome.tabs.onRemoved.addListener(function(tabId) {
  delete tabResults[tabId];
  delete tabStates[tabId];
});

chrome.tabs.onUpdated.addListener(function(tabId, info) {
  if (info.status === "loading") {
    delete tabResults[tabId];
    setIcon(tabId, "dormant");
  }
});

console.log("[BHVD Background] Ready");
