// BHVD Signal — Injected Sidebar v4
// Redesigned: score front-and-center, dimension bars, evidence metrics, verdict badge

(function () {
  "use strict";
  if (document.getElementById("bhvd-signal-sidebar")) return;

  var API_URL = "https://bhvd-signal-api.fly.dev";

  function logDemandEvent(domain, eventType) {
    if (!domain) return;
    fetch(API_URL + "/api/demand/event", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ domain: domain, event_type: eventType }),
    }).catch(function() {});
  }

  var KNOWN_DOMAINS = [
    "ag1.com","ritual.com","thorne.com","onnit.com","whoop.com","ouraring.com",
    "joovv.com","therabody.com","hyperice.com","neurohacker.com","eightsleep.com",
    "momentouslabs.com","bulletproof.com","foursigmatic.com","higherdose.com",
    "mindbodygreen.com","goop.com","hims.com","hers.com","ro.co","hone.health",
    "athletic-greens.com","drinkag1.com","levelshealth.com","insidetracker.com",
    "noom.com","garmin.com","fitbit.com","oura.com",
    // neurotech
    "elemindtech.com","elemind.com","neurosity.co","muse-eeg.com","choosemuse.com",
    "emotiv.com","brainco.tech","kernel.com","flowneuro.com","narbis.com",
    "trustedsource.com","halo.sport","humm.com","myndlift.com",
    // sleep & recovery / sound wellness
    "dreem.com","kokoon.com","bose.com","sleepme.com","chilisleep.com","ooler.com",
    "sleepnumber.com","casper.com","helix.com","saatva.com",
    "soundhealth.life","sonus.com","somnox.com","kokoon.com","soundcore.com",
    "yogasleep.com","endel.io","noisli.com",
    // additional supplement/wellness
    "rawgarden.com","momentous.com","pendulum.life","seed.com","ritual.com","care/of",
    "athletic-greens.com","ag1.com","organifi.com","sunwarrior.com","vitalproteins.com"
  ];

  function isKnownWellnessDomain() {
    var host = window.location.hostname.replace(/^www\./, "");
    for (var i = 0; i < KNOWN_DOMAINS.length; i++) {
      if (host === KNOWN_DOMAINS[i] || host.endsWith("." + KNOWN_DOMAINS[i])) return true;
    }
    return false;
  }

  var NORM_LOGO =
    '<circle cx="11" cy="8.5" r="5.5" stroke="currentColor" stroke-width="1.5" fill="none"/>' +
    '<circle cx="9.2" cy="7.8" r="1" fill="currentColor"/>' +
    '<circle cx="12.8" cy="7.8" r="1" fill="currentColor"/>' +
    '<path d="M9 10.5 Q11 12.5 13 10.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" fill="none"/>' +
    '<path d="M5.5 19 Q11 16 16.5 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none"/>';

  var SIG = {
    red:    { bg:"#120808", bd:"#5a1a1a", c:"#e74c3c", label:"Significant Evidence Gap",  verdict:"Marketing claims extend materially beyond the visible evidence base" },
    yellow: { bg:"#110e04", bd:"#5a3a0a", c:"#f39c12", label:"Moderate Evidence Gap",     verdict:"Some claims lack visible support"          },
    green:  { bg:"#060f08", bd:"#1a4a2a", c:"#27ae60", label:"Evidence Proportionate",    verdict:"Claims align with visible evidence"        },
  };

  // New verdict names — primary
  var VERDICT_COLOR = {
    "ALIGNED":"#27ae60","VALIDATED":"#2ecc71","GENERALLY ALIGNED":"#f39c12",
    "PARTIALLY ALIGNED":"#e67e22","OVEREXTENDED":"#e74c3c","EVIDENCE GAP":"#922b21",
    // Legacy backward compat for old DB records — remap to current names
    "INFLATED":"#e74c3c","HIGH CLAIM RISK":"#922b21",
    "REAL":"#27ae60","TIGHT":"#2ecc71","CREDIBLE":"#f39c12",
    "SOFT":"#e67e22","STRETCHED":"#e74c3c","HYPE":"#e74c3c","RED FLAG":"#922b21"
  };

  var VERDICT_LABEL = {
    "ALIGNED":"ALIGNED","VALIDATED":"VALIDATED","GENERALLY ALIGNED":"GENERALLY ALIGNED",
    "PARTIALLY ALIGNED":"PARTIALLY ALIGNED","OVEREXTENDED":"OVEREXTENDED","EVIDENCE GAP":"EVIDENCE GAP",
    // Legacy → display as current names
    "INFLATED":"OVEREXTENDED","HIGH CLAIM RISK":"EVIDENCE GAP",
    "REAL":"ALIGNED","TIGHT":"VALIDATED","CREDIBLE":"GENERALLY ALIGNED",
    "SOFT":"PARTIALLY ALIGNED","STRETCHED":"OVEREXTENDED","HYPE":"OVEREXTENDED","RED FLAG":"EVIDENCE GAP"
  };

  var STYLES = `
    #bhvd-signal-sidebar * { box-sizing:border-box; margin:0; padding:0; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; -webkit-font-smoothing:antialiased; }

    /* Tab — independently fixed so panel layout never affects its position */
    @keyframes bhvd-tab-in { from{opacity:0;transform:scale(0.7)} to{opacity:1;transform:scale(1)} }
    #bhvd-tab { position:fixed; right:24px; bottom:28px; z-index:2147483647; width:58px; height:58px; border-radius:50%; display:flex; align-items:center; justify-content:center; cursor:pointer; border:1px solid rgba(255,255,255,0.10); padding:0; box-shadow:0 8px 32px rgba(0,0,0,0.7); background:#07080e; transition:transform .15s ease; animation:bhvd-tab-in .4s cubic-bezier(.34,1.56,.64,1) both; }
    #bhvd-tab:hover { transform:scale(1.08); }
    #bhvd-tab-blob { flex-shrink:0; }
    #bhvd-blob-path { transition:fill .4s; fill:#1e2440; }
    #bhvd-tab-label { display:none; }

    /* Scanning pulse */
    @keyframes bhvd-pulse { 0%,100%{opacity:1} 50%{opacity:.2} }

    /* Glow animations */
    @keyframes bhvd-glow-dormant {
      0%,100% { filter: drop-shadow(0 0 3px rgba(42,48,100,0.3)); }
      50%      { filter: drop-shadow(0 0 9px rgba(58,66,130,0.7)); }
    }
    @keyframes bhvd-glow-red {
      0%,100% { filter: drop-shadow(0 0 4px rgba(231,76,60,0.35)); }
      50%      { filter: drop-shadow(0 0 16px rgba(231,76,60,1)) drop-shadow(0 0 5px rgba(231,76,60,0.6)); }
    }
    @keyframes bhvd-glow-yellow {
      0%,100% { filter: drop-shadow(0 0 4px rgba(243,156,18,0.35)); }
      50%      { filter: drop-shadow(0 0 16px rgba(243,156,18,1)) drop-shadow(0 0 5px rgba(243,156,18,0.6)); }
    }
    @keyframes bhvd-glow-green {
      0%,100% { filter: drop-shadow(0 0 4px rgba(39,174,96,0.35)); }
      50%      { filter: drop-shadow(0 0 16px rgba(39,174,96,1)) drop-shadow(0 0 5px rgba(39,174,96,0.6)); }
    }

    /* Hover card */
    #bhvd-hover-card { position:absolute; right:68px; bottom:0; background:#0d1022; border:1px solid rgba(255,255,255,0.1); border-radius:12px; padding:12px 15px; width:180px; display:none; pointer-events:none; box-shadow:-4px 4px 24px rgba(0,0,0,0.7); z-index:2147483648; }
    #bhvd-tab:hover #bhvd-hover-card { display:block; }
    .bhvd-hc-title { font-size:12px; font-weight:700; margin-bottom:4px; }
    .bhvd-hc-sub { font-size:10px; color:#7a82a0; line-height:1.45; }

    /* Panel — independently fixed, never affects tab position */
    @keyframes bhvd-panel-in { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
    #bhvd-panel { position:fixed; right:84px; bottom:96px; z-index:2147483646; width:0; overflow:hidden; transition:width .28s cubic-bezier(.22,1,.36,1); }
    #bhvd-panel.open { width:340px; animation:bhvd-panel-in .28s cubic-bezier(.22,1,.36,1) both; }
    #bhvd-panel-inner { width:340px; background:#07080e; border:1px solid rgba(255,255,255,0.07); border-radius:18px; overflow:hidden; max-height:86vh; overflow-y:auto; box-shadow:-8px 4px 40px rgba(0,0,0,0.8); }
    #bhvd-panel-inner::-webkit-scrollbar { width:2px; }
    #bhvd-panel-inner::-webkit-scrollbar-thumb { background:rgba(255,255,255,0.05); border-radius:2px; }

    /* Header */
    .bhvd-hdr { padding:10px 16px 10px 18px; display:flex; align-items:center; justify-content:space-between; border-bottom:1px solid rgba(255,255,255,0.05); background:rgba(4,5,12,0.97); backdrop-filter:blur(12px); position:sticky; top:0; z-index:2; }
    .bhvd-hdr-logo { display:flex; align-items:center; gap:9px; font-size:8.5px; font-weight:800; letter-spacing:.18em; color:#9ba3c0; font-family:monospace; text-transform:uppercase; }
    .bhvd-hdr-right { display:flex; align-items:center; gap:4px; }
    .bhvd-share-icon { background:none; border:none; color:#9ba3c0; cursor:pointer; padding:6px 7px; border-radius:7px; line-height:0; display:flex; align-items:center; justify-content:center; transition:all .15s; flex-shrink:0; }
    .bhvd-share-icon:hover { background:rgba(255,255,255,0.08); color:#e0e8ff; }
    .bhvd-close { background:none; border:none; color:#9ba3c0; font-size:18px; cursor:pointer; line-height:1; padding:6px 7px; border-radius:7px; transition:all .15s; }
    .bhvd-close:hover { color:#f0f4ff; background:rgba(255,255,255,0.08); }

    /* States */
    #bhvd-scanning { padding:48px 28px; text-align:center; display:none; }
    .bhvd-spin { width:26px; height:26px; border-radius:50%; border:2px solid rgba(255,255,255,0.05); border-top-color:#4a5272; animation:bhvd-spin .8s linear infinite; margin:0 auto 14px; }
    @keyframes bhvd-spin { to{transform:rotate(360deg)} }
    .bhvd-scan-txt { font-size:12.5px; color:#8892b0; font-weight:500; }
    .bhvd-scan-sub { font-size:10.5px; color:#8892b0; margin-top:5px; }
    #bhvd-unscored { padding:40px 28px; text-align:center; display:none; }
    .bhvd-us-icon { font-size:24px; margin-bottom:12px; color:#5a6280; }
    .bhvd-us-title { font-size:13.5px; font-weight:700; color:#d0d8f0; margin-bottom:7px; }
    .bhvd-us-body { font-size:11.5px; color:#8892b0; line-height:1.65; margin-bottom:16px; }
    .bhvd-snapshot-box { background:rgba(255,255,255,0.025); border:1px solid rgba(255,255,255,0.06); border-radius:10px; padding:14px 16px; margin:0 0 14px; text-align:left; }
    .bhvd-snapshot-row { display:flex; align-items:center; gap:10px; padding:3px 0; }
    .bhvd-snapshot-num { font-size:18px; font-weight:800; color:#c0c8e0; font-family:monospace; min-width:26px; }
    .bhvd-snapshot-lbl { font-size:10.5px; color:#7a82a0; }
    .bhvd-add-note { font-size:9.5px; color:#4a5272; line-height:1.65; border-top:1px solid rgba(255,255,255,0.05); padding-top:12px; margin-top:4px; }

    /* Unverifiable / limited / pending / suppressed states */
    #bhvd-unverifiable,#bhvd-limited-data,#bhvd-pending,#bhvd-suppressed { padding:40px 28px; text-align:center; display:none; }
    .bhvd-uv-icon { font-size:22px; margin-bottom:12px; color:#4a5272; }
    .bhvd-uv-title { font-size:13.5px; font-weight:700; color:#d0d8f0; margin-bottom:7px; }
    .bhvd-uv-body { font-size:11.5px; color:#8892b0; line-height:1.65; }
    .bhvd-uv-note { font-size:9.5px; color:#4a5272; margin-top:14px; line-height:1.6; border-top:1px solid rgba(255,255,255,0.05); padding-top:14px; }

    /* ── Result panel — single-view layout ── */
    #bhvd-result { display:none; }
    @keyframes bhvd-section-in { from{opacity:0;transform:translateY(5px)} to{opacity:1;transform:translateY(0)} }

    /* Hero: brand + score */
    .bhvd-r-hero { display:flex; align-items:flex-start; justify-content:space-between; padding:16px 18px 12px; gap:8px; }
    .bhvd-r-hero-left { flex:1; min-width:0; display:flex; flex-direction:column; justify-content:center; gap:7px; }
    .bhvd-r-brand { font-size:20px; font-weight:800; color:#f0f2ff; letter-spacing:-.025em; line-height:1.1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .bhvd-r-badge { display:inline-flex; align-items:center; gap:5px; padding:3px 9px 3px 6px; border-radius:20px; border:1px solid; font-size:8px; font-weight:900; letter-spacing:.11em; text-transform:uppercase; line-height:1; width:fit-content; }
    .bhvd-r-badge-dot { width:4px; height:4px; border-radius:50%; flex-shrink:0; }
    .bhvd-r-score-block { flex-shrink:0; text-align:right; display:flex; flex-direction:column; align-items:flex-end; justify-content:center; padding-top:2px; }
    .bhvd-r-score-num { font-size:42px; font-weight:900; font-family:monospace; line-height:1; letter-spacing:-.04em; display:block; }
    .bhvd-r-score-den { font-size:11px; font-weight:600; opacity:.25; font-family:monospace; margin-top:2px; }

    /* Ratio row */
    .bhvd-r-ratio-row { padding:0 18px 12px; }
    .bhvd-r-ratio { font-size:11px; color:#9ba3c0; letter-spacing:.01em; }
    .bhvd-r-ratio b { color:#d0d8f0; font-weight:700; }

    /* Divider */
    .bhvd-r-divider { height:1px; background:rgba(255,255,255,0.05); margin:0 18px; }

    /* Sentence */
    .bhvd-r-sentence { padding:13px 18px 15px; font-size:13px; color:#c0c8e0; line-height:1.65; border-bottom:1px solid rgba(255,255,255,0.05); }

    /* Claims section header */
    .bhvd-r-claims-hdr { display:flex; align-items:center; justify-content:space-between; padding:11px 18px 0; }
    .bhvd-r-claims-lbl { font-size:7.5px; font-weight:900; letter-spacing:.2em; color:#6a7298; text-transform:uppercase; }
    .bhvd-r-claims-count { font-size:9.5px; color:#9ba3c0; }

    /* Lock card */
    .bhvd-r-lock-wrap { position:relative; padding:10px 18px 16px; overflow:hidden; min-height:115px; }
    .bhvd-r-lock-overlay { position:absolute; inset:0; background:linear-gradient(to bottom,transparent 6%,rgba(7,8,14,0.95) 38%); display:flex; flex-direction:column; align-items:center; justify-content:flex-end; padding-bottom:18px; text-align:center; }
    .bhvd-r-lock-title { font-size:12.5px; font-weight:700; color:#d0d8f0; margin-bottom:5px; }
    .bhvd-r-lock-sub { font-size:10.5px; color:#9ba3c0; margin-bottom:12px; line-height:1.55; padding:0 24px; }
    .bhvd-r-lock-btn { font-size:11px; color:#4f7cff; background:transparent; border:1px solid rgba(79,124,255,.35); border-radius:7px; padding:8px 20px; cursor:pointer; font-family:inherit; font-weight:600; transition:all .15s; }
    .bhvd-r-lock-btn:hover { background:rgba(79,124,255,.1); border-color:rgba(79,124,255,.6); }

    /* Section label */
    .bhvd-sec-lbl { font-size:7.5px; font-weight:900; letter-spacing:.22em; color:#6a7298; text-transform:uppercase; margin-bottom:8px; }

    /* Top flag — redesigned */
    .bhvd-r-flag { padding:14px 18px 0; border-top:1px solid rgba(255,255,255,0.05); animation:bhvd-section-in .3s ease both; }
    .bhvd-r-flag-eyebrow { font-size:7.5px; font-weight:900; letter-spacing:.2em; text-transform:uppercase; color:#6a7298; margin-bottom:9px; display:flex; align-items:center; gap:8px; }
    .bhvd-r-flag-eyebrow::after { content:''; flex:1; height:1px; background:rgba(255,255,255,0.05); }
    .bhvd-r-flag-card { border-radius:10px; padding:12px 14px 11px; border-left:2px solid; background:rgba(255,255,255,0.03); }
    .bhvd-r-flag-quote { font-size:12px; color:#d0d8f0; line-height:1.55; margin-bottom:8px; font-weight:500; }
    .bhvd-r-flag-gap { font-size:10px; color:#9ba3c0; display:flex; align-items:center; gap:6px; line-height:1.4; }
    .bhvd-r-flag-gap-badge { font-size:8px; font-weight:900; letter-spacing:.06em; text-transform:uppercase; padding:2px 6px; border-radius:4px; flex-shrink:0; }
    /* Ghost claims — hint at more below */
    .bhvd-r-more-claims { position:relative; padding:8px 18px 0; }
    .bhvd-r-ghost-card { border-radius:9px; padding:9px 13px; border:1px solid rgba(255,255,255,0.05); background:rgba(255,255,255,0.02); margin-bottom:7px; display:flex; align-items:center; gap:8px; overflow:hidden; }
    .bhvd-r-ghost-card:nth-child(2) { opacity:0.45; }
    .bhvd-r-ghost-card:nth-child(3) { opacity:0.18; }
    .bhvd-r-ghost-dot { width:5px; height:5px; border-radius:50%; flex-shrink:0; }
    .bhvd-r-ghost-text { font-size:11px; color:#6a7298; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; font-style:italic; }
    .bhvd-r-more-fade { position:absolute; bottom:0; left:0; right:0; height:40px; background:linear-gradient(to bottom,transparent,#07080e); pointer-events:none; }

    /* Reasons */
    .bhvd-r-reasons { padding:14px 18px; border-top:1px solid rgba(255,255,255,0.05); animation:bhvd-section-in .35s ease both; }
    .bhvd-r-reason-row { display:flex; align-items:flex-start; gap:9px; margin-bottom:8px; }
    .bhvd-r-reason-row:last-child { margin-bottom:0; }
    .bhvd-r-reason-num { width:16px; height:16px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:7.5px; font-weight:900; flex-shrink:0; margin-top:2px; font-family:monospace; }
    .bhvd-r-reason-txt { font-size:11.5px; color:#c8d0e8; line-height:1.55; }

    /* Dimension bars */
    .bhvd-r-dims { padding:14px 18px 16px; border-top:1px solid rgba(255,255,255,0.05); animation:bhvd-section-in .4s ease both; }
    .bhvd-r-dim-row { display:flex; align-items:center; gap:9px; padding:4px 0; }
    .bhvd-r-dim-name { font-size:10.5px; color:#9ba3c0; flex:0 0 128px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .bhvd-r-dim-bar { flex:1; height:2px; background:rgba(255,255,255,0.06); border-radius:2px; overflow:hidden; }
    .bhvd-r-dim-fill { height:100%; border-radius:2px; transition:width .5s cubic-bezier(.22,1,.36,1); }
    .bhvd-r-dim-num { font-size:10.5px; font-family:monospace; font-weight:700; flex-shrink:0; width:22px; text-align:right; }

    /* CTA */
    .bhvd-r-cta-wrap { padding:10px 18px 16px; }
    .bhvd-r-cta { display:flex; align-items:center; justify-content:space-between; width:100%; padding:13px 16px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.10); border-radius:10px; color:#c0c8e0; font-size:12px; font-weight:700; text-align:left; cursor:pointer; transition:all .2s; font-family:inherit; letter-spacing:.01em; box-sizing:border-box; }
    .bhvd-r-cta:hover { background:rgba(255,255,255,0.09); border-color:rgba(255,255,255,0.20); color:#e8f0ff; }
    .bhvd-r-cta-label { flex:1; }
    .bhvd-r-cta-count { font-size:14px; font-weight:900; font-family:monospace; flex-shrink:0; margin-left:10px; opacity:.7; }
    .bhvd-r-cta-arrow { font-size:14px; flex-shrink:0; margin-left:6px; opacity:.5; transition:transform .2s; }
    .bhvd-r-cta:hover .bhvd-r-cta-arrow { transform:translateX(3px); opacity:.9; }

    /* Category rank bar */
    .bhvd-r-cat-bar { padding:0 18px 10px; }
    .bhvd-r-cat-meta { display:flex; justify-content:space-between; font-size:9.5px; color:#4a5272; margin-bottom:5px; }
    .bhvd-r-cat-meta b { color:#7a82a0; }
    .bhvd-r-cat-track { height:3px; background:rgba(255,255,255,0.06); border-radius:2px; overflow:hidden; position:relative; }
    .bhvd-r-cat-fill { position:absolute; top:0; left:0; bottom:0; width:0; border-radius:2px; transition:width .6s cubic-bezier(.22,1,.36,1); }

    /* Disclaimer footnote */
    .bhvd-r-footnote { padding:0 18px 14px; font-size:9px; color:#2e3555; line-height:1.5; text-align:center; }

    /* Collapsible sections */
    .bhvd-r-section-hdr { display:flex; align-items:center; justify-content:space-between; padding:13px 18px; border-top:1px solid rgba(255,255,255,0.05); cursor:pointer; user-select:none; transition:background .12s; }
    .bhvd-r-section-hdr:hover { background:rgba(255,255,255,0.025); }
    .bhvd-r-section-hdr-left { display:flex; align-items:center; gap:9px; }
    .bhvd-r-section-count { font-size:8px; font-family:monospace; font-weight:900; padding:1px 6px; border-radius:8px; }
    .bhvd-r-section-chevron { font-size:10px; color:#3a4468; transition:transform .25s cubic-bezier(.22,1,.36,1); line-height:1; }
    .bhvd-r-section-body { max-height:0; overflow:hidden; transition:max-height .35s cubic-bezier(.22,1,.36,1); }
    .bhvd-r-section-body.open { max-height:600px; }
    /* Ghost tappable */
    .bhvd-r-ghost-cta { font-size:10px; color:#4a6aaa; letter-spacing:.04em; padding:6px 14px 10px; display:flex; align-items:center; gap:5px; cursor:pointer; font-weight:600; transition:color .15s; }
    .bhvd-r-ghost-cta:hover { color:#7a9adf; }

    /* Share overlay */
    #bhvd-share-sheet { display:none; padding:26px 26px 28px; }
    @keyframes bhvd-share-up { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
    #bhvd-share-sheet.open { display:block; animation:bhvd-share-up .22s cubic-bezier(.22,1,.36,1) both; }
    .bhvd-share-hdr { font-size:9px; font-weight:800; letter-spacing:.2em; color:#4a5272; text-transform:uppercase; text-align:center; margin-bottom:16px; }
    .bhvd-share-card { background:#0b0d1a; border:1px solid rgba(255,255,255,0.07); border-radius:14px; padding:18px 18px 16px; margin-bottom:18px; }
    .bhvd-share-card-row { display:flex; align-items:flex-start; gap:14px; margin-bottom:12px; }
    .bhvd-share-card-score { font-size:34px; font-weight:900; font-family:monospace; line-height:1; letter-spacing:-.04em; flex-shrink:0; }
    .bhvd-share-card-score span { font-size:14px; opacity:.35; }
    .bhvd-share-card-right { flex:1; min-width:0; }
    .bhvd-share-card-name { font-size:15px; font-weight:800; color:#f0f2ff; letter-spacing:-.01em; line-height:1.2; }
    .bhvd-share-card-verdict { font-size:8px; font-weight:900; letter-spacing:.12em; margin-top:6px; display:inline-block; padding:3px 9px; border-radius:5px; border:1px solid; }
    .bhvd-share-act { display:flex; align-items:center; gap:13px; padding:13px 16px; border-radius:11px; border:1px solid rgba(255,255,255,0.07); background:#0b0d1a; color:#c0c8e0; font-size:12.5px; font-weight:600; cursor:pointer; font-family:inherit; transition:all .15s; text-align:left; width:100%; }
    .bhvd-share-act:hover { background:#141828; border-color:rgba(255,255,255,0.14); color:#e0e8ff; }
    .bhvd-share-act.x-btn { background:#000; border-color:#1c1c1c; }
    .bhvd-share-act.x-btn:hover { background:#0d0d0d; border-color:#333; }
    .bhvd-share-cancel { background:none; border:none; color:#8892b0; font-size:12px; cursor:pointer; width:100%; padding:12px; font-family:inherit; transition:color .15s; letter-spacing:.02em; }
    .bhvd-share-cancel:hover { color:#d0d8f0; }
  `;

  var styleEl = document.createElement("style");
  styleEl.textContent = STYLES;
  document.head.appendChild(styleEl);

  var sb = document.createElement("div");
  sb.id = "bhvd-signal-sidebar";
  sb.innerHTML =
    '<div id="bhvd-panel">' +
        '<div id="bhvd-panel-inner">' +
          '<div class="bhvd-hdr">' +
            '<div class="bhvd-hdr-logo">' +
              '<svg viewBox="0 0 22 22" width="18" height="18" style="color:#4a78f0">' + NORM_LOGO + '</svg>' +
              'NORM' +
            '</div>' +
            '<div class="bhvd-hdr-right">' +
              '<button class="bhvd-share-icon" id="bhvd-share-open" style="display:none"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="16"/></svg></button>' +
              '<button class="bhvd-close" id="bhvd-close">\xd7</button>' +
            '</div>' +
          '</div>' +
          '<div id="bhvd-scanning"><div class="bhvd-spin"></div><div class="bhvd-scan-txt">Scanning page…</div><div class="bhvd-scan-sub">Analyzing claims and evidence</div></div>' +
          '<div id="bhvd-unscored"><div class="bhvd-us-icon">◎</div><div class="bhvd-us-title">Not in Public Record</div><div class="bhvd-us-body">This brand has not entered the public claim record yet.</div><div class="bhvd-snapshot-box"><div class="bhvd-snapshot-row"><span class="bhvd-snapshot-num" id="bhvd-snapshot-claims">—</span><span class="bhvd-snapshot-lbl">benefit claims detected on this page</span></div><div class="bhvd-snapshot-row"><span class="bhvd-snapshot-num" id="bhvd-snapshot-evidence">—</span><span class="bhvd-snapshot-lbl">evidence references detected</span></div></div><div class="bhvd-add-note">Claim snapshot captured for review. An alignment rating will only be shown after editorial assessment.</div></div>' +
          '<div id="bhvd-unverifiable"><div class="bhvd-uv-icon">◌</div><div class="bhvd-uv-title">Assessment limited by site access</div><div class="bhvd-uv-body">This brand limits independent reading. Results reflect visible content only.</div><div class="bhvd-uv-note">Ratings are based on publicly visible evidence only.</div></div>' +
          '<div id="bhvd-suppressed"><div class="bhvd-uv-icon">◑</div><div class="bhvd-uv-title">Limited visibility — rating withheld</div><div class="bhvd-uv-body">We captured too little data to assess this brand reliably.</div><div class="bhvd-uv-note">Try a product-specific page for better coverage.</div></div>' +
          '<div id="bhvd-limited-data"><div class="bhvd-uv-icon">◌</div><div class="bhvd-uv-title">Insufficient Public Data</div><div class="bhvd-uv-body">Too sparse to support a reliable assessment.</div><div class="bhvd-uv-note">Try a product-specific page or check back soon.</div></div>' +
          '<div id="bhvd-pending"><div class="bhvd-uv-icon">◑</div><div class="bhvd-uv-title">Assessment in Progress</div><div class="bhvd-uv-body">This brand has not yet been cleared for public display.</div><div class="bhvd-uv-note">Ratings are held until they meet our coverage threshold.</div></div>' +
          '<div id="bhvd-expired"><div class="bhvd-uv-icon">○</div><div class="bhvd-uv-title">Assessment Expired</div><div class="bhvd-uv-body">This brand\'s rating has passed its validity window and is being re-evaluated.</div><div class="bhvd-uv-note">Check back shortly.</div></div>' +
          '<div id="bhvd-share-sheet"></div>' +
          '<div id="bhvd-result">' +
            '<div class="bhvd-r-hero">' +
              '<div class="bhvd-r-hero-left">' +
                '<div class="bhvd-r-brand" id="bhvd-r-brand"></div>' +
                '<div class="bhvd-r-badge" id="bhvd-r-badge"><span class="bhvd-r-badge-dot" id="bhvd-r-badge-dot"></span><span id="bhvd-r-badge-txt"></span></div>' +
              '</div>' +
              '<div class="bhvd-r-score-block"><span class="bhvd-r-score-num" id="bhvd-r-score"></span><span class="bhvd-r-score-den">/100</span></div>' +
            '</div>' +
            '<div class="bhvd-r-ratio-row"><span class="bhvd-r-ratio" id="bhvd-r-ratio"></span></div>' +
            '<div class="bhvd-r-cat-bar" id="bhvd-r-cat-bar" style="display:none">' +
              '<div class="bhvd-r-cat-meta"><span id="bhvd-r-cat-lbl"></span><span id="bhvd-r-cat-pct"></span></div>' +
              '<div class="bhvd-r-cat-track"><div class="bhvd-r-cat-fill" id="bhvd-r-cat-fill"></div></div>' +
            '</div>' +
            '<div class="bhvd-r-divider"></div>' +
            '<div class="bhvd-r-sentence" id="bhvd-r-sentence"></div>' +
            '<div class="bhvd-r-flag" id="bhvd-r-flag-sec"><div class="bhvd-r-flag-eyebrow" id="bhvd-r-flag-lbl">What we found</div><div class="bhvd-r-flag-card" id="bhvd-r-flag-card"><div class="bhvd-r-flag-quote" id="bhvd-r-flag-quote"></div><div class="bhvd-r-flag-gap"><span class="bhvd-r-flag-gap-badge" id="bhvd-r-flag-badge"></span><span id="bhvd-r-flag-gap-txt"></span></div></div></div>' +
            '<div class="bhvd-r-more-claims" id="bhvd-r-more-claims" style="display:none"></div>' +
            '<div id="bhvd-r-lock-sec" style="display:none">' +
              '<div class="bhvd-r-claims-hdr"><span class="bhvd-r-claims-lbl">Claims</span><span class="bhvd-r-claims-count" id="bhvd-r-claims-count"></span></div>' +
              '<div class="bhvd-r-lock-wrap">' +
                '<div id="bhvd-r-ghost-claims"></div>' +
                '<div class="bhvd-r-lock-overlay">' +
                  '<div class="bhvd-r-lock-title">Claim-by-claim breakdown</div>' +
                  '<div class="bhvd-r-lock-sub">See every marketing claim verified against visible evidence — verdict by verdict.</div>' +
                  '<button class="bhvd-r-lock-btn" id="bhvd-r-lock-btn">Unlock with Pro →</button>' +
                '</div>' +
              '</div>' +
            '</div>' +
            '<div id="bhvd-r-reasons-sec" style="display:none">' +
              '<div class="bhvd-r-section-hdr" id="bhvd-reasons-hdr">' +
                '<div class="bhvd-r-section-hdr-left">' +
                  '<span class="bhvd-sec-lbl" style="margin-bottom:0">WHY THIS RATING</span>' +
                  '<span class="bhvd-r-section-count" id="bhvd-reasons-count" style="display:none"></span>' +
                '</div>' +
                '<span class="bhvd-r-section-chevron" id="bhvd-reasons-chev">▾</span>' +
              '</div>' +
              '<div class="bhvd-r-section-body" id="bhvd-reasons-body">' +
                '<div style="padding:0 18px 14px"><div id="bhvd-r-reasons-list"></div></div>' +
              '</div>' +
            '</div>' +
            '<div id="bhvd-r-dims-sec" style="display:none">' +
              '<div class="bhvd-r-section-hdr" id="bhvd-dims-hdr">' +
                '<div class="bhvd-r-section-hdr-left">' +
                  '<span class="bhvd-sec-lbl" style="margin-bottom:0">EVIDENCE DIMENSIONS</span>' +
                  '<span class="bhvd-r-section-count" id="bhvd-dims-count" style="display:none"></span>' +
                '</div>' +
                '<span class="bhvd-r-section-chevron" id="bhvd-dims-chev">▾</span>' +
              '</div>' +
              '<div class="bhvd-r-section-body" id="bhvd-dims-body">' +
                '<div style="padding:0 18px 16px"><div id="bhvd-r-dims-list"></div></div>' +
              '</div>' +
            '</div>' +
            '<div class="bhvd-r-cta-wrap"><button class="bhvd-r-cta" id="bhvd-r-cta"><span class="bhvd-r-cta-label" id="bhvd-r-cta-label"></span><span class="bhvd-r-cta-count" id="bhvd-r-cta-count"></span><span class="bhvd-r-cta-arrow">→</span></button></div>' +
            '<div class="bhvd-r-footnote">Scores reflect public marketing claims — not efficacy, safety, or regulatory status.</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '<div id="bhvd-tab">' +
      '<div id="bhvd-hover-card"><div class="bhvd-hc-title" id="bhvd-hc-title">NORM</div><div class="bhvd-hc-sub" id="bhvd-hc-sub">Checking this page…</div></div>' +
      '<svg id="bhvd-tab-blob" viewBox="0 0 22 22" width="34" height="34" style="color:#2a3050">' + NORM_LOGO + '</svg>' +
    '</div>';

  document.body.appendChild(sb);

  // Collapsible section toggles
  (function() {
    function mkToggle(hdrId, bodyId, chevId) {
      var hdr  = document.getElementById(hdrId);
      var body = document.getElementById(bodyId);
      var chev = document.getElementById(chevId);
      if (!hdr) return;
      hdr.addEventListener("click", function() {
        var open = body.classList.toggle("open");
        chev.style.transform = open ? "rotate(180deg)" : "";
      });
    }
    mkToggle("bhvd-reasons-hdr", "bhvd-reasons-body", "bhvd-reasons-chev");
    mkToggle("bhvd-dims-hdr",    "bhvd-dims-body",    "bhvd-dims-chev");
  })();

  var isOpen = false;
  var _provInterval = null;
  var _provPollTimer = null;
  var _sidebarTier = 'free';

  // Fetch tier once so lock card can render correctly
  chrome.runtime.sendMessage({ type: 'FETCH_TIER' }, function(resp) {
    _sidebarTier = (resp && resp.tier) || 'free';
  });

  document.getElementById("bhvd-tab").addEventListener("click", function () {
    isOpen = !isOpen;
    document.getElementById("bhvd-panel").classList.toggle("open", isOpen);
  });
  document.getElementById("bhvd-close").addEventListener("click", function () {
    isOpen = false;
    document.getElementById("bhvd-panel").classList.remove("open");
  });

  function setTab(sig, title, sub) {
    var blob = document.getElementById("bhvd-tab-blob");
    var tab  = document.getElementById("bhvd-tab");
    document.getElementById("bhvd-hc-title").textContent = title || "NORM";
    document.getElementById("bhvd-hc-sub").textContent   = sub   || "Checking this page…";
    if (SIG[sig]) {
      var s = SIG[sig];
      tab.style.background = s.bg; tab.style.borderColor = s.bd;
      blob.style.color = s.c;
      blob.style.filter = "";
      blob.style.animation = "bhvd-glow-" + sig + " 2.8s ease-in-out infinite";
      document.getElementById("bhvd-hc-title").style.color = s.c;
    } else if (sig === "scanning") {
      tab.style.background = "#0a0c14"; tab.style.borderColor = "rgba(255,255,255,0.08)";
      blob.style.color = "#4a5272";
      blob.style.filter = ""; blob.style.animation = "bhvd-pulse 1.2s ease infinite"; document.getElementById("bhvd-hc-title").style.color = "#8892b0";
    } else {
      tab.style.background = "#0a0c14"; tab.style.borderColor = "rgba(255,255,255,0.06)";
      blob.style.color = "#2a3050";
      blob.style.filter = ""; blob.style.animation = "bhvd-glow-dormant 3.5s ease-in-out infinite"; document.getElementById("bhvd-hc-title").style.color = "#8892b0";
    }
  }

  function showScanning() {
    setTab("scanning", "Scanning…", "Analyzing claims and evidence");
    document.getElementById("bhvd-scanning").style.display = "block";
    document.getElementById("bhvd-unscored").style.display = "none";
    document.getElementById("bhvd-result").style.display   = "none";
  }

  function showProvisional(url) {
    if (_provInterval)  { clearInterval(_provInterval);  _provInterval = null; }
    if (_provPollTimer) { clearTimeout(_provPollTimer);   _provPollTimer = null; }

    setTab("scanning", "Scoring…", "Multi-page AI analysis running");
    var scanEl  = document.getElementById("bhvd-scanning");
    var txtEl   = scanEl.querySelector(".bhvd-scan-txt");
    var subEl   = scanEl.querySelector(".bhvd-scan-sub");
    scanEl.style.display = "block";
    document.getElementById("bhvd-unscored").style.display = "none";
    document.getElementById("bhvd-result").style.display   = "none";
    // panel stays closed — user opens it by clicking the tab

    var secs = 60;
    var startTime = Date.now();

    function tick() {
      if (txtEl) txtEl.textContent = "Scoring in progress… " + secs + "s";
      if (subEl) subEl.textContent = "Running multi-page AI analysis";
    }
    tick();

    function doPoll() {
      chrome.runtime.sendMessage({ type: "LOOKUP_URL", url: url }, function(resp) {
        if (chrome.runtime.lastError) { scheduleNextPoll(); return; }
        if (resp && resp.status === "found" && resp.data && resp.data.signal_color && !resp.data.is_provisional) {
          if (_provInterval)  { clearInterval(_provInterval);  _provInterval = null; }
          if (_provPollTimer) { clearTimeout(_provPollTimer);   _provPollTimer = null; }
          var elapsed = Math.round((Date.now() - startTime) / 1000);
          if (txtEl && elapsed < 115) txtEl.textContent = "Scored in " + elapsed + "s!";
          setTimeout(function() { showResult(resp.data); }, elapsed < 115 ? 800 : 0);
        } else {
          scheduleNextPoll();
        }
      });
    }

    function scheduleNextPoll() {
      if (secs > 0) {
        _provPollTimer = setTimeout(doPoll, 10000);
      } else {
        // Countdown done, still scoring — keep polling every 15s, update text
        if (txtEl) txtEl.textContent = "Still scoring…";
        if (subEl) subEl.textContent = "Hang tight — results landing soon";
        _provPollTimer = setTimeout(doPoll, 15000);
      }
    }

    _provInterval = setInterval(function() {
      secs--;
      if (secs <= 0) {
        clearInterval(_provInterval); _provInterval = null;
        doPoll(); // check immediately at 0
      } else {
        tick();
        if (secs % 10 === 0) doPoll();
      }
    }, 1000);
  }

  function showUnverifiable() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-unverifiable").style.display = "block";
    // panel stays closed — user opens it by clicking the tab
  }

  var _domCaptureSent = {};  // guard against duplicate captures per URL

  // Paths that must never be captured — checkout, auth, account, personal pages
  var _BLOCKED_PATHS = [
    "/checkout","/cart","/account","/order","/orders","/login","/signin",
    "/signup","/register","/profile","/subscription","/billing","/payment",
    "/my-","/my/","/purchases","/history","/address","/settings","/security",
    "/forgot-password","/reset-password","/2fa","/verify"
  ];

  function _isBlockedPath(url) {
    try {
      var path = new URL(url).pathname.toLowerCase();
      for (var i = 0; i < _BLOCKED_PATHS.length; i++) {
        if (path.indexOf(_BLOCKED_PATHS[i]) === 0 || path.indexOf(_BLOCKED_PATHS[i]) !== -1 && _BLOCKED_PATHS[i].indexOf("/my-") === 0) return true;
        if (path === _BLOCKED_PATHS[i] || path.startsWith(_BLOCKED_PATHS[i] + "/") || path.startsWith(_BLOCKED_PATHS[i].replace(/\/$/, "") + "/")) return true;
      }
    } catch(_) {}
    return false;
  }

  function _stripPii(text) {
    return text
      .replace(/\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b/g, "[email]")
      .replace(/\b(?:\+?1[\s\-.]?)?\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4}\b/g, "[phone]")
      .replace(/\b\d{4}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}\b/g, "[card]")
      .replace(/\b\d{3}-\d{2}-\d{4}\b/g, "[ssn]");
  }

  function tryDomCapture(url) {
    // Never capture blocked paths
    if (_isBlockedPath(url)) return;
    if (_domCaptureSent[url]) return;
    var domText = document.body ? document.body.innerText : "";
    if (!domText || domText.length < 500) return;
    _domCaptureSent[url] = true;
    var safeText = _stripPii(domText.slice(0, 50000));
    // Fire-and-forget — no UI change, no polling, no promise of a score
    chrome.runtime.sendMessage({ type: "DOM_CAPTURE", url: url, dom_text: safeText }, function() {
      if (chrome.runtime.lastError) {} // silent
    });
  }

  function showNotYetAssessed(claimCount, evidenceCount, url) {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-snapshot-claims").textContent   = claimCount  > 0 ? claimCount  : "0";
    document.getElementById("bhvd-snapshot-evidence").textContent = evidenceCount > 0 ? evidenceCount : "0";
    document.getElementById("bhvd-unscored").style.display = "block";

    var currentDomain = window.location.hostname.replace(/^www\./, "");
    var requestUrl = "https://trynorm.co/request?d=" + encodeURIComponent(currentDomain) + "&source=extension";

    var reqLink = document.getElementById("bhvd-unscored-request");
    if (!reqLink) {
      reqLink = document.createElement("a");
      reqLink.id = "bhvd-unscored-request";
      reqLink.setAttribute("target", "_blank");
      reqLink.setAttribute("rel", "noopener noreferrer");
      reqLink.setAttribute("style", "display:block;margin-top:12px;font-size:10.5px;color:#1a8fff;text-decoration:none;text-align:center;font-weight:600;letter-spacing:.01em;");
      reqLink.textContent = "Request an assessment →";
      document.getElementById("bhvd-unscored").appendChild(reqLink);
    }
    reqLink.href = requestUrl;

    logDemandEvent(currentDomain, "not_assessed_shown");
    // panel stays closed — user opens it by clicking the tab
    if (url) tryDomCapture(url);
  }

  // Keep showUnscored as alias — called from legacy paths (unverifiable fallback etc.)
  function showUnscored(url) {
    showNotYetAssessed(0, 0, url);
  }

  function _hideAllPanelStates() {
    ["bhvd-scanning","bhvd-unscored","bhvd-unverifiable","bhvd-suppressed",
     "bhvd-limited-data","bhvd-pending","bhvd-expired","bhvd-result"]
      .forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.style.display = "none";
      });
  }

  function showSuppressed() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-suppressed").style.display = "block";
    // panel stays closed — user opens it by clicking the tab
  }

  function showLimitedData() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-limited-data").style.display = "block";
    // panel stays closed — user opens it by clicking the tab
  }

  function showPendingReview() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-pending").style.display = "block";
    // panel stays closed — user opens it by clicking the tab
  }

  function showExpired() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-expired").style.display = "block";
    // panel stays closed — user opens it by clicking the tab
  }

  function _esc(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function timeAgo(iso) {
    if (!iso) return "unknown";
    var diff = Date.now() - new Date(iso).getTime();
    var mins = Math.floor(diff / 60000);
    if (mins < 2)   return "just now";
    if (mins < 60)  return mins + "m ago";
    var hrs = Math.floor(mins / 60);
    if (hrs < 24)   return hrs + "h ago";
    return Math.floor(hrs / 24) + "d ago";
  }

  function truncateWords(text, n) {
    if (!text) return "";
    var words = text.trim().split(/\s+/);
    if (words.length <= n) {
      var t = text.trim();
      if (!/[.!?…]$/.test(t)) t += ".";
      return t;
    }
    return words.slice(0, n).join(" ") + "…";
  }

  function getVerdictSentence(sig) {
    var map = {
      green:  "Evidence is visible and consistent.",
      yellow: "Check claims against label before buying.",
      red:    "Claims exceed what is shown.",
    };
    return map[sig] || "Key information is not clearly shown.";
  }

  function getTopFinding(ld, r, sig) {
    if (ld.gap_map && ld.gap_map.length > 0) {
      var preferred = (sig === "red" || sig === "yellow")
        ? ld.gap_map.filter(function(g) { return g.status === "gap" || g.status === "partial"; })
        : ld.gap_map.filter(function(g) { return g.status === "aligned"; });
      var pool = preferred.length ? preferred : ld.gap_map;
      if (pool[0] && pool[0].claim) return truncateWords(pool[0].claim, 12);
    }
    var fullText = ld.why_this_verdict || r.consumer_summary || "";
    if (fullText) {
      var sentences = fullText.replace(/\s+/g, " ").trim().split(/\.\s+/);
      for (var i = 0; i < sentences.length; i++) {
        var sent = sentences[i].trim();
        if (sent.length > 15) return truncateWords(sent, 12);
      }
    }
    var defaults = {
      green:  "Key claims match visible evidence references.",
      yellow: "Some benefit claims lack clinical backing.",
      red:    "Marketing language exceeds the evidence shown.",
    };
    return defaults[sig] || "Evidence gaps found across reviewed claims.";
  }

  function getSupportLine(ld, r, sig) {
    if ((sig === "green" || sig === "yellow") && ld.strengths) {
      return truncateWords(ld.strengths, 10);
    }
    var fullText = ld.why_this_verdict || r.consumer_summary || "";
    if (fullText) {
      var sentences = fullText.replace(/\s+/g, " ").trim().split(/\.\s+/);
      var nonEmpty = sentences.filter(function(s) { return s.trim().length > 15; });
      if (nonEmpty.length >= 2) return truncateWords(nonEmpty[1].trim(), 10);
    }
    return null;
  }

  function brandHandle(bn) {
    var cleaned = bn
      .replace(/[\s,\.]+?(Inc\.?|LLC\.?|Ltd\.?|Corp\.?)$/i, "")
      .replace(/[^a-zA-Z0-9]/g, "")
      .trim();
    return cleaned || bn.replace(/[^a-zA-Z0-9]/g, "");
  }
  function generateXShareText(bn, sc, link) {
    var handle  = brandHandle(bn);
    var atTag   = "@" + handle;
    var hashTag = "#" + handle;
    var hooks    = ["Before you buy " + bn + " —", "Thinking about " + bn + "?", "If you're using " + bn + " —", "Quick check on " + bn + " —"];
    var insights = ["Most people never check what this actually means.", "This gets misunderstood a lot.", "Almost no one verifies this.", "Looks simple — it's not."];
    var features = ["There's an instant check for this.", "Runs automatically on product pages.", "No digging. It surfaces instantly.", "Tap. Check. Done."];
    var hook    = hooks[Math.floor(Math.random() * hooks.length)];
    var insight = insights[Math.floor(Math.random() * insights.length)];
    var feature = features[Math.floor(Math.random() * features.length)];
    return hook + "\n\nNORM score: " + sc + "/100\n\nI checked it on NORM.\n\n" + insight + "\n\n" + feature + "\n\n→ " + link + "\n\n" + atTag + " " + hashTag + " #NORMCheck";
  }

  function showResult(r) {
    var sig = r.signal_color || "yellow";
    var s   = SIG[sig] || SIG.yellow;
    var ld  = r.leaderboard_data || {};

    var dataIntegrity = ld.data_integrity || (
      r.confidence === "high" ? "high" : r.confidence === "medium" ? "medium" : "low"
    );
    var isReviewed = (ld.review_status === "reviewed" || ld.review_status === "seeder_reviewed") && ld.total_score != null && ld.public_safe !== false;
    if (dataIntegrity === "low" && !isReviewed) { showLimitedData(); return; }

    var validUntil = r.valid_until || ld.valid_until || null;
    if (validUntil && Date.now() > new Date(validUntil).getTime()) { showExpired(); return; }

    _hideAllPanelStates();

    var score     = ld.total_score != null ? Math.round(ld.total_score) : Math.round(100 - (r.claim_support_risk || 50));
    var brandName = r.brand_name || (r.domain || window.location.hostname).replace(/^www\./, "").split(".")[0];
    var domain    = (r.domain || window.location.hostname).replace(/^www\./, "");
    var brandPage = "https://trynorm.co/brand?d=" + encodeURIComponent(domain) + "&source=extension&t=" + Date.now();

    var verdict        = ld.bhvd_verdict || null;
    var verdictDisplay = verdict ? (VERDICT_LABEL[verdict] || verdict) : s.label;
    var verdictC       = verdict ? (VERDICT_COLOR[verdict] || s.c) : s.c;
    var verdictSentence = getVerdictSentence(sig);

    setTab(sig, brandName, verdictSentence);

    // Show share button in header
    var shareOpenBtn = document.getElementById("bhvd-share-open");
    if (shareOpenBtn) shareOpenBtn.style.display = "flex";

    // ── Hero ──
    document.getElementById("bhvd-r-brand").textContent = brandName;
    var scoreEl = document.getElementById("bhvd-r-score");
    scoreEl.style.color = s.c;
    // Count-up animation
    (function(el, to) {
      var start = null;
      function step(ts) {
        if (!start) start = ts;
        var p = Math.min((ts - start) / 580, 1);
        var ease = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(to * ease);
        if (p < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
    })(scoreEl, score);

    var badgeEl = document.getElementById("bhvd-r-badge");
    badgeEl.style.color       = verdictC;
    badgeEl.style.borderColor = verdictC + "66";
    badgeEl.style.background  = verdictC + "18";
    document.getElementById("bhvd-r-badge-dot").style.background = verdictC;
    document.getElementById("bhvd-r-badge-txt").textContent      = verdictDisplay;

    // Claims ratio
    var gapMap       = ld.gap_map || [];
    var totalClaims  = ld.extraction_claim_count || r.extraction_claim_count || 0;
    var flaggedCount = gapMap.filter(function(g) { return g.status === "gap" || g.status === "partial"; }).length;
    var ratioEl = document.getElementById("bhvd-r-ratio");
    if (flaggedCount > 0 && totalClaims > 0) {
      ratioEl.innerHTML = '<b>' + flaggedCount + '</b> of ' + totalClaims + ' claims flagged';
    } else if (flaggedCount > 0) {
      ratioEl.innerHTML = '<b>' + flaggedCount + '</b> claims flagged';
    } else if (gapMap.length > 0) {
      ratioEl.innerHTML = '<b>' + gapMap.length + '</b> claims reviewed';
    } else {
      ratioEl.textContent = "";
    }

    // Category rank bar
    var catBarEl = document.getElementById("bhvd-r-cat-bar");
    var rank  = r.category_rank || r.rank_number;
    var total = r.category_total;
    if (catBarEl && rank != null && total != null) {
      var pctNum = r.category_percentile != null ? r.category_percentile : Math.round((1 - (rank / total)) * 100);
      var ord = pctNum === 1 ? "st" : pctNum === 2 ? "nd" : pctNum === 3 ? "rd" : "th";
      var catName = (r.category || "").replace(/_/g, " ");
      document.getElementById("bhvd-r-cat-lbl").innerHTML = "<b>#" + rank + "</b> of " + total + (catName ? " in " + catName : "");
      document.getElementById("bhvd-r-cat-pct").textContent = pctNum + ord + " percentile";
      var fillEl = document.getElementById("bhvd-r-cat-fill");
      fillEl.style.background = s.c;
      fillEl.style.width = "0";
      catBarEl.style.display = "block";
      requestAnimationFrame(function() { requestAnimationFrame(function() { fillEl.style.width = pctNum + "%"; }); });
    } else if (catBarEl) {
      catBarEl.style.display = "none";
    }

    // Verdict sentence — summary is the main free data point, show more of it
    var sentenceSrc = ld.why_this_verdict || r.consumer_summary || verdictSentence;
    document.getElementById("bhvd-r-sentence").textContent = truncateWords(sentenceSrc, 38);

    // Top flag + ghost claims preview
    var flagSec       = document.getElementById("bhvd-r-flag-sec");
    var moreClaimsSec = document.getElementById("bhvd-r-more-claims");
    var gapsOrPartial = gapMap.filter(function(g) { return g.status === "gap" || g.status === "partial"; });
    var topFlag = gapsOrPartial.length ? gapsOrPartial[0] : (gapMap.length ? gapMap[0] : null);
    var topClaimText = (topFlag && topFlag.claim) ? topFlag.claim
      : (sig === "green" && ld.strengths) ? ld.strengths
      : null;
    if (topClaimText) {
      document.getElementById("bhvd-r-flag-card").style.borderLeftColor = verdictC;
      var flagLbl = document.getElementById("bhvd-r-flag-lbl");
      if (flagLbl) flagLbl.textContent = sig === "green" ? "What checked out" : "What we found";
      document.getElementById("bhvd-r-flag-quote").textContent = "“" + truncateWords(topClaimText, 18) + "”";
      var gapText = (topFlag && (topFlag.gap_description || topFlag.gap || topFlag.evidence_note)) || (sig === "green" ? "Claim supported by visible evidence" : "No direct evidence found on this page");
      var badgeEl = document.getElementById("bhvd-r-flag-badge");
      if (badgeEl) {
        var badgeLabel = topFlag ? (topFlag.status === "gap" ? "No evidence" : topFlag.status === "partial" ? "Partial" : "Supported") : (sig === "green" ? "Supported" : "No evidence");
        var badgeClr   = topFlag ? (topFlag.status === "gap" ? "#e74c3c" : topFlag.status === "partial" ? "#f39c12" : "#27ae60") : verdictC;
        badgeEl.textContent = badgeLabel;
        badgeEl.style.color      = badgeClr;
        badgeEl.style.background = badgeClr + "18";
      }
      document.getElementById("bhvd-r-flag-gap-txt").textContent = gapText;
      flagSec.style.display = "block";

      // Ghost claims — show next 1-2 flagged claims as blurred teaser cards
      var restClaims = gapsOrPartial.slice(1, 3);
      if (moreClaimsSec && restClaims.length > 0) {
        var ghostHtml = "";
        restClaims.forEach(function(c) {
          var dotC = c.status === "gap" ? "#e74c3c" : "#f39c12";
          ghostHtml += '<div class="bhvd-r-ghost-card">' +
            '<span class="bhvd-r-ghost-dot" style="background:' + dotC + '"></span>' +
            '<span class="bhvd-r-ghost-text">"' + _esc(truncateWords(c.claim, 10)) + '"</span>' +
          '</div>';
        });
        ghostHtml += '<div class="bhvd-r-ghost-cta">See all ' + gapsOrPartial.length + ' flagged claims →</div>';
        ghostHtml += '<div class="bhvd-r-more-fade"></div>';
        moreClaimsSec.innerHTML = ghostHtml;
        moreClaimsSec.style.display = "block";
        moreClaimsSec.style.cursor = "pointer";
        moreClaimsSec.onclick = function() {
          logDemandEvent(domain, "extension_click");
          window.open(brandPage, "_blank");
        };
      } else if (moreClaimsSec) {
        moreClaimsSec.style.display = "none";
      }
    } else {
      flagSec.style.display = "none";
      if (moreClaimsSec) moreClaimsSec.style.display = "none";
    }

    // Reasons
    var reasons     = (r.why_flagged_top_reasons && Array.isArray(r.why_flagged_top_reasons)) ? r.why_flagged_top_reasons : [];
    var reasonsSec  = document.getElementById("bhvd-r-reasons-sec");
    var reasonsList = document.getElementById("bhvd-r-reasons-list");
    if (reasons.length > 0) {
      reasonsList.innerHTML = reasons.map(function(txt, i) {
        return '<div class="bhvd-r-reason-row">' +
          '<div class="bhvd-r-reason-num" style="background:' + verdictC + '18;border:1px solid ' + verdictC + '44;color:' + verdictC + '">' + (i+1) + '</div>' +
          '<span class="bhvd-r-reason-txt">' + _esc(txt) + '</span>' +
        '</div>';
      }).join('');
      var rc = document.getElementById("bhvd-reasons-count");
      if (rc) { rc.textContent = reasons.length; rc.style.cssText = "background:" + verdictC + "20;color:" + verdictC + ";display:inline"; }
      reasonsSec.style.display = 'block';
    } else {
      reasonsSec.style.display = 'none';
    }

    // Dimension bars — numeric scores
    var DIM_LABELS = {
      claim_specificity:      "Claim Specificity",
      evidence_alignment:     "Evidence Alignment",
      source_transparency:    "Source Transparency",
      mechanism_integrity:    "Mechanism Integrity",
      regulatory_risk:        "Regulatory Risk",
      comparative_fairness:   "Comparative Fairness",
      trust_signal_integrity: "Trust Signal Integrity"
    };
    var dimScores = r.dimension_scores || {};
    var dimKeys   = Object.keys(dimScores).filter(function(k) { return DIM_LABELS[k]; });
    var dimsSec   = document.getElementById("bhvd-r-dims-sec");
    var dimsList  = document.getElementById("bhvd-r-dims-list");
    if (dimKeys.length > 0) {
      dimsList.innerHTML = dimKeys.slice(0, 6).map(function(k) {
        var risk    = Number(dimScores[k]) || 50;
        var quality = Math.round(100 - risk);
        var dc      = quality >= 68 ? "#27ae60" : quality >= 44 ? "#f39c12" : "#e74c3c";
        return '<div class="bhvd-r-dim-row">' +
          '<span class="bhvd-r-dim-name">' + _esc(DIM_LABELS[k]) + '</span>' +
          '<div class="bhvd-r-dim-bar"><div class="bhvd-r-dim-fill" style="width:' + quality + '%;background:' + dc + '"></div></div>' +
          '<span class="bhvd-r-dim-num" style="color:' + dc + '">' + quality + '</span>' +
        '</div>';
      }).join('');
      var dc2 = document.getElementById("bhvd-dims-count");
      if (dc2) { dc2.textContent = dimKeys.length; dc2.style.cssText = "background:rgba(74,120,240,0.15);color:#4a78f0;display:inline"; }
      dimsSec.style.display = 'block';
    } else {
      dimsSec.style.display = 'none';
    }

    // CTA
    var ctaEl      = document.getElementById("bhvd-r-cta");
    var ctaLabel   = document.getElementById("bhvd-r-cta-label");
    var ctaCount   = document.getElementById("bhvd-r-cta-count");
    if (ctaLabel) ctaLabel.textContent = flaggedCount > 0 ? "Read the full evidence report" : "View full brand report";
    if (ctaCount) { ctaCount.textContent = flaggedCount > 0 ? flaggedCount + " flags" : ""; }
    ctaEl.style.borderColor = verdictC + "44";
    ctaEl.onclick = function() {
      logDemandEvent(domain, "extension_click");
      window.open(brandPage, "_blank");
    };

    // ── Share sheet ──
    var shareSheet = document.getElementById("bhvd-share-sheet");
    var resultEl   = document.getElementById("bhvd-result");
    var _shareText = generateXShareText(brandName, score, brandPage);

    shareSheet.innerHTML =
      '<div class="bhvd-share-hdr">Share this signal</div>' +
      '<div class="bhvd-share-card">' +
        '<div class="bhvd-share-card-row">' +
          '<div class="bhvd-share-card-score" style="color:' + s.c + '">' + score + '<span>/100</span></div>' +
          '<div class="bhvd-share-card-right">' +
            '<div class="bhvd-share-card-name">' + _esc(brandName) + '</div>' +
            '<div class="bhvd-share-card-verdict" style="color:' + verdictC + ';border-color:' + verdictC + '44;background:' + verdictC + '18">' + _esc(verdictDisplay) + '</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<textarea id="bhvd-share-ta" style="width:100%;background:#07080e;border:1px solid rgba(255,255,255,.07);border-radius:8px;padding:10px;font-size:11px;line-height:1.7;color:#c0c8e0;white-space:pre-wrap;min-height:110px;max-height:170px;overflow-y:auto;resize:none;outline:none;font-family:inherit;box-sizing:border-box" readonly></textarea>' +
      '<div style="display:flex;gap:5px;margin-top:8px">' +
        '<button class="bhvd-share-act x-btn" id="bhvd-share-x" style="flex:1;font-size:10px;font-weight:700">Post 𝕏</button>' +
        '<button class="bhvd-share-act" id="bhvd-share-copy" style="flex:1;font-size:10px">Copy</button>' +
        '<button class="bhvd-share-act" id="bhvd-share-native" style="flex:1;font-size:10px">Share</button>' +
      '</div>' +
      '<div style="font-size:9px;color:#4a5272;text-align:center;margin-top:5px;font-family:inherit;letter-spacing:.04em">Send this to someone using it.</div>' +
      '<div id="bhvd-copy-ok" style="font-size:9px;color:#27ae60;text-align:center;min-height:13px;margin-top:3px"></div>' +
      '<button class="bhvd-share-cancel" id="bhvd-share-cancel">← Back</button>';

    document.getElementById("bhvd-share-ta").value = _shareText;

    document.getElementById("bhvd-share-open").onclick = function() {
      _shareText = generateXShareText(brandName, score, brandPage);
      document.getElementById("bhvd-share-ta").value = _shareText;
      resultEl.style.display = "none";
      shareSheet.classList.add("open");
      document.getElementById("bhvd-panel-inner").scrollTop = 0;
    };
    document.getElementById("bhvd-share-cancel").onclick = function() {
      shareSheet.classList.remove("open");
      resultEl.style.display = "block";
    };
    document.getElementById("bhvd-share-copy").onclick = function() {
      var ta = document.getElementById("bhvd-share-ta");
      var ok = document.getElementById("bhvd-copy-ok");
      navigator.clipboard.writeText(ta.value).then(function() {
        ok.textContent = "✓ Copied"; setTimeout(function() { ok.textContent = ""; }, 2000);
      });
    };
    document.getElementById("bhvd-share-x").onclick = function() {
      var ta = document.getElementById("bhvd-share-ta");
      window.open("https://twitter.com/intent/tweet?text=" + encodeURIComponent(ta.value), "_blank");
    };
    document.getElementById("bhvd-share-native").onclick = function() {
      var ta = document.getElementById("bhvd-share-ta");
      if (navigator.share) {
        navigator.share({ title: brandName + " — NORM score: " + score + "/100", text: ta.value, url: brandPage }).catch(function() {});
      } else {
        var ok = document.getElementById("bhvd-copy-ok");
        navigator.clipboard.writeText(ta.value).then(function() {
          ok.textContent = "✓ Copied"; setTimeout(function() { ok.textContent = ""; }, 2000);
        });
      }
    };

    // ── Tier gating — free users see lock card instead of claim detail ──
    var isPro = (_sidebarTier === 'pro' || _sidebarTier === 'brand');
    var lockSec     = document.getElementById("bhvd-r-lock-sec");
    var flagSecEl   = document.getElementById("bhvd-r-flag-sec");
    var moreClaimsEl= document.getElementById("bhvd-r-more-claims");
    var reasonsSecEl= document.getElementById("bhvd-r-reasons-sec");
    var dimsSecEl   = document.getElementById("bhvd-r-dims-sec");

    if (isPro) {
      if (lockSec) lockSec.style.display = "none";
    } else {
      // Hide detailed claim sections behind lock
      if (flagSecEl)    flagSecEl.style.display    = "none";
      if (moreClaimsEl) moreClaimsEl.style.display = "none";
      if (reasonsSecEl) reasonsSecEl.style.display = "none";
      if (dimsSecEl)    dimsSecEl.style.display    = "none";

      if (lockSec) {
        // Claim count label
        var claimsCountEl = document.getElementById("bhvd-r-claims-count");
        if (claimsCountEl) {
          if (totalClaims > 0 && flaggedCount > 0) {
            claimsCountEl.innerHTML = totalClaims + " analyzed &middot; <span style='color:#e74c3c'>" + flaggedCount + " flagged</span>";
          } else if (flaggedCount > 0) {
            claimsCountEl.innerHTML = "<span style='color:#e74c3c'>" + flaggedCount + " flagged</span>";
          } else if (totalClaims > 0) {
            claimsCountEl.textContent = totalClaims + " reviewed";
          }
        }

        // Ghost claim cards
        var ghostEl = document.getElementById("bhvd-r-ghost-claims");
        if (ghostEl) {
          var ghostPool = gapsOrPartial.length ? gapsOrPartial : (gapMap.length ? gapMap : []);
          var ghostHtml = "";
          if (ghostPool.length > 0) {
            ghostPool.slice(0, 2).forEach(function(c, i) {
              var dotC = c.status === "gap" ? "#e74c3c" : c.status === "partial" ? "#f39c12" : verdictC;
              ghostHtml += '<div class="bhvd-r-ghost-card" style="' + (i === 1 ? "opacity:0.35;" : "") + '">' +
                '<span class="bhvd-r-ghost-dot" style="background:' + dotC + '"></span>' +
                '<span class="bhvd-r-ghost-text">"' + _esc(truncateWords(c.claim || "", 12)) + '"</span>' +
              '</div>';
            });
          } else if (reasons.length) {
            reasons.slice(0, 2).forEach(function(txt, i) {
              ghostHtml += '<div class="bhvd-r-ghost-card" style="' + (i === 1 ? "opacity:0.35;" : "") + '">' +
                '<span class="bhvd-r-ghost-dot" style="background:' + verdictC + '"></span>' +
                '<span class="bhvd-r-ghost-text">' + _esc(txt.slice(0, 80)) + '</span>' +
              '</div>';
            });
          } else {
            ghostHtml = '<div class="bhvd-r-ghost-card"><span class="bhvd-r-ghost-dot" style="background:' + verdictC + '"></span><span class="bhvd-r-ghost-text">Marketing claims analyzed against visible evidence…</span></div>';
          }
          ghostEl.innerHTML = ghostHtml;
        }

        var lockBtn = document.getElementById("bhvd-r-lock-btn");
        if (lockBtn) lockBtn.onclick = function() {
          window.open("https://trynorm.co/pricing?source=extension", "_blank");
        };

        lockSec.style.display = "block";
      }
    }

    document.getElementById("bhvd-result").style.display = "block";
    // panel stays closed — user opens it by clicking the tab
  }

  var _pollTimer  = null;
  var _scanned    = false;

  function isWellnessPage() {
    var host = window.location.hostname.replace(/^www\./, "");
    for (var i = 0; i < KNOWN_DOMAINS.length; i++) {
      if (host === KNOWN_DOMAINS[i] || host.endsWith("." + KNOWN_DOMAINS[i])) return true;
    }
    var text = (document.title + " " + document.body.innerText.slice(0, 2000)).toLowerCase();
    var kw = ["supplement","vitamin","nootropic","adaptogen","skincare","serum","wearable",
              "sleep tracker","fitness tracker","probiotic","collagen","creatine","ashwagandha",
              "neurostimulation","brain stimulation","biohacking","longevity","biomarker",
              "recovery","gut health","hormone","cortisol","melatonin","electrolyte",
              "greens powder","protein powder","pre-workout","immune support","red light",
              "infrared","sauna","pemf","heart rate","hrv","spo2","circadian","rem sleep",
              "clinically proven","third party tested","fda cleared","supplement facts",
              // neurotech / sleep devices
              "eeg","neurofeedback","brain waves","brainwave","sleep quality","deep sleep",
              "sleep stages","cognitive performance","cognitive enhancement","neural",
              "transcranial","tDCS","neurostimul","audio stimulation","sleep score",
              // broader wellness signals
              "cognitive","mental performance","stress relief","mood support",
              "clinical study","clinical trial","peer reviewed","randomized controlled"];
    for (var j = 0; j < kw.length; j++) {
      if (text.indexOf(kw[j]) !== -1) return true;
    }
    return false;
  }

  var _HIGH = ["clinically proven","scientifically proven","proven to","guaranteed",
               "eliminates","reverses","100% effective","treats","cures","prevents disease"];
  var _MED  = ["improves","boosts","enhances","reduces","optimizes","supports","promotes",
               "strengthens","increases","helps","designed to","formulated to","shown to"];

  function _extractPageClaims(text) {
    var claims = [];
    var seen = {};
    var lines = text.split(/[\n.!?]+/);
    for (var i = 0; i < lines.length && claims.length < 25; i++) {
      var line = lines[i].trim();
      if (line.length < 12 || line.length > 350) continue;
      var key = line.slice(0, 50).toLowerCase().replace(/\s+/g, " ");
      if (seen[key]) continue;
      var ll = line.toLowerCase();
      var intensity = "low";
      for (var h = 0; h < _HIGH.length; h++) { if (ll.indexOf(_HIGH[h]) !== -1) { intensity = "high"; break; } }
      if (intensity === "low") {
        for (var m = 0; m < _MED.length; m++) { if (ll.indexOf(_MED[m]) !== -1) { intensity = "medium"; break; } }
      }
      if (intensity !== "low") { seen[key] = true; claims.push({ text: line.slice(0, 250), zone: "body", intensity: intensity }); }
    }
    return claims;
  }

  function triggerScan() {
    if (_scanned) return;
    _scanned = true;
    showScanning();
    var _currentUrl = window.location.href;
    var _scanDone = false;

    // Fallback: if no provisional result within 12s, show submit state
    var _scanTimeout = setTimeout(function() {
      if (!_scanDone) showUnscored(_currentUrl);
    }, 12000);

    var pageText = document.body ? document.body.innerText.slice(0, 6000) : "";
    var extractedClaims = _extractPageClaims(pageText);
    var studyLinks = 0;
    var links = document.querySelectorAll("a[href]");
    for (var li = 0; li < links.length; li++) {
      var href = (links[li].href || "").toLowerCase();
      if (href.indexOf("pubmed") !== -1 || href.indexOf("doi.org") !== -1 || href.indexOf("ncbi") !== -1) studyLinks++;
    }
    var extractedEvidence = studyLinks > 0 ? [{ type: "study_links", count: studyLinks }] : [];

    chrome.runtime.sendMessage({
      type: "SCAN_URL",
      payload: {
        url: _currentUrl,
        page_text: pageText,
        claims: extractedClaims,
        evidence: extractedEvidence,
        product_info: {
          productName: document.title.split("|")[0].split("-")[0].trim(),
          brandName:   "",
          pageUrl:     _currentUrl
        }
      }
    }, function(d) {
      clearTimeout(_scanTimeout);
      _scanDone = true;
      if (chrome.runtime.lastError) { showUnscored(_currentUrl); return; }
      var hasSignal = d && d.success && d.data && d.data.signal_color && !d.data.is_provisional;
      var isUnverifiable = d && d.success && d.data && d.data.leaderboard_data && d.data.leaderboard_data.scrape_status === "unverifiable";
      if (hasSignal) {
        showResult(d.data);
      } else if (isUnverifiable) {
        showUnverifiable();
      } else {
        showUnscored(_currentUrl);
      }
    });
  }

  // Track captured URLs in sessionStorage so we don't re-send same page in same session
  function _alreadyCaptured(url) {
    try {
      var key = "bhvd_captured";
      var captured = JSON.parse(sessionStorage.getItem(key) || "[]");
      var clean = url.split("?")[0].split("#")[0];
      if (captured.indexOf(clean) !== -1) return true;
      captured.push(clean);
      if (captured.length > 30) captured = captured.slice(-30);
      sessionStorage.setItem(key, JSON.stringify(captured));
      return false;
    } catch(_) { return false; }
  }

  // Always capture DOM on wellness pages — scored or not.
  // This feeds the aggregation pipeline so every page visit enriches brand data.
  function captureCurrentPage(url) {
    if (_isBlockedPath(url)) return;
    if (_alreadyCaptured(url)) return;
    var domText = document.body ? document.body.innerText : "";
    if (!domText || domText.length < 300) return;
    var safeText = _stripPii(domText.slice(0, 50000));
    chrome.runtime.sendMessage({ type: "DOM_CAPTURE", url: url, dom_text: safeText }, function() {
      if (chrome.runtime.lastError) {} // silent
    });
  }

  function poll(count) {
    if (count > 10) return;
    chrome.runtime.sendMessage({ type: "LOOKUP_URL", url: window.location.href }, function(d) {
      if (chrome.runtime.lastError) {
        _pollTimer = setTimeout(function() { poll(count + 1); }, 5000);
        return;
      }
      var currentUrl = window.location.href;
      if (d && d.status === "found" && d.data && d.data.leaderboard_data && d.data.leaderboard_data.scrape_status === "unverifiable") {
        showUnverifiable();
        // Still capture — site was unverifiable via crawler but user's browser can read it
        if (isWellnessPage()) captureCurrentPage(currentUrl);
      } else if (d && d.status === "found" && d.data && d.data.signal_color && !d.data.is_provisional) {
        showResult(d.data);
        // Capture enrichment data — scored brands benefit from more real-browser page coverage
        if (isWellnessPage()) captureCurrentPage(currentUrl);
      } else if (count === 0 && isWellnessPage()) {
        var snapUrl = currentUrl;
        if (!_isBlockedPath(snapUrl)) {
          var snapText    = document.body ? document.body.innerText.slice(0, 6000) : "";
          var snapClaims  = _extractPageClaims(snapText);
          var snapEvLinks = document.querySelectorAll('a[href*="pubmed"],a[href*="doi.org"],a[href*="ncbi.nlm"]').length;
          showNotYetAssessed(snapClaims.length, snapEvLinks, snapUrl);
          captureCurrentPage(snapUrl);
        }
      } else if (_scanned) {
        _pollTimer = setTimeout(function() { poll(count + 1); }, 5000);
      }
    });
  }

  chrome.runtime.onMessage.addListener(function(msg) {
    if (!msg) return;
    if (msg.type === "BHVD_SCANNING") showScanning();
    if (msg.type === "BHVD_RESULT" && msg.result && !msg.result.is_provisional) {
      clearTimeout(_pollTimer);
      showResult(msg.result);
    }
  });

  poll(0);

})();
