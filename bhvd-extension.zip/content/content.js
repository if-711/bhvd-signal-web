// BHVD Signal — Content Script v2
// Aggressive detection — fires on any page with wellness keywords

(function () {
  "use strict";

  if (window.__bhvd_ran) return;
  window.__bhvd_ran = true;

  // Known domains — always trigger regardless of keyword matching
  var KNOWN_DOMAINS = [
    "ag1.com","ritual.com","thorne.com","onnit.com","whoop.com","ouraring.com",
    "joovv.com","therabody.com","hyperice.com","neurohacker.com","eightsleep.com",
    "momentouslabs.com","bulletproof.com","foursigmatic.com","higherdose.com",
    "mindbodygreen.com","goop.com","hims.com","hers.com","ro.co","hone.health",
    "athletic-greens.com","drinkag1.com","levelshealth.com","insidetracker.com",
    "noom.com","whoop.com","garmin.com","fitbit.com","oura.com",
    "soundhealth.life","sonus.com","somnox.com","bose.com","kokoon.com",
    "soundcore.com","yogasleep.com","endel.io","noisli.com"
  ];

  var WELLNESS_KEYWORDS = [
    // supplements & nutrition
    "supplement","vitamin","probiotic","collagen","omega","magnesium",
    "ashwagandha","creatine","whey","protein powder","nootropic","adaptogen",
    "electrolyte","greens powder","mushroom coffee","pre-workout","amino acid",
    "melatonin","sleep aid","immune support","gut health","microbiome",
    // skincare & beauty
    "skincare","serum","moisturizer","retinol","niacinamide","sunscreen","peptide",
    // devices & wearables
    "red light","infrared","massage gun","sauna","pemf","compression",
    "wearable","sleep tracker","fitness tracker","heart rate","hrv",
    "sleep stages","rem sleep","readiness","blood oxygen","spo2","circadian",
    "continuous monitoring","health metrics","biometric","wellness score",
    // neuro / brain / biohacking
    "neurostimulation","neurofeedback","brain stimulation","transcranial",
    "cognitive performance","brain health","brainwave","neural","eeg headband",
    "biohacking","longevity","lifespan","healthspan","biomarker",
    // trust signals
    "clinically proven","scientifically proven","doctor recommended",
    "third party tested","nsf certified","informed sport","non-gmo",
    "serving size","supplement facts","daily value",
    "fda cleared","fda approved","ce marked","iso certified",
    // general wellness
    "recovery","inflammation","cortisol","hormone","testosterone",
    "weight loss","fat burn","metabolism","detox","cleanse"
  ];

  var HIGH_INTENSITY = [
    "clinically proven","scientifically proven","guaranteed","doctor approved",
    "proven to","reverses","eliminates","instant results","100% effective",
    "rewires","transforms","medically reviewed"
  ];

  var MED_INTENSITY = [
    "improves","boosts","enhances","increases","reduces","optimizes",
    "supports","promotes","strengthens","formulated for","designed to"
  ];

  function isWellnessPage() {
    var host = window.location.hostname.replace(/^www\./, "");
    // Known domain — always trigger
    for (var d = 0; d < KNOWN_DOMAINS.length; d++) {
      if (host === KNOWN_DOMAINS[d] || host.endsWith("." + KNOWN_DOMAINS[d])) return true;
    }
    // Keyword fallback for unknown domains
    var text = (
      document.title + " " +
      window.location.href + " " +
      (document.querySelector('meta[name="description"]') ?
        document.querySelector('meta[name="description"]').content : "") + " " +
      (document.body ? document.body.innerText.slice(0, 3000) : "")
    ).toLowerCase();

    for (var i = 0; i < WELLNESS_KEYWORDS.length; i++) {
      if (text.indexOf(WELLNESS_KEYWORDS[i]) !== -1) return true;
    }
    return false;
  }

  function extractClaims() {
    var claims = [];
    var seen = {};
    var els = document.querySelectorAll("h1,h2,h3,h4,li,p,span,div,td,th,strong,em,b");
    var count = 0;

    // Also grab meta description and title
    var metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc && metaDesc.content) {
      var metaText = metaDesc.content.trim();
      if (metaText.length > 10) {
        var lower = metaText.toLowerCase();
        var intensity = "low";
        for (var h = 0; h < HIGH_INTENSITY.length; h++) {
          if (lower.indexOf(HIGH_INTENSITY[h]) !== -1) { intensity = "high"; break; }
        }
        if (intensity === "low") {
          for (var m = 0; m < MED_INTENSITY.length; m++) {
            if (lower.indexOf(MED_INTENSITY[m]) !== -1) { intensity = "medium"; break; }
          }
        }
        if (intensity !== "low") {
          claims.push({ text: metaText.slice(0, 250), zone: "meta", intensity: intensity });
          count++;
        }
      }
    }

    for (var i = 0; i < els.length && count < 60; i++) {
      var el = els[i];
      if (el.children.length > 5) continue;
      var text = (el.innerText || el.textContent || "").trim();
      if (!text || text.length < 8 || text.length > 400) continue;
      var key = text.slice(0, 60);
      if (seen[key]) continue;
      seen[key] = true;

      var lower = text.toLowerCase();
      var intensity = "low";
      for (var h = 0; h < HIGH_INTENSITY.length; h++) {
        if (lower.indexOf(HIGH_INTENSITY[h]) !== -1) { intensity = "high"; break; }
      }
      if (intensity === "low") {
        for (var m = 0; m < MED_INTENSITY.length; m++) {
          if (lower.indexOf(MED_INTENSITY[m]) !== -1) { intensity = "medium"; break; }
        }
      }

      // Determine zone based on element position
      var zone = "body";
      var tag = el.tagName.toLowerCase();
      if (tag === "h1") zone = "hero";
      else if (tag === "h2" || tag === "h3") zone = "section";
      else if (tag === "li") zone = "bullets";

      if (intensity !== "low") {
        claims.push({ text: text.slice(0, 300), zone: zone, intensity: intensity });
        count++;
      }
    }
    return claims;
  }

  function extractEvidence() {
    var evidence = [];
    var text = document.body ? document.body.innerText.toLowerCase() : "";
    var links = document.querySelectorAll("a[href]");
    var studyLinks = 0;
    for (var i = 0; i < links.length; i++) {
      var href = (links[i].href || "").toLowerCase();
      if (href.indexOf("pubmed") !== -1 || href.indexOf("ncbi") !== -1 ||
          href.indexOf("doi.org") !== -1) studyLinks++;
    }
    if (studyLinks > 0) evidence.push({ type: "study_links", count: studyLinks });
    if (/nsf|informed sport|usp verified|third.party tested/.test(text))
      evidence.push({ type: "certification" });
    if (/supplement facts|serving size/.test(text))
      evidence.push({ type: "supplement_facts" });
    return evidence;
  }

  function getProductInfo() {
    function og(n) {
      var el = document.querySelector('meta[property="og:' + n + '"]');
      return el ? (el.content || "").trim() : "";
    }
    return {
      productName: og("title") || document.title.split("|")[0].split("-")[0].trim(),
      brandName:   og("site_name") || "",
      pageUrl:     window.location.href,
    };
  }

  var BLOCKED_PATHS = [
    "/checkout","/cart","/account","/order","/orders","/login","/signin",
    "/signup","/register","/profile","/subscription","/billing","/payment",
    "/my-","/my/","/purchases","/history","/address","/settings","/security",
    "/forgot-password","/reset-password","/2fa","/verify"
  ];

  function isBlockedPath() {
    var path = window.location.pathname.toLowerCase();
    for (var i = 0; i < BLOCKED_PATHS.length; i++) {
      if (path === BLOCKED_PATHS[i] || path.startsWith(BLOCKED_PATHS[i] + "/") || path.startsWith(BLOCKED_PATHS[i])) return true;
    }
    return false;
  }

  function run() {
    console.log("[BHVD] Content script running on:", window.location.href);

    if (isBlockedPath()) {
      console.log("[BHVD] Blocked path, skipping:", window.location.pathname);
      return;
    }

    if (!isWellnessPage()) {
      console.log("[BHVD] Not a wellness page, skipping");
      return;
    }

    console.log("[BHVD] Wellness page detected, sending to background");

    var data = {
      type:        "PAGE_CONTENT",
      url:         window.location.href,
      productInfo: getProductInfo(),
      claims:      extractClaims(),
      evidence:    extractEvidence(),
      pageText:    document.body ? document.body.innerText.slice(0, 6000) : "",
      timestamp:   Date.now()
    };

    try {
      chrome.runtime.sendMessage(data, function(response) {
        if (chrome.runtime.lastError) {
          console.log("[BHVD] Message error:", chrome.runtime.lastError.message);
        } else {
          console.log("[BHVD] Background responded:", response);
        }
      });
    } catch(e) {
      console.log("[BHVD] Send error:", e);
    }
  }

  // Run after page loads
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function() { setTimeout(run, 1500); });
  } else {
    setTimeout(run, 1500);
  }

  chrome.runtime.onMessage.addListener(function(msg) {
    if (msg && msg.type === "RESCAN") run();
  });

})();
