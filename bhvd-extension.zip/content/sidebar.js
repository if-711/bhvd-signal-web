// NORM — Injected Sidebar v4
// Redesigned: score front-and-center, dimension bars, evidence metrics, verdict badge

(function () {
  "use strict";
  if (document.getElementById("bhvd-signal-sidebar")) return;

  var API_URL = "https://bhvd-signal-api.fly.dev";

  var SHARE_COLOR_LABEL = { green: "Green ✓", yellow: "Yellow ⚠", red: "Red ✕" };
  var X_LIMIT = 280;

  function toBrandHashtag(name) {
    if (!name) return "";
    var words = name.split(/[\s\-_.,!?&+()\/'"“”]+/).filter(Boolean);
    var tag = words.map(function(w) {
      if (w.length > 1 && w === w.toUpperCase() && /[A-Z]/.test(w)) return w;
      return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
    }).join("");
    return "#" + tag;
  }

  function brandHandle(name, domain) {
    var base = (domain || "").replace(/^www\./, "").replace(/\.[^.]+$/, "").replace(/-/g, "");
    return "@" + (base || name.toLowerCase().replace(/[^a-z0-9]/g, ""));
  }

  function buildShareTweet(brandName, signalColor, summary, url, score, domain) {
    var handle  = brandHandle(brandName, domain);
    var hooks   = ["Thinking about " + brandName + "?", "Before you buy " + brandName + " —", "Quick check on " + brandName + " —"];
    var runLines = ["I ran this through NORM.", "Checked it on NORM.", "Pulled the NORM rating."];
    var features = ["He runs on any product page automatically.", "No digging required — NORM does it.", "Ask him before you buy anything."];
    var hook    = hooks[Math.floor(Math.random() * hooks.length)];
    var runLine = runLines[Math.floor(Math.random() * runLines.length)];
    var feature = features[Math.floor(Math.random() * features.length)];
    var scoreStr = score != null ? "Score: " + score + "/100" : "Rating: see below";
    return (
      hook + "\n\n" +
      scoreStr + "\n\n" +
      runLine + "\n\n" +
      "You can actually see whether this brand backs up what it claims.\n\n" +
      feature + "\n\n" +
      handle + " " + (url || "https://trynorm.co") + "\n\n" +
      "#normcheck"
    );
  }

  function logDemandEvent(domain, eventType) {
    if (!domain) return;
    fetch(API_URL + "/api/event", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ domain: domain, event_type: eventType }),
    }).catch(function() {});
  }

  var KNOWN_DOMAINS = [
    "ag1.com","ritual.com","thorne.com","onnit.com","whoop.com","ouraring.com",
    "joovv.com","therabody.com","hyperice.com","neurohacker.com","eightsleep.com",
    "momentouslabs.com","bulletproof.com","foursigmatic.com","higherdose.com",
    "mindbodygreen.com","goop.com","hims.com","hers.com","ro.co","hone.health",
    "athletic-greens.com","drinkag1.com","levelshealth.com","insidetracker.com",
    "noom.com","garmin.com","fitbit.com","oura.com",
    // neurotech
    "elemindtech.com","elemind.com","neurosity.co","muse-eeg.com","choosemuse.com",
    "emotiv.com","brainco.tech","kernel.com","flowneuro.com","narbis.com",
    "trustedsource.com","halo.sport","humm.com","myndlift.com",
    // sleep & recovery / sound wellness
    "dreem.com","kokoon.com","bose.com","sleepme.com","chilisleep.com","ooler.com",
    "sleepnumber.com","casper.com","helix.com","saatva.com",
    "soundhealth.life","sonus.com","somnox.com","kokoon.com","soundcore.com",
    "yogasleep.com","endel.io","noisli.com",
    // additional supplement/wellness
    "rawgarden.com","momentous.com","pendulum.life","seed.com","ritual.com","care/of",
    "athletic-greens.com","ag1.com","organifi.com","sunwarrior.com","vitalproteins.com",
    "blueprint.bryanjohnson.com","bryanjohnson.co"
  ];

  function isKnownWellnessDomain() {
    var host = window.location.hostname.replace(/^www\./, "");
    for (var i = 0; i < KNOWN_DOMAINS.length; i++) {
      if (host === KNOWN_DOMAINS[i] || host.endsWith("." + KNOWN_DOMAINS[i])) return true;
    }
    return false;
  }

  var BLOB = "M25.9998 0C28.1731 0 29.9538 1.72582 30.0217 3.8981C30.1312 7.40731 33.1026 10.2196 35.1071 13.102C36.0252 14.4222 36.5452 16.038 36.4956 17.7728L36.2914 24.9228C36.1757 28.9731 33.5493 32.7567 33.2607 36.7983L32.6148 45.8407C32.3669 49.3111 29.4792 52 26 52C22.5207 52 19.633 49.3112 19.3851 45.8407L18.7391 36.7982C18.4504 32.7566 15.8242 28.9731 15.7085 24.9228L15.5041 17.7728C15.4545 16.0382 15.9744 14.4226 16.8924 13.1025C18.8968 10.2198 21.8683 7.4075 21.9781 3.8981C22.046 1.72584 23.8265 3.83946e-05 25.9998 0Z";

  var SIG = {
    red:    { bg:"#120808", bd:"#5a1a1a", c:"#e74c3c", label:"Red",    verdict:"Marketing claims extend materially beyond the visible evidence base" },
    yellow: { bg:"#110e04", bd:"#5a3a0a", c:"#f39c12", label:"Yellow", verdict:"Some claims lack visible support"          },
    green:  { bg:"#060f08", bd:"#1a4a2a", c:"#27ae60", label:"Green",  verdict:"Claims align with visible evidence"        },
  };

  // New verdict names — primary
  var VERDICT_COLOR = {
    "ALIGNED":"#27ae60","VALIDATED":"#2ecc71","GENERALLY ALIGNED":"#f39c12",
    "PARTIALLY ALIGNED":"#e67e22","OVEREXTENDED":"#e74c3c","EVIDENCE GAP":"#922b21",
    // Legacy backward compat for old DB records — remap to current names
    "INFLATED":"#e74c3c","HIGH CLAIM RISK":"#922b21",
    "REAL":"#27ae60","TIGHT":"#2ecc71","CREDIBLE":"#f39c12",
    "SOFT":"#e67e22","STRETCHED":"#e74c3c","HYPE":"#e74c3c","RED FLAG":"#922b21"
  };

  var VERDICT_LABEL = {
    "ALIGNED":"Green","VALIDATED":"Green","GENERALLY ALIGNED":"Yellow",
    "PARTIALLY ALIGNED":"Yellow","OVEREXTENDED":"Red","EVIDENCE GAP":"Red",
    // Legacy → same mapping
    "INFLATED":"Red","HIGH CLAIM RISK":"Red",
    "REAL":"Green","TIGHT":"Green","CREDIBLE":"Yellow",
    "SOFT":"Yellow","STRETCHED":"Red","HYPE":"Red","RED FLAG":"Red"
  };

  var STYLES = `
    #bhvd-signal-sidebar * { box-sizing:border-box; margin:0; padding:0; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; -webkit-font-smoothing:antialiased; }

    /* Tab — independently fixed so panel layout never affects its position */
    @keyframes bhvd-tab-in { from{opacity:0;transform:scale(0.7)} to{opacity:1;transform:scale(1)} }
    #bhvd-tab { position:fixed; right:24px; bottom:28px; z-index:2147483647; width:58px; height:58px; border-radius:50%; display:flex; align-items:center; justify-content:center; cursor:pointer; border:1px solid rgba(255,255,255,0.10); padding:0; box-shadow:0 8px 32px rgba(0,0,0,0.7); background:#07080e; transition:transform .15s ease; animation:bhvd-tab-in .4s cubic-bezier(.34,1.56,.64,1) both; }
    #bhvd-tab:hover { transform:scale(1.08); }
    #bhvd-tab-blob { flex-shrink:0; color:#1e2440; transition:color .4s; }
    #bhvd-blob-path { display:none; }
    #bhvd-tab-label { display:none; }

    /* Scanning pulse */
    @keyframes bhvd-pulse { 0%,100%{opacity:1} 50%{opacity:.2} }

    /* Glow animations */
    @keyframes bhvd-glow-dormant {
      0%,100% { filter: drop-shadow(0 0 3px rgba(42,48,100,0.3)); }
      50%      { filter: drop-shadow(0 0 9px rgba(58,66,130,0.7)); }
    }
    @keyframes bhvd-glow-red {
      0%,100% { filter: drop-shadow(0 0 4px rgba(231,76,60,0.35)); }
      50%      { filter: drop-shadow(0 0 16px rgba(231,76,60,1)) drop-shadow(0 0 5px rgba(231,76,60,0.6)); }
    }
    @keyframes bhvd-glow-yellow {
      0%,100% { filter: drop-shadow(0 0 4px rgba(243,156,18,0.35)); }
      50%      { filter: drop-shadow(0 0 16px rgba(243,156,18,1)) drop-shadow(0 0 5px rgba(243,156,18,0.6)); }
    }
    @keyframes bhvd-glow-green {
      0%,100% { filter: drop-shadow(0 0 4px rgba(39,174,96,0.35)); }
      50%      { filter: drop-shadow(0 0 16px rgba(39,174,96,1)) drop-shadow(0 0 5px rgba(39,174,96,0.6)); }
    }

    /* Hover card */
    #bhvd-hover-card { position:absolute; right:68px; bottom:0; background:#0d1022; border:1px solid rgba(255,255,255,0.1); border-radius:12px; padding:12px 15px; width:180px; display:none; pointer-events:none; box-shadow:-4px 4px 24px rgba(0,0,0,0.7); z-index:2147483648; }
    #bhvd-tab:hover #bhvd-hover-card { display:block; }
    .bhvd-hc-title { font-size:12px; font-weight:700; margin-bottom:4px; }
    .bhvd-hc-sub { font-size:10px; color:#7a82a0; line-height:1.45; }

    /* Panel — independently fixed, never affects tab position */
    @keyframes bhvd-panel-in { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
    #bhvd-panel { position:fixed; right:80px; bottom:100px; z-index:2147483646; width:0; overflow:hidden; transition:width .3s cubic-bezier(.22,1,.36,1); }
    #bhvd-panel.open { width:368px; animation:bhvd-panel-in .3s cubic-bezier(.22,1,.36,1) both; }
    #bhvd-panel-inner { width:368px; background:#07080e; border:1px solid rgba(255,255,255,0.08); border-radius:16px; overflow:hidden; height:auto; box-shadow:-12px 0 48px rgba(0,0,0,0.7); }
    #bhvd-panel-inner::-webkit-scrollbar { width:3px; }
    #bhvd-panel-inner::-webkit-scrollbar-thumb { background:rgba(255,255,255,0.06); border-radius:3px; }

    /* Header */
    .bhvd-hdr { padding:11px 22px; display:flex; align-items:center; justify-content:space-between; border-bottom:1px solid rgba(255,255,255,0.06); background:rgba(4,5,12,0.98); backdrop-filter:blur(12px); position:sticky; top:0; z-index:2; }
    .bhvd-hdr-logo { display:flex; align-items:center; gap:10px; font-size:9px; font-weight:800; letter-spacing:.16em; color:#6a7298; font-family:monospace; text-transform:uppercase; }
    .bhvd-close { background:none; border:none; color:#5a6288; font-size:20px; cursor:pointer; line-height:1; padding:4px 6px; border-radius:6px; transition:all .15s; }
    .bhvd-close:hover { color:#d0d8f0; background:rgba(255,255,255,0.06); }

    /* States */
    #bhvd-scanning { padding:52px 32px; text-align:center; display:none; }
    .bhvd-spin { width:30px; height:30px; border-radius:50%; border:2px solid rgba(255,255,255,0.05); border-top-color:#4a5272; animation:bhvd-spin .8s linear infinite; margin:0 auto 16px; }
    @keyframes bhvd-spin { to{transform:rotate(360deg)} }
    .bhvd-scan-txt { font-size:13px; color:#8892b0; font-weight:500; }
    .bhvd-scan-sub { font-size:11px; color:#5a6280; margin-top:6px; }
    #bhvd-unscored { padding:44px 32px; text-align:center; display:none; }
    .bhvd-us-icon { font-size:26px; margin-bottom:14px; color:#5a6280; }
    .bhvd-us-title { font-size:14px; font-weight:700; color:#d0d8f0; margin-bottom:8px; }
    .bhvd-us-body { font-size:12px; color:#8892b0; line-height:1.7; margin-bottom:18px; }
    .bhvd-snapshot-box { background:rgba(255,255,255,0.025); border:1px solid rgba(255,255,255,0.06); border-radius:10px; padding:16px 18px; margin:0 0 16px; text-align:left; }
    .bhvd-snapshot-row { display:flex; align-items:center; gap:12px; padding:4px 0; }
    .bhvd-snapshot-num { font-size:20px; font-weight:800; color:#c0c8e0; font-family:monospace; min-width:28px; }
    .bhvd-snapshot-lbl { font-size:11px; color:#7a82a0; }
    .bhvd-add-note { font-size:10px; color:#4a5272; line-height:1.65; border-top:1px solid rgba(255,255,255,0.05); padding-top:14px; margin-top:4px; }

    /* Unverifiable state */
    #bhvd-unverifiable { padding:44px 32px; text-align:center; display:none; }

    /* Low data integrity — cannot assess reliably */
    #bhvd-limited-data { padding:44px 32px; text-align:center; display:none; }
    /* Pending review — public_safe = false */
    #bhvd-pending { padding:44px 32px; text-align:center; display:none; }
    /* Legacy suppressed state */
    #bhvd-suppressed { padding:44px 32px; text-align:center; display:none; }
    .bhvd-uv-icon { font-size:24px; margin-bottom:14px; color:#4a5272; }
    .bhvd-uv-title { font-size:14px; font-weight:700; color:#d0d8f0; margin-bottom:8px; }
    .bhvd-uv-body { font-size:12px; color:#8892b0; line-height:1.7; }
    .bhvd-uv-note { font-size:10px; color:#4a5272; margin-top:16px; line-height:1.6; border-top:1px solid rgba(255,255,255,0.05); padding-top:16px; }

    /* Result */
    #bhvd-result { display:none; }

    /* Hero — verdict-first layout */
    .bhvd-hero { padding:11px 22px 10px; border-bottom:1px solid rgba(255,255,255,0.06); position:relative; }
    .bhvd-hero-top { display:flex; flex-direction:column; gap:8px; margin-bottom:8px; padding-right:44px; }

    /* Score circle — secondary role */
    .bhvd-score-circle { width:44px; height:44px; border-radius:12px; display:block; position:relative; flex-shrink:0; border:1.5px solid; overflow:hidden; }
    .bhvd-score-num { position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); font-size:18px; font-weight:900; line-height:1; font-family:monospace; letter-spacing:-.03em; white-space:nowrap; }
    .bhvd-score-denom { display:none; }

    /* Score + brand inline row (secondary) */
    .bhvd-score-row { display:flex; align-items:center; gap:12px; }
    .bhvd-hero-meta { flex:1; min-width:0; padding-right:38px; }
    .bhvd-brand-name { font-size:13px; font-weight:600; color:#6a7295; line-height:1.2; word-break:break-word; }
    /* Verdict badge — primary headline, large */
    .bhvd-verdict-badge { display:inline-flex; align-items:center; padding:7px 16px; border-radius:10px; font-size:20px; font-weight:900; letter-spacing:-.02em; border:1.5px solid; line-height:1.2; }
    .bhvd-hero-sub { font-size:10px; color:#5a6285; margin-top:2px; text-transform:capitalize; letter-spacing:.01em; }

    /* Share icon */
    .bhvd-share-icon { position:absolute; top:16px; right:22px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.09); border-radius:9px; color:#4a5272; cursor:pointer; padding:8px 9px; line-height:0; display:flex; align-items:center; justify-content:center; transition:all .15s; }
    .bhvd-share-icon:hover { background:rgba(255,255,255,0.09); color:#c0c8e0; border-color:rgba(255,255,255,0.18); }

    /* Punchline — plain-English summary, clamped to 3 lines */
    .bhvd-punchline { font-size:12.5px; color:#8892b0; line-height:1.55; border-top:1px solid rgba(255,255,255,0.06); padding-top:8px; display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden; }

    /* Claim preview — worst claims visible on overview without tab click */
    #bhvd-claim-preview { padding:0 22px 8px; }
    .bhvd-cp-label { font-size:9px; font-weight:800; letter-spacing:.16em; text-transform:uppercase; color:#3e4668; padding:7px 0 5px; border-top:1px solid rgba(255,255,255,0.05); }
    .bhvd-cp-item { display:flex; align-items:flex-start; gap:9px; padding:5px 0; }
    .bhvd-cp-status { font-size:8px; font-weight:800; letter-spacing:.06em; text-transform:uppercase; flex-shrink:0; padding:2px 6px; border-radius:3px; margin-top:3px; white-space:nowrap; line-height:1.4; }
    .bhvd-cp-status.gap     { color:#e74c3c; background:rgba(231,76,60,0.15); }
    .bhvd-cp-status.partial { color:#f39c12; background:rgba(243,156,18,0.12); }
    .bhvd-cp-status.aligned { color:#27ae60; background:rgba(39,174,96,0.10); }
    .bhvd-cp-text { font-size:11px; color:#b0b8d0; line-height:1.5; font-style:italic; flex:1; min-width:0; }
    .bhvd-cp-more { display:block; width:100%; text-align:center; font-size:10px; color:#3a78e0; padding:8px 0 2px; border:none; background:none; font-family:inherit; font-weight:600; cursor:pointer; letter-spacing:.02em; }
    .bhvd-cp-more:hover { color:#5a98ff; }

    /* Upgrade block — shown to free users below scoring dimensions */
    #bhvd-upgrade-block { padding:8px 22px 10px; }
    .bhvd-ug-inner { background:rgba(58,120,224,0.07); border:1px solid rgba(58,120,224,0.18); border-radius:10px; padding:10px 14px; display:flex; align-items:center; gap:12px; }
    .bhvd-ug-left { flex:1; min-width:0; }
    .bhvd-ug-title { font-size:11px; font-weight:700; color:#c0c8e0; margin-bottom:2px; }
    .bhvd-ug-body { font-size:10px; color:#6a7295; line-height:1.45; }
    .bhvd-ug-btn { flex-shrink:0; padding:7px 12px; background:#3a78e0; color:#fff; border:none; border-radius:7px; font-size:10.5px; font-weight:700; font-family:inherit; cursor:pointer; letter-spacing:.02em; text-align:center; text-decoration:none; white-space:nowrap; }
    .bhvd-ug-btn:hover { background:#5a98ff; }

    /* Data visibility bar — always shown when result is displayed */
    .bhvd-vis-bar { padding:6px 22px 5px; border-bottom:1px solid rgba(255,255,255,0.05); }
    .bhvd-vis-top { display:flex; align-items:center; gap:6px; font-size:10px; font-weight:700; letter-spacing:.07em; text-transform:uppercase; flex-wrap:wrap; }
    .bhvd-vis-icon { font-size:11px; }
    .bhvd-vis-sep { color:#2e3450; font-weight:400; }
    .bhvd-vis-meta { font-size:9.5px; font-weight:400; color:#5a6288; letter-spacing:.01em; text-transform:none; }
    .bhvd-vis-sub { font-size:9px; color:#454d6a; margin-top:4px; line-height:1.4; }
    .bhvd-vis-bar.high,   .bhvd-vis-bar.full    { }
    .bhvd-vis-bar.high   .bhvd-vis-icon, .bhvd-vis-bar.high   .bhvd-vis-level,
    .bhvd-vis-bar.full   .bhvd-vis-icon, .bhvd-vis-bar.full   .bhvd-vis-level { color:#27ae60; }
    .bhvd-vis-bar.medium .bhvd-vis-icon, .bhvd-vis-bar.medium .bhvd-vis-level,
    .bhvd-vis-bar.partial .bhvd-vis-icon, .bhvd-vis-bar.partial .bhvd-vis-level { color:#e67e22; }
    .bhvd-vis-bar.low    .bhvd-vis-icon, .bhvd-vis-bar.low    .bhvd-vis-level,
    .bhvd-vis-bar.limited .bhvd-vis-icon, .bhvd-vis-bar.limited .bhvd-vis-level { color:#6a7295; }

    /* Sections */
    .bhvd-sec { padding:8px 22px; border-bottom:1px solid rgba(255,255,255,0.06); }
    .bhvd-sec-title { font-size:8px; font-weight:800; letter-spacing:.2em; text-transform:uppercase; color:#7a84b8; margin-bottom:7px; display:flex; align-items:center; gap:8px; }
    .bhvd-sec-title::after { content:''; flex:1; height:1px; background:rgba(255,255,255,0.10); }

    /* Dimension bars */
    .bhvd-dim-row { display:flex; align-items:center; gap:10px; margin-bottom:5px; }
    .bhvd-dim-row:last-child { margin-bottom:0; }
    .bhvd-dim-name { font-size:11px; color:#9098b8; width:100px; flex-shrink:0; }
    .bhvd-dim-bar-wrap { flex:1; height:4px; border-radius:3px; }
    .bhvd-dim-score { font-size:10px; font-family:monospace; width:34px; text-align:right; flex-shrink:0; font-weight:700; color:#1a8fff; }

    /* Flags */
    .bhvd-flag-item { display:flex; align-items:flex-start; gap:12px; margin-bottom:12px; }
    .bhvd-flag-item:last-child { margin-bottom:0; }
    .bhvd-flag-dot { font-size:6px; flex-shrink:0; margin-top:5px; }
    .bhvd-flag-text { font-size:12px; color:#b8c0d8; line-height:1.65; }


    /* Rank */
    .bhvd-rank-row { display:flex; align-items:center; gap:12px; }
    .bhvd-rank-num { font-size:14px; font-weight:800; font-family:monospace; }
    .bhvd-rank-bar { flex:1; height:4px; background:#0e111e; border-radius:2px; overflow:hidden; }
    .bhvd-rank-fill { height:100%; border-radius:2px; }
    .bhvd-rank-sub { font-size:10px; color:#6a7295; margin-top:8px; }

    /* Meta strip */
    .bhvd-meta-strip { padding:12px 26px; border-bottom:1px solid rgba(255,255,255,0.04); display:flex; flex-wrap:wrap; align-items:center; gap:4px 10px; }
    .bhvd-meta-item { font-size:9px; color:#5e6888; white-space:nowrap; }
    .bhvd-meta-dot { color:#3e4660; font-size:8px; }

    /* Category Standing */
    #bhvd-standing-sec { padding:8px 22px; border-bottom:1px solid rgba(255,255,255,0.05); }
    .bhvd-standing-label { font-size:9px; color:#4a5280; font-weight:700; letter-spacing:.10em; text-transform:uppercase; margin-bottom:8px; }
    .bhvd-standing-row { display:flex; align-items:center; gap:10px; }
    .bhvd-standing-badge { font-size:11px; font-weight:600; flex-shrink:0; }
    .bhvd-standing-track { flex:1; height:4px; background:rgba(255,255,255,0.06); border-radius:2px; overflow:hidden; position:relative; }
    .bhvd-standing-fill { position:absolute; top:0; left:0; bottom:0; border-radius:2px; transition:width .6s cubic-bezier(.34,1.1,.64,1); }
    .bhvd-standing-pct { font-size:9px; color:#4a5280; font-family:monospace; flex-shrink:0; width:30px; text-align:right; }
    .bhvd-standing-sub { font-size:9.5px; color:#4a5280; margin-top:5px; line-height:1.5; }

    /* Share overlay */
    #bhvd-share-sheet { display:none; padding:26px 26px 28px; }
    @keyframes bhvd-share-up { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
    #bhvd-share-sheet.open { display:block; animation:bhvd-share-up .22s cubic-bezier(.22,1,.36,1) both; }
    .bhvd-share-hdr { font-size:9px; font-weight:800; letter-spacing:.2em; color:#4a5272; text-transform:uppercase; text-align:center; margin-bottom:16px; }
    .bhvd-share-card { background:#0b0d1a; border:1px solid rgba(255,255,255,0.07); border-radius:14px; padding:18px 18px 16px; margin-bottom:18px; }
    .bhvd-share-card-row { display:flex; align-items:flex-start; gap:14px; margin-bottom:12px; }
    .bhvd-share-card-score { font-size:34px; font-weight:900; font-family:monospace; line-height:1; letter-spacing:-.04em; flex-shrink:0; }
    .bhvd-share-card-score span { font-size:14px; opacity:.35; }
    .bhvd-share-card-right { flex:1; min-width:0; }
    .bhvd-share-card-name { font-size:15px; font-weight:800; color:#f0f2ff; letter-spacing:-.01em; line-height:1.2; }
    .bhvd-share-card-verdict { font-size:8px; font-weight:900; letter-spacing:.12em; margin-top:6px; display:inline-block; padding:3px 9px; border-radius:5px; border:1px solid; }
    .bhvd-share-card-note { font-size:10.5px; color:#6a7295; line-height:1.6; border-top:1px solid rgba(255,255,255,0.05); padding-top:12px; }
    .bhvd-share-actions { display:flex; flex-direction:column; gap:8px; margin-bottom:12px; }
    .bhvd-share-act { display:flex; align-items:center; gap:13px; padding:13px 16px; border-radius:11px; border:1px solid rgba(255,255,255,0.07); background:#0b0d1a; color:#c0c8e0; font-size:12.5px; font-weight:600; cursor:pointer; font-family:inherit; transition:all .15s; text-align:left; width:100%; }
    .bhvd-share-act:hover { background:#141828; border-color:rgba(255,255,255,0.14); color:#e0e8ff; }
    .bhvd-share-act.x-btn { background:#000; border-color:#1c1c1c; }
    .bhvd-share-act.x-btn:hover { background:#0d0d0d; border-color:#333; }
    .bhvd-share-act-icon { font-size:15px; width:20px; text-align:center; flex-shrink:0; line-height:1; }
    .bhvd-share-cancel { background:none; border:none; color:#8892b0; font-size:12px; cursor:pointer; width:100%; padding:12px; font-family:inherit; transition:color .15s; letter-spacing:.02em; }
    .bhvd-share-cancel:hover { color:#d0d8f0; }
    .bhvd-copy-ok { font-size:9px; color:#27ae60; text-align:center; padding:6px; display:none; }

    /* Unverified estimate strip */
    #bhvd-unverified-strip { display:none; padding:5px 22px; background:rgba(243,156,18,0.07); border-bottom:1px solid rgba(243,156,18,0.15); }
    .bhvd-unverified-row { display:flex; align-items:center; gap:7px; font-size:9.5px; font-weight:700; letter-spacing:.08em; text-transform:uppercase; color:#c8820a; }
    .bhvd-unverified-sub { font-size:9px; color:#7a6030; margin-top:2px; letter-spacing:.01em; font-weight:400; text-transform:none; }

    /* Assessment section — collapsible, legible header */
    #bhvd-flags-sec.collapsible { cursor:pointer; user-select:none; }
    #bhvd-flags-sec.collapsible .bhvd-sec-title { cursor:pointer; }
    #bhvd-assessment-toggle-icon { margin-left:5px; font-style:normal; font-size:10px; color:#7a84b8; font-weight:900; }
    #bhvd-flags-sec.collapsed #bhvd-assessment-body { display:none; }
    #bhvd-assessment-body { font-size:12px; color:#a0a8c8; line-height:1.6; }
    .bhvd-assess-verdict { margin-bottom:10px; }
    .bhvd-assess-strengths { font-size:11.5px; color:#4a9464; background:#061408; border:1px solid #1a4a2a; border-radius:6px; padding:7px 10px; margin-bottom:10px; line-height:1.6; }
    .bhvd-assess-strengths::before { content:"✓ "; font-weight:700; }
    .bhvd-gap-map { margin-top:10px; border-top:1px solid #1e2240; padding-top:10px; }
    .bhvd-gap-title { font-size:10px; color:#4a5280; font-weight:700; letter-spacing:.08em; text-transform:uppercase; margin-bottom:7px; }
    .bhvd-gap-row { display:flex; gap:8px; align-items:flex-start; margin-bottom:10px; }
    .bhvd-gap-dot { flex-shrink:0; width:7px; height:7px; border-radius:50%; margin-top:5px; }
    .bhvd-gap-dot.aligned { background:#27ae60; }
    .bhvd-gap-dot.partial  { background:#f39c12; }
    .bhvd-gap-dot.gap      { background:#e74c3c; }
    .bhvd-gap-dot.missing  { background:#555; }
    .bhvd-gap-body { flex:1; min-width:0; }
    .bhvd-gap-status { font-size:9.5px; font-weight:700; letter-spacing:.06em; text-transform:uppercase; margin-bottom:3px; }
    .bhvd-gap-status.gap     { color:#e74c3c; }
    .bhvd-gap-status.partial { color:#f39c12; }
    .bhvd-gap-status.aligned { color:#27ae60; }
    .bhvd-gap-status.missing { color:#555; }
    .bhvd-gap-claim { color:#d0d8f0; font-weight:600; font-size:12px; line-height:1.5; margin-bottom:3px; font-style:italic; }
    .bhvd-gap-evid  { color:#7a84a8; font-size:11px; line-height:1.55; }
    .bhvd-gap-row.gap .bhvd-gap-body { background:rgba(231,76,60,0.06); border-radius:5px; padding:5px 8px; }
    .bhvd-flagged-reasons { margin-top:10px; margin-bottom:8px; }
    .bhvd-flagged-reasons-title { font-size:10px; color:#4a5280; font-weight:700; letter-spacing:.08em; text-transform:uppercase; margin-bottom:6px; }
    .bhvd-flagged-reason { display:flex; gap:7px; align-items:flex-start; margin-bottom:5px; font-size:11.5px; color:#c0c8e0; line-height:1.55; }
    .bhvd-flagged-reason::before { content:"→"; color:#e74c3c; flex-shrink:0; font-weight:700; margin-top:1px; }
    .bhvd-assess-limitations { font-size:11.5px; color:#8a8aa8; background:#0e0e18; border:1px solid #2a2a40; border-radius:6px; padding:7px 10px; margin-bottom:10px; line-height:1.6; }
    .bhvd-assess-limitations::before { content:"⚠ "; color:#e05555; font-weight:700; }

    /* CTA */
    .bhvd-cta-sec { padding:8px 22px 10px; }
    .bhvd-cta-btn { display:block; width:100%; padding:11px; background:#0e1122; border:1px solid rgba(255,255,255,0.07); border-radius:10px; color:#b0b8d0; font-size:12px; font-weight:600; text-align:center; cursor:pointer; transition:all .15s; font-family:inherit; margin-bottom:7px; letter-spacing:.01em; }
    .bhvd-cta-btn:hover { background:#141828; border-color:rgba(255,255,255,0.14); color:#d0d8f0; }
    .bhvd-cta-btn.primary { background:#1a8fff; border-color:transparent; color:#fff; font-weight:700; letter-spacing:.02em; }
    .bhvd-cta-btn.primary:hover { background:#1480f0; }
    .bhvd-disc { font-size:9px; color:#5a6282; line-height:1.5; text-align:center; margin-top:8px; }
    /* Tabs */
    .bhvd-tabs { display:flex; border-bottom:1px solid #1a1e30; background:#080b14; }
    .bhvd-tab-btn { flex:1; padding:10px 0; font-size:9.5px; font-weight:700; letter-spacing:.09em; text-transform:uppercase; color:#3a4268; text-align:center; cursor:pointer; border:none; background:none; font-family:inherit; border-bottom:2px solid transparent; transition:color .15s,border-color .15s; }
    .bhvd-tab-btn.active { color:#c0c8e0; border-bottom-color:#1a8fff; }
    .bhvd-tab-btn:hover:not(.active) { color:#7a84a8; }
    .bhvd-tab-panel { display:none; }
    .bhvd-tab-panel.active { display:block; }
    /* Claim cards */
    .bhvd-claim-card { border:1px solid rgba(255,255,255,0.06); border-radius:8px; margin-bottom:8px; overflow:hidden; cursor:pointer; transition:border-color .15s; }
    .bhvd-claim-card:hover { border-color:rgba(255,255,255,0.12); }
    .bhvd-claim-card-head { display:flex; align-items:flex-start; gap:8px; padding:10px 12px; }
    .bhvd-claim-card-status { font-size:9px; font-weight:700; letter-spacing:.07em; text-transform:uppercase; flex-shrink:0; padding:2px 7px; border-radius:3px; margin-top:2px; white-space:nowrap; }
    .bhvd-claim-card-status.gap { color:#e74c3c; background:rgba(231,76,60,0.12); }
    .bhvd-claim-card-status.partial { color:#f39c12; background:rgba(243,156,18,0.12); }
    .bhvd-claim-card-status.aligned { color:#27ae60; background:rgba(39,174,96,0.12); }
    .bhvd-claim-card-status.missing { color:#555; background:rgba(100,100,100,0.12); }
    .bhvd-claim-card-text { font-size:11.5px; color:#c0c8e0; font-style:italic; line-height:1.5; flex:1; min-width:0; }
    .bhvd-claim-card-arrow { font-size:10px; color:#3a4268; flex-shrink:0; padding-top:3px; transition:transform .15s; }
    .bhvd-claim-card.open .bhvd-claim-card-arrow { transform:rotate(180deg); }
    .bhvd-claim-card-body { display:none; padding:10px 12px 12px; font-size:11px; color:#7a84a8; line-height:1.6; border-top:1px solid rgba(255,255,255,0.05); }
    .bhvd-claim-card.open .bhvd-claim-card-body { display:block; }
    /* Tighter dims */
    #bhvd-dims > div { margin-bottom:7px !important; }
  `;

  var styleEl = document.createElement("style");
  styleEl.textContent = STYLES;
  document.head.appendChild(styleEl);

  var sb = document.createElement("div");
  sb.id = "bhvd-signal-sidebar";
  sb.innerHTML =
    '<div id="bhvd-panel">' +
        '<div id="bhvd-panel-inner">' +
          '<div class="bhvd-hdr">' +
            '<div class="bhvd-hdr-logo">' +
              '<svg viewBox="0 0 22 22" width="20" height="20" fill="none"><circle cx="11" cy="8.5" r="5.5" stroke="#4a78f0" stroke-width="1.5"/><circle cx="9.2" cy="7.8" r="1" fill="#4a78f0"/><circle cx="12.8" cy="7.8" r="1" fill="#4a78f0"/><path d="M9 10.5 Q11 12.5 13 10.5" stroke="#4a78f0" stroke-width="1.2" stroke-linecap="round"/><path d="M5.5 19 Q11 16 16.5 19" stroke="#4a78f0" stroke-width="1.5" stroke-linecap="round"/></svg>' +
              'NORM' +
              '<span id="bhvd-pro-badge" style="display:none;margin-left:6px;font-size:9px;font-weight:600;letter-spacing:.08em;background:#4a78f0;color:#fff;border-radius:4px;padding:2px 6px;vertical-align:middle">PRO</span>' +
            '</div>' +
            '<button class="bhvd-close" id="bhvd-close">\xd7</button>' +
          '</div>' +
          '<div id="bhvd-scanning"><div class="bhvd-spin"></div><div class="bhvd-scan-txt">NORM is on it.</div><div class="bhvd-scan-sub">Reading their claims now.</div></div>' +
          '<div id="bhvd-unscored"><div class="bhvd-us-icon">◎</div><div class="bhvd-us-title">NORM hasn\'t checked this one yet.</div><div class="bhvd-us-body">He covers most major wellness brands. Request a review and he\'ll get to it.</div><div class="bhvd-snapshot-box"><div class="bhvd-snapshot-row"><span class="bhvd-snapshot-num" id="bhvd-snapshot-claims">—</span><span class="bhvd-snapshot-lbl">benefit claims detected on this page</span></div><div class="bhvd-snapshot-row"><span class="bhvd-snapshot-num" id="bhvd-snapshot-evidence">—</span><span class="bhvd-snapshot-lbl">evidence references detected</span></div></div><div class="bhvd-add-note">NORM noted the claims on this page. He\'ll flag it for review.</div></div>' +
          '<div id="bhvd-unverifiable"><div class="bhvd-uv-icon">◌</div><div class="bhvd-uv-title">Assessment limited by site access</div><div class="bhvd-uv-body">This brand limits independent reading. Results reflect visible content only — we couldn\'t fully access this site\'s pages.</div><div class="bhvd-uv-note">Ratings are based on publicly visible evidence only. A site that blocks independent reading cannot be fully assessed.</div></div>' +
          '<div id="bhvd-suppressed"><div class="bhvd-uv-icon">◑</div><div class="bhvd-uv-title">Limited visibility — rating withheld</div><div class="bhvd-uv-body">We captured too little data to assess this brand reliably. Publishing a rating with this level of visibility would not reflect adequate evidence.</div><div class="bhvd-uv-note">Try a product-specific page for better visibility coverage.</div></div>' +
          '<div id="bhvd-limited-data"><div class="bhvd-uv-icon">◌</div><div class="bhvd-uv-title">Insufficient Public Data</div><div class="bhvd-uv-body">The data captured from this brand is too sparse to support a reliable assessment. Publishing a rating with this level of coverage would not reflect adequate evidence.</div><div class="bhvd-uv-note">Try a product-specific page, or check back after we\'ve improved coverage for this brand.</div></div>' +
          '<div id="bhvd-pending"><div class="bhvd-uv-icon">◑</div><div class="bhvd-uv-title">Assessment in Progress</div><div class="bhvd-uv-body">This brand has not yet been cleared for public display. Ratings are verified before release to ensure they reflect adequate evidence coverage.</div><div class="bhvd-uv-note">This does not indicate a problem with the brand. Ratings are held until they meet our coverage threshold.</div></div>' +
          '<div id="bhvd-expired"><div class="bhvd-uv-icon">○</div><div class="bhvd-uv-title">NORM\'s last check has expired.</div><div class="bhvd-uv-body">Brand claims change. NORM checks back periodically — a fresh verdict is on the way.</div><div class="bhvd-uv-note">Check back shortly.</div></div>' +
          '<div id="bhvd-share-sheet"></div>' +
          '<div id="bhvd-result">' +
            '<div id="bhvd-nearexpiry-strip" style="display:none;padding:7px 22px;background:rgba(243,156,18,0.04);border-bottom:1px solid rgba(243,156,18,0.09);"><div style="display:flex;align-items:center;gap:7px;font-size:9.5px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#c8820a;">⏱ Assessment expiring soon</div><div id="bhvd-nearexpiry-sub" style="font-size:9px;color:#7a6030;margin-top:2px;letter-spacing:.01em;font-weight:400;text-transform:none;"></div></div>' +
            '<div class="bhvd-hero" id="bhvd-hero">' +
              '<div class="bhvd-hero-top">' +
                '<div class="bhvd-verdict-badge" id="bhvd-verdict-badge"></div>' +
                '<div class="bhvd-score-row">' +
                  '<div class="bhvd-score-circle" id="bhvd-score-circle"><div class="bhvd-score-num" id="bhvd-score-num">—</div><div class="bhvd-score-denom">/100</div></div>' +
                  '<div class="bhvd-hero-meta">' +
                    '<div class="bhvd-brand-name" id="bhvd-brand-name"></div>' +
                    '<div class="bhvd-hero-sub" id="bhvd-hero-sub"></div>' +
                  '</div>' +
                '</div>' +
              '</div>' +
              '<div class="bhvd-punchline" id="bhvd-punchline"></div>' +
              '<button class="bhvd-share-icon" id="bhvd-share-open"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="16"/></svg></button>' +
            '</div>' +
            '<div id="bhvd-claim-preview"></div>' +
            '<div class="bhvd-tabs">' +
              '<button class="bhvd-tab-btn active" data-tab="overview">Overview</button>' +
              '<button class="bhvd-tab-btn" data-tab="claims">Claims</button>' +
            '</div>' +
            '<div class="bhvd-tab-panel active" id="bhvd-tab-overview">' +
              '<div class="bhvd-sec" id="bhvd-dims-sec"><div class="bhvd-sec-title">Scoring Dimensions</div><div id="bhvd-dims"></div></div>' +
              '<div class="bhvd-meta-strip"><span class="bhvd-meta-item" id="bhvd-meta-pages"></span><span class="bhvd-meta-dot">·</span><span class="bhvd-meta-item" id="bhvd-meta-scanned"></span><span class="bhvd-meta-dot">·</span><span class="bhvd-meta-item" id="bhvd-meta-model"></span><span class="bhvd-meta-dot" id="bhvd-meta-validity-dot" style="display:none">·</span><span class="bhvd-meta-item" id="bhvd-meta-validity" style="display:none"></span></div>' +
            '</div>' +
            '<div class="bhvd-tab-panel" id="bhvd-tab-claims">' +
              '<div style="padding:16px 18px 0;"><div id="bhvd-assessment-body" style="font-size:12px;color:#a0a8c8;line-height:1.6;"></div></div>' +
              '<div style="padding:0 18px 16px;" id="bhvd-claims-cards"></div>' +
            '</div>' +
            '<div class="bhvd-sec" id="bhvd-flags-sec" style="display:none"></div>' +
            '<div class="bhvd-sec" id="bhvd-rank-sec" style="display:none"></div>' +
            '<div class="bhvd-vis-bar" id="bhvd-vis-bar" style="border-bottom:none;border-top:1px solid rgba(255,255,255,0.04);">' +
              '<div class="bhvd-vis-top"><span class="bhvd-vis-icon" id="bhvd-vis-icon">◕</span><span class="bhvd-vis-level" id="bhvd-vis-level">FULL VISIBILITY</span><span class="bhvd-vis-sep">·</span><span class="bhvd-vis-meta" id="bhvd-vis-meta"></span></div>' +
              '<div class="bhvd-vis-sub" id="bhvd-vis-sub">Based on visible claims and referenced evidence</div>' +
            '</div>' +
            '<div id="bhvd-upgrade-block" style="display:none;">' +
              '<div class="bhvd-ug-inner">' +
                '<div class="bhvd-ug-left">' +
                  '<div class="bhvd-ug-title" id="bhvd-ug-title">Full evidence audit locked.</div>' +
                  '<div class="bhvd-ug-body" id="bhvd-ug-body">Pro shows what evidence sits behind every claim — not just that it was flagged.</div>' +
                '</div>' +
                '<a class="bhvd-ug-btn" href="https://trynorm.co/pricing" target="_blank">Unlock Pro →</a>' +
              '</div>' +
            '</div>' +
            '<div class="bhvd-cta-sec"><button class="bhvd-cta-btn primary" id="bhvd-cta-report">View public claim record →</button><button class="bhvd-cta-btn" id="bhvd-cta-compare">How does a competitor compare?</button><div class="bhvd-disc">NORM reflects public marketing claims and visible evidence references. It does not evaluate product efficacy, safety, or regulatory status.</div></div>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '<div id="bhvd-tab">' +
      '<div id="bhvd-hover-card"><div class="bhvd-hc-title" id="bhvd-hc-title">NORM</div><div class="bhvd-hc-sub" id="bhvd-hc-sub">Ask NORM before you buy.</div></div>' +
      '<svg id="bhvd-tab-blob" viewBox="0 0 22 22" width="36" height="36" fill="none"><circle cx="11" cy="8.5" r="5.5" stroke="currentColor" stroke-width="1.5"/><circle cx="9.2" cy="7.8" r="1" fill="currentColor"/><circle cx="12.8" cy="7.8" r="1" fill="currentColor"/><path d="M9 10.5 Q11 12.5 13 10.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" fill="none"/><path d="M5.5 19 Q11 16 16.5 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none"/></svg>' +
      '<div id="bhvd-tab-label">NORM</div>' +
    '</div>';

  document.body.appendChild(sb);

  var isOpen = false;
  var _provInterval = null;
  var _provPollTimer = null;
  var _totalFlaggedClaims = 0;
  var _panelOpenCount = 0;

  function trackPanelOpen() {
    var host = window.location.hostname.replace(/^www\./, "");
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;
    chrome.storage.local.get(['norm_panel_opens'], function(res) {
      var opens = res.norm_panel_opens || {};
      opens[host] = (opens[host] || 0) + 1;
      _panelOpenCount = opens[host];
      chrome.storage.local.set({ norm_panel_opens: opens });
    });
  }

  document.getElementById("bhvd-tab").addEventListener("click", function () {
    isOpen = !isOpen;
    document.getElementById("bhvd-panel").classList.toggle("open", isOpen);
    if (isOpen) {
      trackPanelOpen();
      var stateIds = ["bhvd-scanning","bhvd-unscored","bhvd-unverifiable","bhvd-suppressed","bhvd-limited-data","bhvd-pending","bhvd-expired","bhvd-result"];
      var hasState = stateIds.some(function(id) {
        var el = document.getElementById(id);
        return el && el.style.display !== "" && el.style.display !== "none";
      });
      if (!hasState) showScanning();
    }
  });
  document.getElementById("bhvd-close").addEventListener("click", function () {
    isOpen = false;
    document.getElementById("bhvd-panel").classList.remove("open");
  });

  function setTab(sig, title, sub) {
    var blob = document.getElementById("bhvd-tab-blob");
    var lbl  = document.getElementById("bhvd-tab-label");
    var tab  = document.getElementById("bhvd-tab");
    document.getElementById("bhvd-hc-title").textContent = title || "NORM";
    document.getElementById("bhvd-hc-sub").textContent   = sub   || "Ask NORM before you buy.";
    if (SIG[sig]) {
      var s = SIG[sig];
      tab.style.background = s.bg; tab.style.borderColor = s.bd;
      blob.style.color = s.c;
      blob.style.filter = "";
      blob.style.animation = "bhvd-glow-" + sig + " 2.8s ease-in-out infinite";
      lbl.style.color = s.c;
      document.getElementById("bhvd-hc-title").style.color = s.c;
    } else if (sig === "scanning") {
      tab.style.background = "#0a0c14"; tab.style.borderColor = "rgba(255,255,255,0.08)";
      blob.style.color = "#4a5272";
      blob.style.filter = ""; blob.style.animation = "bhvd-pulse 1.2s ease infinite";
      lbl.style.color = "#4a5272"; document.getElementById("bhvd-hc-title").style.color = "#8892b0";
    } else {
      tab.style.background = "#0a0c14"; tab.style.borderColor = "rgba(255,255,255,0.06)";
      blob.style.color = "#2a3050";
      blob.style.filter = ""; blob.style.animation = "bhvd-glow-dormant 3.5s ease-in-out infinite";
      lbl.style.color = "#4a5272"; document.getElementById("bhvd-hc-title").style.color = "#8892b0";
    }
  }

  function showScanning() {
    setTab("scanning", "NORM is on it.", "Reading their claims now.");
    document.getElementById("bhvd-scanning").style.display = "block";
    document.getElementById("bhvd-unscored").style.display = "none";
    document.getElementById("bhvd-result").style.display   = "none";
  }

  function showProvisional(url) {
    if (_provInterval)  { clearInterval(_provInterval);  _provInterval = null; }
    if (_provPollTimer) { clearTimeout(_provPollTimer);   _provPollTimer = null; }

    setTab("scanning", "Scoring…", "Multi-page AI analysis running");
    var scanEl  = document.getElementById("bhvd-scanning");
    var txtEl   = scanEl.querySelector(".bhvd-scan-txt");
    var subEl   = scanEl.querySelector(".bhvd-scan-sub");
    scanEl.style.display = "block";
    document.getElementById("bhvd-unscored").style.display = "none";
    document.getElementById("bhvd-result").style.display   = "none";
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }

    var secs = 60;
    var startTime = Date.now();

    function tick() {
      if (txtEl) txtEl.textContent = "NORM is on it. " + secs + "s";
      if (subEl) subEl.textContent = "Reading their claims now.";
    }
    tick();

    function doPoll() {
      chrome.runtime.sendMessage({ type: "LOOKUP_URL", url: url }, function(resp) {
        if (chrome.runtime.lastError) { scheduleNextPoll(); return; }
        if (resp && resp.status === "found" && resp.data && resp.data.signal_color && !resp.data.is_provisional) {
          if (_provInterval)  { clearInterval(_provInterval);  _provInterval = null; }
          if (_provPollTimer) { clearTimeout(_provPollTimer);   _provPollTimer = null; }
          var elapsed = Math.round((Date.now() - startTime) / 1000);
          if (txtEl && elapsed < 115) txtEl.textContent = "Scored in " + elapsed + "s!";
          setTimeout(function() { showResult(resp.data); }, elapsed < 115 ? 800 : 0);
        } else {
          scheduleNextPoll();
        }
      });
    }

    function scheduleNextPoll() {
      if (secs > 0) {
        _provPollTimer = setTimeout(doPoll, 10000);
      } else {
        // Countdown done, still scoring — keep polling every 15s, update text
        if (txtEl) txtEl.textContent = "Still scoring…";
        if (subEl) subEl.textContent = "Hang tight — results landing soon";
        _provPollTimer = setTimeout(doPoll, 15000);
      }
    }

    _provInterval = setInterval(function() {
      secs--;
      if (secs <= 0) {
        clearInterval(_provInterval); _provInterval = null;
        doPoll(); // check immediately at 0
      } else {
        tick();
        if (secs % 10 === 0) doPoll();
      }
    }, 1000);
  }

  function showUnverifiable() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-unverifiable").style.display = "block";
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
  }

  var _domCaptureSent = {};  // guard against duplicate captures per URL

  // Paths that must never be captured — checkout, auth, account, personal pages
  var _BLOCKED_PATHS = [
    "/checkout","/cart","/account","/order","/orders","/login","/signin",
    "/signup","/register","/profile","/subscription","/billing","/payment",
    "/my-","/my/","/purchases","/history","/address","/settings","/security",
    "/forgot-password","/reset-password","/2fa","/verify"
  ];

  function _isBlockedPath(url) {
    try {
      var path = new URL(url).pathname.toLowerCase();
      for (var i = 0; i < _BLOCKED_PATHS.length; i++) {
        if (path.indexOf(_BLOCKED_PATHS[i]) === 0 || path.indexOf(_BLOCKED_PATHS[i]) !== -1 && _BLOCKED_PATHS[i].indexOf("/my-") === 0) return true;
        if (path === _BLOCKED_PATHS[i] || path.startsWith(_BLOCKED_PATHS[i] + "/") || path.startsWith(_BLOCKED_PATHS[i].replace(/\/$/, "") + "/")) return true;
      }
    } catch(_) {}
    return false;
  }

  function _stripPii(text) {
    return text
      .replace(/\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b/g, "[email]")
      .replace(/\b(?:\+?1[\s\-.]?)?\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4}\b/g, "[phone]")
      .replace(/\b\d{4}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}\b/g, "[card]")
      .replace(/\b\d{3}-\d{2}-\d{4}\b/g, "[ssn]");
  }

  function tryDomCapture(url) {
    // Never capture blocked paths
    if (_isBlockedPath(url)) return;
    if (_domCaptureSent[url]) return;
    var domText = document.body ? document.body.innerText : "";
    if (!domText || domText.length < 500) return;
    _domCaptureSent[url] = true;
    var safeText = _stripPii(domText.slice(0, 50000));
    // Fire-and-forget — no UI change, no polling, no promise of a score
    chrome.runtime.sendMessage({ type: "DOM_CAPTURE", url: url, dom_text: safeText }, function() {
      if (chrome.runtime.lastError) {} // silent
    });
  }

  function showNotYetAssessed(claimCount, evidenceCount, url) {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-snapshot-claims").textContent   = claimCount  > 0 ? claimCount  : "0";
    document.getElementById("bhvd-snapshot-evidence").textContent = evidenceCount > 0 ? evidenceCount : "0";
    document.getElementById("bhvd-unscored").style.display = "block";

    var currentDomain = window.location.hostname.replace(/^www\./, "");
    var requestUrl = "https://trynorm.co/request/?d=" + encodeURIComponent(currentDomain) + "&source=extension";

    var reqLink = document.getElementById("bhvd-unscored-request");
    if (!reqLink) {
      reqLink = document.createElement("a");
      reqLink.id = "bhvd-unscored-request";
      reqLink.setAttribute("target", "_blank");
      reqLink.setAttribute("rel", "noopener noreferrer");
      reqLink.setAttribute("style", "display:block;margin-top:12px;font-size:10.5px;color:#1a8fff;text-decoration:none;text-align:center;font-weight:600;letter-spacing:.01em;");
      reqLink.textContent = "Request an assessment →";
      document.getElementById("bhvd-unscored").appendChild(reqLink);
    }
    reqLink.href = requestUrl;
    reqLink.onclick = function() {
      // Queue the brand for scanning when user clicks request
      chrome.runtime.sendMessage({ type: "QUEUE_URL", url: "https://" + currentDomain }).catch(function(){});
    };

    logDemandEvent(currentDomain, "not_assessed_shown");
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
    if (url) tryDomCapture(url);
  }

  // Keep showUnscored as alias — called from legacy paths (unverifiable fallback etc.)
  function showUnscored(url) {
    showNotYetAssessed(0, 0, url);
  }

  function _hideAllPanelStates() {
    ["bhvd-scanning","bhvd-unscored","bhvd-unverifiable","bhvd-suppressed",
     "bhvd-limited-data","bhvd-pending","bhvd-expired","bhvd-result"]
      .forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.style.display = "none";
      });
  }

  function showSuppressed() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-suppressed").style.display = "block";
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
  }

  function showLimitedData() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-limited-data").style.display = "block";
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
  }

  function showPendingReview() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-pending").style.display = "block";
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
  }

  function showExpired() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-expired").style.display = "block";
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
  }

  function _esc(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function timeAgo(iso) {
    if (!iso) return "unknown";
    var diff = Date.now() - new Date(iso).getTime();
    var mins = Math.floor(diff / 60000);
    if (mins < 2)   return "just now";
    if (mins < 60)  return mins + "m ago";
    var hrs = Math.floor(mins / 60);
    if (hrs < 24)   return hrs + "h ago";
    return Math.floor(hrs / 24) + "d ago";
  }

  function barColor(pct) {
    if (pct >= 0.7) return "#4eca7a";
    if (pct >= 0.45) return "#f5c430";
    return "#e05555";
  }

  // When leaderboard has a scored verdict, it overrides the legacy signal_color field
  var VERDICT_TO_SIG = {
    "ALIGNED":"green","VALIDATED":"green","GENERALLY ALIGNED":"green",
    "PARTIALLY ALIGNED":"yellow",
    "OVEREXTENDED":"red","EVIDENCE GAP":"red",
    "REAL":"green","TIGHT":"green","CREDIBLE":"yellow",
    "SOFT":"yellow","STRETCHED":"red","HYPE":"red","RED FLAG":"red"
  };

  function showResult(r) {
    var sig  = r.signal_color || "yellow";
    // Verdict from leaderboard is authoritative — override the legacy signal_color
    var _rawVerdict = (r.leaderboard_data || {}).bhvd_verdict || null;
    if (_rawVerdict && VERDICT_TO_SIG[_rawVerdict]) {
      sig = VERDICT_TO_SIG[_rawVerdict];
    }
    var s    = SIG[sig] || SIG.yellow;
    var ld   = r.leaderboard_data || {};
    var dims = r.dimension_scores || {};

    // Data integrity — two-factor trust gate (prefer new fields, fall back to legacy)
    var dataIntegrity = ld.data_integrity || (
      r.confidence === "high" ? "high" : r.confidence === "medium" ? "medium" : "low"
    );
    var dataVis    = ld.data_visibility || (r.confidence === "high" ? "full" : r.confidence === "medium" ? "partial" : "limited");
    var visIndex   = ld.visibility_index != null ? ld.visibility_index : (r.confidence === "high" ? 80 : r.confidence === "medium" ? 55 : 20);
    var captureRaw = ld.capture_method || "crawler";
    var reviewedDate = captureRaw === "manual" && ld.reviewed_at
      ? new Date(ld.reviewed_at).toLocaleDateString("en-US", { month: "short", year: "numeric" })
      : null;
    var captureDisplay = captureRaw === "manual"
      ? ("Reference data" + (reviewedDate ? " · verified " + reviewedDate : ""))
      : (captureRaw === "dom" ? "DOM capture" : captureRaw === "vision" ? "Vision" : "Crawler");

    // Gate 1: Data integrity — Low = cannot assess reliably, suppress all scores
    if (dataIntegrity === "low") {
      showLimitedData();
      return;
    }

    // Unverified flag — score shows but with indicator
    var isVerified = (ld.review_status === "reviewed") && (ld.public_safe !== false);

    // Gate 2 (expiry only — unverified scores now show with indicator)
    var validUntil = r.valid_until || ld.valid_until || null;
    if (validUntil && Date.now() > new Date(validUntil).getTime()) {
      showExpired();
      return;
    }

    var dataConf       = r.data_confidence || ld.data_confidence || "medium";
    var validUntilDate = validUntil ? new Date(validUntil) : null;
    var daysUntilExpiry = validUntilDate ? Math.floor((validUntilDate.getTime() - Date.now()) / 86400000) : null;

    _hideAllPanelStates();

    // ── Unverified strip ──
    var uvStrip = document.getElementById("bhvd-unverified-strip");
    if (uvStrip) uvStrip.style.display = isVerified ? "none" : "block";

    // ── Near-expiry strip ──
    var nearExpiryStrip = document.getElementById("bhvd-nearexpiry-strip");
    if (nearExpiryStrip) {
      if (daysUntilExpiry != null && daysUntilExpiry >= 0 && daysUntilExpiry <= 7) {
        nearExpiryStrip.style.display = "block";
        var nearExpirySub = document.getElementById("bhvd-nearexpiry-sub");
        if (nearExpirySub) nearExpirySub.textContent = "Score expires in " + daysUntilExpiry + " day" + (daysUntilExpiry === 1 ? "" : "s") + " — reassessment scheduled.";
      } else {
        nearExpiryStrip.style.display = "none";
      }
    }

    // ── Visibility bar ──
    var visBar    = document.getElementById("bhvd-vis-bar");
    var visIcons  = { full: "◕", partial: "◑", limited: "○", high: "◕", medium: "◑", low: "○" };
    var visLabels = { full: "THOROUGH SCAN", partial: "PARTIAL SCAN", limited: "INSUFFICIENT PUBLIC DATA",
                      high: "THOROUGH SCAN",  medium: "PARTIAL SCAN",  low: "INSUFFICIENT PUBLIC DATA" };
    var visSubs   = {
      high:    "Thorough scan — strong page coverage with substantive outcome and functional claims",
      medium:  "Partial scan — based on visible marketing language; some pages or claims may not have been captured",
      low:     "Insufficient public data — too little captured to assess fairly",
      full:    "Thorough scan — strong page coverage with substantive outcome and functional claims",
      partial: "Partial scan — based on visible marketing language; some pages or claims may not have been captured",
      limited: "Insufficient public data — too little captured to assess fairly",
    };

    // Manual / reference brands get a distinct label — not conflated with crawler scan quality
    var integrityDisplay = ld.data_integrity || dataVis;
    var isManual = captureRaw === "manual";
    var visLevelText = isManual ? "REFERENCE SCORE" : (visLabels[integrityDisplay] || "PARTIAL SCAN");
    var visSubText   = isManual
      ? "Alignment rating — hand-verified editorial assessment based on publicly visible claims and evidence references"
      : (visSubs[integrityDisplay] || visSubs.medium);
    document.getElementById("bhvd-vis-icon").textContent  = isManual ? "◈" : (visIcons[integrityDisplay]  || "○");
    document.getElementById("bhvd-vis-level").textContent = visLevelText;
    var confSuffix = dataConf === "high" ? " · High confidence" : dataConf === "low" ? " · Low confidence" : "";
    document.getElementById("bhvd-vis-sub").textContent   = visSubText + confSuffix;

    var claimsCount = ld.extraction_claim_count != null ? ld.extraction_claim_count : (ld.claims_found || []).length;
    var pagesCount  = ld.scrape_pages != null ? ld.scrape_pages : null;
    var metaParts   = [];
    if (claimsCount > 0) metaParts.push(claimsCount + " claims");
    if (pagesCount != null && pagesCount > 0) metaParts.push(pagesCount + (pagesCount === 1 ? " page" : " pages"));
    metaParts.push(captureDisplay);
    document.getElementById("bhvd-vis-meta").textContent = metaParts.join(" · ");

    if (visBar) visBar.className = "bhvd-vis-bar " + (isManual ? "high" : (ld.data_integrity || dataVis));

    // Score: prefer leaderboard total, fall back to inverted risk
    var score = ld.total_score != null ? Math.round(ld.total_score) : Math.round(100 - (r.claim_support_risk || 50));
    var verdict = ld.bhvd_verdict || null;
    var brandName = r.brand_name || (r.domain || window.location.hostname).replace(/^www\./, "").split(".")[0];

    setTab(sig, brandName, "NORM checked. See what he found.");

    // ── Hero ──
    var heroEl = document.getElementById("bhvd-hero");
    heroEl.style.background = s.bg;

    var circle = document.getElementById("bhvd-score-circle");
    // Use display:block + position:absolute on children — flex centering is overridden by page CSS
    circle.setAttribute("style", [
      "display:block !important",
      "position:relative !important",
      "width:44px !important",
      "height:44px !important",
      "min-width:44px !important",
      "min-height:44px !important",
      "max-width:44px !important",
      "max-height:44px !important",
      "border-radius:12px !important",
      "flex-shrink:0 !important",
      "box-sizing:border-box !important",
      "border:1.5px solid " + s.c + " !important",
      "background-color:rgba(0,0,0,0.3) !important",
      "padding:0 !important",
      "margin:0 !important",
      "overflow:hidden !important",
    ].join(";"));

    // Hide denom — absolute centering of two elements is complex; score alone is clear
    var denomEl = document.getElementById("bhvd-score-circle").querySelector(".bhvd-score-denom");
    if (denomEl) denomEl.setAttribute("style", "display:none !important");

    var scoreEl = document.getElementById("bhvd-score-num");
    scoreEl.textContent = score;
    // Absolute centering — immune to any flex/block override from page CSS
    scoreEl.setAttribute("style", [
      "position:absolute !important",
      "top:50% !important",
      "left:50% !important",
      "transform:translate(-50%,-50%) !important",
      "font-size:18px !important",
      "font-weight:900 !important",
      "line-height:1 !important",
      "font-family:monospace !important",
      "letter-spacing:-.03em !important",
      "white-space:nowrap !important",
      "margin:0 !important",
      "padding:0 !important",
      "color:" + s.c + " !important",
    ].join(";"));

    document.getElementById("bhvd-brand-name").textContent = brandName;

    var badge = document.getElementById("bhvd-verdict-badge");
    if (verdict) {
      var vc = VERDICT_COLOR[verdict] || s.c;
      badge.textContent = VERDICT_LABEL[verdict] || verdict;
      badge.style.color = vc;
      badge.style.borderColor = vc + "55";
      badge.style.backgroundColor = vc + "18";
      badge.style.display = "inline-flex";
    } else {
      badge.textContent = s.label;
      badge.style.color = s.c;
      badge.style.borderColor = s.c + "44";
      badge.style.backgroundColor = s.c + "15";
      badge.style.display = "inline-flex";
    }

    var catStr = (r.category || "").replace(/_/g, " ");
    document.getElementById("bhvd-hero-sub").textContent = catStr + (r.rank_number ? " · #" + r.rank_number + (r.rank_total ? " of " + r.rank_total : "") : "");
    // Rank shown above — omit from meta strip to avoid duplication

    // Punchline — show plain-English summary immediately below score row
    var punchEl = document.getElementById("bhvd-punchline");
    if (punchEl) {
      var summaryText = ld.why_this_verdict || r.consumer_summary || s.verdict || "";
      if (summaryText) {
        punchEl.textContent = summaryText;
        punchEl.style.display = "";
      } else {
        punchEl.style.display = "none";
      }
    }

    // ── Dimension bars ──
    // Support both v3 schema (evidence_presence/evidence_strength/consumer_distortion)
    // and v2 schema (evidence/marketing_honesty) for backwards-compat with old DB rows
    var isV3 = dims.evidence_presence != null || dims.evidence_strength != null || dims.consumer_distortion != null;
    var BHVD_DIMS = isV3 ? [
      { name: "Specificity",           key: "specificity",         max: 15 },
      { name: "Mechanism",             key: "mechanism",           max: 15 },
      { name: "Evidence Presence",     key: "evidence_presence",   max: 10 },
      { name: "Evidence Strength",     key: "evidence_strength",   max: 25 },
      { name: "Effect Reality",        key: "effect_reality",      max: 15 },
      { name: "Marketing Honesty", key: "consumer_distortion", max: 20 },
    ] : [
      { name: "Specificity",   key: "specificity",       max: 20 },
      { name: "Mechanism",     key: "mechanism",         max: 20 },
      { name: "Evidence",      key: "evidence",          max: 25 },
      { name: "Effect Reality",key: "effect_reality",    max: 20 },
      { name: "Mktg Honesty",  key: "marketing_honesty", max: 15 },
    ];
    var dc = document.getElementById("bhvd-dims");
    dc.innerHTML = "";
    var hasDims = BHVD_DIMS.some(function(d) { return dims[d.key] != null; });
    document.getElementById("bhvd-dims-sec").style.display = "none";

    function dimInsight(key, val, max) {
      var pct = val / max;
      var hi = pct >= 0.7, mid = pct >= 0.45;
      var insights = {
        specificity: {
          hi:  "Specific ingredients, doses, and bioavailable forms are clearly named — consumers can verify what they're actually getting.",
          mid: "Some specificity — partial doses or forms named, but not consistently throughout.",
          lo:  "Vague formulation — no specific doses, ingredient forms, or sourcing disclosed. Hard to verify independently."
        },
        mechanism: {
          hi:  "Explains how effects occur biologically — delivery system, absorption pathway, or device mechanism described.",
          mid: "Some mechanism explained, but key claims lack a clear biological rationale.",
          lo:  "No biological mechanism provided. Claims effects without explaining how the body would produce them."
        },
        evidence_presence: {
          hi:  "Strong evidence signals — linked studies, a dedicated science page, or third-party certifications visible.",
          mid: "Some evidence signals present but limited — a cert claimed or vague study references without links.",
          lo:  "No visible evidence signals — no linked studies, no certifications, no science page."
        },
        evidence_strength: {
          hi:  "Evidence is rigorous and aligned — independent RCTs at meaningful doses that directly support the marketed claims.",
          mid: "Evidence exists but has limitations — ingredient-level studies, small samples, or partial alignment with claims.",
          lo:  "Evidence is weak or misaligned — bioavailability data, internal studies, or research that doesn't prove the marketed outcome."
        },
        effect_reality: {
          hi:  "Claimed effects are consistent with what published science supports for this category and dose.",
          mid: "Some claims are literature-supported; others stretch beyond what evidence shows.",
          lo:  "Claimed effects significantly exceed what published literature supports for this product type."
        },
        consumer_distortion: {
          hi:  "Claims are proportionate to the visible evidence — language is measured and qualified relative to what studies show.",
          mid: "Some overstatement present but not materially misleading — minor extension beyond what evidence directly supports.",
          lo:  "Claims extend materially beyond the visible evidence base — clinical language used for weak evidence, or narrow findings applied to broad consumer promises."
        },
        // v2 fallbacks
        evidence: {
          hi:  "Evidence is rigorous and directly supports the claims made.",
          mid: "Some evidence present but limited in quality or alignment.",
          lo:  "Evidence is weak, missing, or misaligned with the claims made."
        },
        marketing_honesty: {
          hi:  "Marketing language is proportionate and honest about what the evidence shows.",
          mid: "Some overstatement present but not severely misleading.",
          lo:  "Marketing significantly overstates what the evidence supports."
        }
      };
      var set = insights[key];
      if (!set) return "";
      return hi ? set.hi : mid ? set.mid : set.lo;
    }

    // Shared tooltip element
    var _dimTip = document.getElementById("bhvd-dim-tip");
    if (!_dimTip) {
      _dimTip = document.createElement("div");
      _dimTip.id = "bhvd-dim-tip";
      _dimTip.setAttribute("style",
        "position:fixed !important;z-index:2147483648 !important;" +
        "background:#0d1020 !important;border:1px solid rgba(255,255,255,0.12) !important;" +
        "border-radius:10px !important;padding:10px 13px !important;" +
        "font-size:11px !important;line-height:1.55 !important;color:#b8c0d8 !important;" +
        "max-width:240px !important;pointer-events:none !important;opacity:0 !important;" +
        "transition:opacity .15s !important;box-shadow:0 8px 24px rgba(0,0,0,0.6) !important;" +
        "font-family:-apple-system,BlinkMacSystemFont,sans-serif !important;"
      );
      document.body.appendChild(_dimTip);
    }

    if (hasDims) {
      BHVD_DIMS.forEach(function(d) {
        var val = dims[d.key] != null ? dims[d.key] : null;
        var pct = val != null ? val / d.max : 0;
        var fillPct = val != null ? Math.round(pct * 100) : 0;
        var barFill = val != null ? barColor(pct) : "rgba(255,255,255,0.08)";
        var TRACK_BG = "rgba(255,255,255,0.08)";
        var grad = "linear-gradient(to right," + barFill + " " + fillPct + "%," + TRACK_BG + " " + fillPct + "%)";

        // Stacked layout: name + score on top row, bar below — full names fit without truncation
        var hdrEl = document.createElement("div");
        hdrEl.setAttribute("style", "display:flex !important;justify-content:space-between !important;align-items:baseline !important;margin:0 0 4px 0 !important;padding:0 !important;");

        var nameEl = document.createElement("div");
        nameEl.setAttribute("style", "font-size:10.5px !important;color:#7a82a0 !important;flex:1 !important;margin:0 !important;padding:0 !important;line-height:1.3 !important;");
        nameEl.textContent = d.name;

        var scoreEl = document.createElement("div");
        scoreEl.setAttribute("style", "font-size:10px !important;font-family:monospace !important;flex-shrink:0 !important;font-weight:700 !important;color:" + barFill + " !important;margin:0 0 0 8px !important;padding:0 !important;");
        scoreEl.textContent = val != null ? val + "/" + d.max : "—";

        hdrEl.appendChild(nameEl);
        hdrEl.appendChild(scoreEl);

        var barWrap = document.createElement("div");
        barWrap.setAttribute("style",
          "width:100% !important;height:4px !important;min-height:4px !important;" +
          "max-height:4px !important;border-radius:2px !important;" +
          "background:" + grad + " !important;margin:0 !important;padding:0 !important;display:block !important;"
        );

        var row = document.createElement("div");
        row.setAttribute("style", "display:flex !important;flex-direction:column !important;margin-bottom:10px !important;padding:3px 0 !important;cursor:default !important;");
        row.appendChild(hdrEl);
        row.appendChild(barWrap);

        // Hover tooltip
        if (val != null) {
          var insight = dimInsight(d.key, val, d.max);
          if (insight) {
            row.addEventListener("mouseenter", function(e) {
              _dimTip.textContent = insight;
              _dimTip.style.setProperty("opacity", "1", "important");
              var rect = row.getBoundingClientRect();
              var tipLeft = rect.left;
              var tipTop  = rect.top - 8;
              // Keep inside viewport
              if (tipLeft + 250 > window.innerWidth) tipLeft = window.innerWidth - 258;
              _dimTip.style.setProperty("left", tipLeft + "px", "important");
              _dimTip.style.setProperty("top",  (tipTop - _dimTip.offsetHeight || tipTop - 60) + "px", "important");
            });
            row.addEventListener("mouseleave", function() {
              _dimTip.style.setProperty("opacity", "0", "important");
            });
          }
        }

        dc.appendChild(row);
      });
    }

    // ── Claim preview — top flagged claims visible on overview without tab click ──
    var previewEl = document.getElementById("bhvd-claim-preview");
    if (previewEl) {
      var gapMap = ld.gap_map || [];
      var sortOrder = { gap: 0, partial: 1, missing: 2, aligned: 3 };
      var sortedClaims = gapMap.slice().sort(function(a, b) {
        return (sortOrder[a.status] || 2) - (sortOrder[b.status] || 2);
      });
      var previewClaims = sortedClaims.filter(function(g) {
        return g.status === "gap" || g.status === "partial";
      }).slice(0, 3);

      if (previewClaims.length > 0) {
        var GAP_PREV_LABEL = { gap: "No Evidence", partial: "Partial" };
        var isRed = sig === "red";
        var pvHtml = '<div class="bhvd-cp-label">' + (isRed ? "Flagged Claims" : sig === "yellow" ? "Unsupported Claims" : "Claim Highlights") + '</div>';
        for (var pi = 0; pi < previewClaims.length; pi++) {
          var pc = previewClaims[pi];
          pvHtml +=
            '<div class="bhvd-cp-item">' +
              '<span class="bhvd-cp-status ' + _esc(pc.status) + '">' + _esc(GAP_PREV_LABEL[pc.status] || pc.status.toUpperCase()) + '</span>' +
              '<span class="bhvd-cp-text">“' + _esc(pc.claim) + '”</span>' +
            '</div>';
        }
        var totalFlagged = sortedClaims.filter(function(g) { return g.status === "gap" || g.status === "partial"; }).length;
        if (totalFlagged > previewClaims.length) {
          pvHtml += '<button class="bhvd-cp-more" id="bhvd-cp-more-btn">See all flagged claims →</button>';
        }
        previewEl.innerHTML = pvHtml;
        previewEl.style.display = "";
        var cpMoreBtn = document.getElementById("bhvd-cp-more-btn");
        if (cpMoreBtn) {
          cpMoreBtn.addEventListener("click", function() {
            var claimsBtn = document.querySelector('.bhvd-tab-btn[data-tab="claims"]');
            if (claimsBtn) claimsBtn.click();
          });
        }
      } else {
        previewEl.innerHTML = "";
        previewEl.style.display = "none";
      }
    }

    // ── Assessment (always-visible summary) ──
    var flagSec      = document.getElementById("bhvd-flags-sec");
    var assessBody   = document.getElementById("bhvd-assessment-body");

    // ── Evidence metrics — hidden, available in full report ──
    document.querySelector(".bhvd-sec:has(#bhvd-ev-strip)") && (document.querySelector(".bhvd-sec:has(#bhvd-ev-strip)").style.display = "none");
    var claimsFound = ld.extraction_claim_count != null ? ld.extraction_claim_count : (ld.claims_found || []).length;

    // ── Rank — collapsed into meta strip ──
    document.getElementById("bhvd-rank-sec").style.display = "none";

    // ── Category Standing ──
    var standingSec = document.getElementById("bhvd-standing-sec");
    if (standingSec && r.category_standing && r.category_percentile != null) {
      var BAND_COLORS = {
        top10:    "#27ae60", top25: "#4eca7a",
        middle50: "#f39c12",
        bottom25: "#e67e22", bottom10: "#e74c3c"
      };
      var bandColor = BAND_COLORS[r.category_standing_band] || "#f39c12";
      var pct = r.category_percentile;
      var badgeEl = document.getElementById("bhvd-standing-badge");
      var fillEl  = document.getElementById("bhvd-standing-fill");
      var pctEl   = document.getElementById("bhvd-standing-pct");
      var subEl   = document.getElementById("bhvd-standing-sub");
      if (badgeEl) { badgeEl.textContent = r.category_standing; badgeEl.style.color = bandColor; }
      if (fillEl)  { fillEl.style.width = pct + "%"; fillEl.style.background = bandColor; }
      if (pctEl)   { pctEl.textContent = pct + "%"; }
      if (subEl) {
        var catLabel = (r.category || "").replace(/_/g, " ");
        subEl.textContent = "Ranked higher than " + pct + "% of " + (r.category_peer_count || "peer") + " " + catLabel + " brands scored";
      }
      standingSec.style.display = "";
    } else if (standingSec) {
      standingSec.style.display = "none";
    }

    // ── Meta strip ──
    var modelUsed  = ld.model_used === "manual" ? "Ref score" : ld.model_used ? (ld.escalated ? "Sonnet↑" : "Haiku") : "AI";
    var openNote   = _panelOpenCount > 1 ? " · Checked " + _panelOpenCount + "×" : "";
    document.getElementById("bhvd-meta-pages").textContent   = visIndex + "% captured" + openNote;
    var lastVerifiedIso = r.last_verified || r.last_scanned_at;
    document.getElementById("bhvd-meta-scanned").textContent = "Verified " + timeAgo(lastVerifiedIso);
    document.getElementById("bhvd-meta-model").textContent   = modelUsed;
    var validityDot = document.getElementById("bhvd-meta-validity-dot");
    var validityEl  = document.getElementById("bhvd-meta-validity");
    if (validUntilDate && validityEl && validityDot) {
      validityEl.textContent = "Valid until " + validUntilDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
      validityEl.style.display = "";
      validityDot.style.display = "";
    } else if (validityEl && validityDot) {
      validityEl.style.display = "none";
      validityDot.style.display = "none";
    }

    // ── Share ──
    var domain = (r.domain || window.location.hostname).replace(/^www\./, "");
    var brandPage = "https://trynorm.co/brand/?d=" + encodeURIComponent(domain) + "&source=extension&t=" + Date.now();
    var scoreLabel = verdict ? (score + "/100 · " + (VERDICT_LABEL[verdict]||verdict)) : (score + "/100 · " + s.label);
    var fullPunch = ld.why_this_verdict || r.consumer_summary || "";

    // ── Assessment — collapsible, full text, gap_map, strengths ──
    var GAP_STATUS_LABEL = { gap: "NO EVIDENCE FOUND", partial: "PARTIAL EVIDENCE", aligned: "SUPPORTED", missing: "NOT ASSESSED" };
    if (fullPunch && assessBody) {
      var assessHtml = '<div class="bhvd-assess-verdict">' + _esc(fullPunch) + '</div>';

      // Why flagged reasons — specific language problems called out explicitly
      var flaggedReasons = Array.isArray(r.why_flagged_top_reasons) ? r.why_flagged_top_reasons : [];
      if (flaggedReasons.length > 0 && (sig === "red" || sig === "yellow")) {
        assessHtml += '<div class="bhvd-flagged-reasons"><div class="bhvd-flagged-reasons-title">Specific Issues Found</div>';
        for (var fi = 0; fi < flaggedReasons.length; fi++) {
          assessHtml += '<div class="bhvd-flagged-reason">' + _esc(flaggedReasons[fi]) + '</div>';
        }
        assessHtml += '</div>';
      }

      // Limitations — what's missing or overstated
      if (ld.limitations) {
        assessHtml += '<div class="bhvd-assess-limitations">' + _esc(ld.limitations) + '</div>';
      }

      // Strengths — shown only for green/yellow brands worth crediting
      if (ld.strengths && sig !== "red") {
        assessHtml += '<div class="bhvd-assess-strengths">' + _esc(ld.strengths) + '</div>';
      }

      // Evidence accessibility note — shown when evidence exists but isn't easy to find
      var evSnap = r.evidence_snapshot || {};
      var accessNote = evSnap.accessibility_consumer_note;
      var accessLevel = evSnap.accessibility_level;
      if (accessNote && accessLevel > 0) {
        assessHtml +=
          '<div style="margin-top:8px;padding:7px 10px;background:rgba(255,255,255,0.04);border-radius:6px;border-left:2px solid rgba(255,255,255,0.15);">' +
            '<span style="font-size:9.5px;color:#7a82a0;">◎ ' + _esc(accessNote) + '</span>' +
          '</div>';
      }

      // Gap map — flagged claim language with evidence status
      if (ld.gap_map && ld.gap_map.length > 0) {
        var hasGaps = ld.gap_map.some(function(g) { return g.status === "gap" || g.status === "partial"; });
        var gapTitle = hasGaps ? "Flagged Claim Language" : "Claim Evidence Audit";
        assessHtml += '<div class="bhvd-gap-map"><div class="bhvd-gap-title">' + gapTitle + '</div>';
        for (var gi = 0; gi < ld.gap_map.length; gi++) {
          var g = ld.gap_map[gi];
          var gStatus = g.status || "gap";
          var gLabel = GAP_STATUS_LABEL[gStatus] || gStatus.toUpperCase();
          assessHtml +=
            '<div class="bhvd-gap-row ' + _esc(gStatus) + '">' +
              '<div class="bhvd-gap-dot ' + _esc(gStatus) + '"></div>' +
              '<div class="bhvd-gap-body">' +
                '<div class="bhvd-gap-status ' + _esc(gStatus) + '">' + _esc(gLabel) + '</div>' +
                '<div class="bhvd-gap-claim">"' + _esc(g.claim) + '"</div>' +
                (g.evidence ? '<div class="bhvd-gap-evid">' + _esc(g.evidence) + '</div>' : '') +
              '</div>' +
            '</div>';
        }
        assessHtml += '</div>';
      }
      assessBody.innerHTML = assessHtml;
      flagSec.style.display = "none";
    } else if (assessBody) {
      assessBody.innerHTML = "";
      flagSec.style.display = "none";
    }

    // ── Claims tab — claim cards (Option D) ──
    var claimsCards = document.getElementById("bhvd-claims-cards");
    if (claimsCards) {
      var GAP_CARD_LABEL = { gap: "No Evidence Found", partial: "Partial Evidence", aligned: "Supported", missing: "Not Assessed" };
      var cardsHtml = "";
      // Flagged reasons list
      var flaggedReasons = Array.isArray(r.why_flagged_top_reasons) ? r.why_flagged_top_reasons : [];
      if (flaggedReasons.length > 0) {
        cardsHtml += '<div style="margin-bottom:14px;">';
        cardsHtml += '<div style="font-size:10px;color:#4a5280;font-weight:700;letter-spacing:.08em;text-transform:uppercase;margin-bottom:8px;">Issues Found</div>';
        for (var fi = 0; fi < flaggedReasons.length; fi++) {
          cardsHtml += '<div style="display:flex;gap:7px;align-items:flex-start;margin-bottom:6px;font-size:11.5px;color:#c0c8e0;line-height:1.55;">' +
            '<span style="color:#e74c3c;flex-shrink:0;font-weight:700;">→</span>' +
            '<span>' + _esc(flaggedReasons[fi]) + '</span>' +
            '</div>';
        }
        cardsHtml += '</div>';
      }
      // Gap map claim cards
      if (ld.gap_map && ld.gap_map.length > 0) {
        cardsHtml += '<div style="font-size:10px;color:#4a5280;font-weight:700;letter-spacing:.08em;text-transform:uppercase;margin-bottom:8px;">Claim by Claim</div>';
        for (var ci = 0; ci < ld.gap_map.length; ci++) {
          var gc = ld.gap_map[ci];
          var gcStatus = gc.status || "gap";
          var gcLabel = GAP_CARD_LABEL[gcStatus] || gcStatus;
          cardsHtml += '<div class="bhvd-claim-card" data-idx="' + ci + '">' +
            '<div class="bhvd-claim-card-head">' +
              '<span class="bhvd-claim-card-status ' + _esc(gcStatus) + '">' + _esc(gcLabel) + '</span>' +
              '<span class="bhvd-claim-card-text">"' + _esc(gc.claim) + '"</span>' +
              '<span class="bhvd-claim-card-arrow">▾</span>' +
            '</div>' +
            (gc.evidence ? '<div class="bhvd-claim-card-body">' + _esc(gc.evidence) + '</div>' : '') +
          '</div>';
        }
      }
      // Limitations
      if (ld.limitations) {
        cardsHtml += '<div style="margin-top:12px;font-size:11.5px;color:#8a8aa8;background:#0e0e18;border:1px solid #2a2a40;border-radius:6px;padding:8px 11px;line-height:1.6;">' +
          '<span style="color:#e05555;font-weight:700;">⚠ </span>' + _esc(ld.limitations) + '</div>';
      }
      claimsCards.innerHTML = cardsHtml;
      // Wire up claim card expand/collapse
      var cards = claimsCards.querySelectorAll(".bhvd-claim-card");
      for (var ki = 0; ki < cards.length; ki++) {
        cards[ki].addEventListener("click", function() { this.classList.toggle("open"); });
      }
    }


    // ── Tab switching ──
    var tabBtns = document.querySelectorAll(".bhvd-tab-btn");
    var tabPanels = document.querySelectorAll(".bhvd-tab-panel");
    for (var ti = 0; ti < tabBtns.length; ti++) {
      tabBtns[ti].addEventListener("click", function() {
        var target = this.getAttribute("data-tab");
        for (var tj = 0; tj < tabBtns.length; tj++) tabBtns[tj].classList.remove("active");
        for (var tk = 0; tk < tabPanels.length; tk++) tabPanels[tk].classList.remove("active");
        this.classList.add("active");
        var panel = document.getElementById("bhvd-tab-" + target);
        if (panel) panel.classList.add("active");
      });
    }

    var firstSentence = (fullPunch.split(/\.\s+/)[0] || fullPunch).trim();
    var punchShort = firstSentence.length > 140 ? firstSentence.slice(0, 137).replace(/\s\S+$/, "…") : firstSentence;
    if (punchShort && !/[.!?…]$/.test(punchShort)) punchShort += ".";
    var verdictTag = VERDICT_LABEL[verdict] || verdict || s.label;
    var hashtag   = toBrandHashtag(brandName);
    var shareTail = "\n\nWe score wellness brands on evidence, not marketing. → " + brandPage + "\n" + hashtag;
    var shareHead = "Before you buy " + brandName + " — NORM scores it " + score + "/100.\n\nClaim level: " + verdictTag + ". ";
    var punchBudget = 280 - (shareHead + shareTail).length;
    var sharePunch  = punchShort.length > punchBudget ? punchShort.slice(0, punchBudget - 1).replace(/\s\S+$/, "") + "…" : punchShort;
    var shareText   = shareHead + sharePunch + shareTail;

    // ── Share overlay (built dynamically so vars are in scope) ──
    var verdictDisplay = VERDICT_LABEL[verdict] || verdict || s.label;
    var verdictC = verdict ? (VERDICT_COLOR[verdict] || s.c) : s.c;
    var shareSheet = document.getElementById("bhvd-share-sheet");
    var resultEl   = document.getElementById("bhvd-result");
    shareSheet.innerHTML =
      '<div class="bhvd-share-hdr">Share this score</div>' +
      '<div class="bhvd-share-card">' +
        '<div class="bhvd-share-card-row">' +
          '<div class="bhvd-share-card-score" style="color:' + s.c + '">' + score + '<span>/100</span></div>' +
          '<div class="bhvd-share-card-right">' +
            '<div class="bhvd-share-card-name">' + brandName + '</div>' +
            '<div class="bhvd-share-card-verdict" style="color:' + verdictC + ';border-color:' + verdictC + '44;background:' + verdictC + '18">' + verdictDisplay + '</div>' +
          '</div>' +
        '</div>' +
        '<div class="bhvd-share-card-note">' + (fullPunch || "") + '</div>' +
      '</div>' +
      '<div class="bhvd-share-actions">' +
        '<button class="bhvd-share-act x-btn" id="bhvd-share-x"><span class="bhvd-share-act-icon">𝕏</span>Post to X</button>' +
        '<button class="bhvd-share-act" id="bhvd-share-copy"><span class="bhvd-share-act-icon">⎘</span>Copy link<span class="bhvd-copy-ok" id="bhvd-copy-ok"> ✓ Copied</span></button>' +
        '<button class="bhvd-share-act" id="bhvd-share-native"><span class="bhvd-share-act-icon">↗</span>More options</button>' +
      '</div>' +
      '<button class="bhvd-share-cancel" id="bhvd-share-cancel">← Back</button>';

    document.getElementById("bhvd-share-open").onclick = function() {
      resultEl.style.display = "none";
      shareSheet.classList.add("open");
      document.getElementById("bhvd-panel-inner").scrollTop = 0;
    };
    document.getElementById("bhvd-share-cancel").onclick = function() {
      shareSheet.classList.remove("open");
      resultEl.style.display = "block";
    };
    document.getElementById("bhvd-share-x").onclick = function() {
      window.open("https://x.com/intent/tweet?text=" + encodeURIComponent(shareText), "_blank");
    };
    document.getElementById("bhvd-share-copy").onclick = function() {
      navigator.clipboard.writeText(brandPage).then(function() {
        var ok = document.getElementById("bhvd-copy-ok");
        ok.style.display = "inline"; setTimeout(function() { ok.style.display = "none"; }, 2000);
      });
    };
    document.getElementById("bhvd-share-native").onclick = function() {
      if (navigator.share) {
        navigator.share({ title: brandName + " · NORM", text: scoreLabel + " — " + punchShort, url: brandPage });
      } else {
        navigator.clipboard.writeText(shareText).then(function() {
          var ok = document.getElementById("bhvd-copy-ok");
          ok.style.display = "inline"; setTimeout(function() { ok.style.display = "none"; }, 2000);
        });
      }
    };

    // ── CTAs ──
    document.getElementById("bhvd-cta-report").onclick = function() {
      logDemandEvent(domain, "extension_click");
      window.open(brandPage, "_blank");
    };
    document.getElementById("bhvd-cta-compare").style.display = "none";

    var discEl = document.querySelector(".bhvd-disc");
    if (discEl && r.disclaimer) discEl.textContent = r.disclaimer;

    document.getElementById("bhvd-scanning").style.display = "none";
    document.getElementById("bhvd-unscored").style.display = "none";
    _totalFlaggedClaims = ld.gap_map ? ld.gap_map.filter(function(g) { return g.status === "gap" || g.status === "partial"; }).length : 0;
    applyTierRestrictions(_userTier);
    document.getElementById("bhvd-result").style.display   = "block";
  }

  var _pollTimer  = null;
  var _scanned    = false;
  var _userTier   = 'free';

  function showProBadge(tier) {
    var badge = document.getElementById('bhvd-pro-badge');
    if (badge) badge.style.display = (tier === 'pro' || tier === 'brand') ? '' : 'none';
  }

  function loadUserTier(callback) {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      if (callback) callback('free'); return;
    }
    chrome.storage.local.get(['bhvd_token', 'bhvd_tier', 'bhvd_tier_ts'], function(res) {
      var tok = res.bhvd_token;
      var cached = res.bhvd_tier || 'free';
      var ts = res.bhvd_tier_ts || 0;
      _userTier = cached;
      if (callback) callback(cached);
      // Refresh tier from API if token present and cache stale (>5min)
      if (tok && Date.now() - ts > 5 * 60 * 1000) {
        fetch('https://bhvd-signal-api.fly.dev/api/stripe/subscription', {
          headers: { 'Authorization': 'Bearer ' + tok }
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
          var t = (d && d.data && d.data.tier) || 'free';
          chrome.storage.local.set({ bhvd_tier: t, bhvd_tier_ts: Date.now() });
          _userTier = t;
          applyTierRestrictions(t);
          showProBadge(t);
        })
        .catch(function(){});
      }
    });
  }
  loadUserTier(function(tier) { showProBadge(tier); });

  function applyTierRestrictions(tier) {
    var upgradeBlock = document.getElementById('bhvd-upgrade-block');
    var claimsTab = document.querySelector('.bhvd-tab-btn[data-tab="claims"]');

    if (tier === 'free') {
      // Limit claim preview to 1 item
      var cpItems = document.querySelectorAll('#bhvd-claim-preview .bhvd-cp-item');
      for (var i = 1; i < cpItems.length; i++) {
        cpItems[i].style.display = 'none';
      }
      var cpMore = document.querySelector('.bhvd-cp-more');
      if (cpMore) cpMore.style.display = 'none';
      if (upgradeBlock) {
        upgradeBlock.style.display = 'block';
        var titleEl = document.getElementById('bhvd-ug-title');
        var bodyEl  = document.getElementById('bhvd-ug-body');
        if (titleEl) {
          titleEl.textContent = 'More flagged claims locked.';
        }
        if (bodyEl) {
          bodyEl.textContent = 'Pro shows what evidence (or gap) sits behind every claim — not just that it was flagged.';
        }
      }
      if (claimsTab) { claimsTab.style.opacity = '0.35'; claimsTab.style.pointerEvents = 'none'; claimsTab.title = 'Upgrade to Pro'; }
    } else {
      if (upgradeBlock) upgradeBlock.style.display = 'none';
      if (claimsTab) { claimsTab.style.opacity = ''; claimsTab.style.pointerEvents = ''; claimsTab.title = ''; }
    }
  }

  function isWellnessPage() {
    var host = window.location.hostname.replace(/^www\./, "");
    for (var i = 0; i < KNOWN_DOMAINS.length; i++) {
      if (host === KNOWN_DOMAINS[i] || host.endsWith("." + KNOWN_DOMAINS[i])) return true;
    }
    var text = (document.title + " " + document.body.innerText.slice(0, 2000)).toLowerCase();
    var kw = ["supplement","vitamin","nootropic","adaptogen","skincare","serum","wearable",
              "sleep tracker","fitness tracker","probiotic","collagen","creatine","ashwagandha",
              "neurostimulation","brain stimulation","biohacking","longevity","biomarker",
              "recovery","gut health","hormone","cortisol","melatonin","electrolyte",
              "greens powder","protein powder","pre-workout","immune support","red light",
              "infrared","sauna","pemf","heart rate","hrv","spo2","circadian","rem sleep",
              "clinically proven","third party tested","fda cleared","supplement facts",
              // neurotech / sleep devices
              "eeg","neurofeedback","brain waves","brainwave","sleep quality","deep sleep",
              "sleep stages","cognitive performance","cognitive enhancement","neural",
              "transcranial","tDCS","neurostimul","audio stimulation","sleep score",
              // broader wellness signals
              "cognitive","mental performance","stress relief","mood support",
              "clinical study","clinical trial","peer reviewed","randomized controlled"];
    for (var j = 0; j < kw.length; j++) {
      if (text.indexOf(kw[j]) !== -1) return true;
    }
    return false;
  }

  var _HIGH = ["clinically proven","scientifically proven","proven to","guaranteed",
               "eliminates","reverses","100% effective","treats","cures","prevents disease"];
  var _MED  = ["improves","boosts","enhances","reduces","optimizes","supports","promotes",
               "strengthens","increases","helps","designed to","formulated to","shown to"];

  function _extractPageClaims(text) {
    var claims = [];
    var seen = {};
    var lines = text.split(/[\n.!?]+/);
    for (var i = 0; i < lines.length && claims.length < 25; i++) {
      var line = lines[i].trim();
      if (line.length < 12 || line.length > 350) continue;
      var key = line.slice(0, 50).toLowerCase().replace(/\s+/g, " ");
      if (seen[key]) continue;
      var ll = line.toLowerCase();
      var intensity = "low";
      for (var h = 0; h < _HIGH.length; h++) { if (ll.indexOf(_HIGH[h]) !== -1) { intensity = "high"; break; } }
      if (intensity === "low") {
        for (var m = 0; m < _MED.length; m++) { if (ll.indexOf(_MED[m]) !== -1) { intensity = "medium"; break; } }
      }
      if (intensity !== "low") { seen[key] = true; claims.push({ text: line.slice(0, 250), zone: "body", intensity: intensity }); }
    }
    return claims;
  }

  function triggerScan() {
    if (_scanned) return;
    _scanned = true;
    showScanning();
    var _currentUrl = window.location.href;
    var _scanDone = false;

    // Fallback: if no provisional result within 12s, show submit state
    var _scanTimeout = setTimeout(function() {
      if (!_scanDone) showUnscored(_currentUrl);
    }, 12000);

    var pageText = document.body ? document.body.innerText.slice(0, 6000) : "";
    var extractedClaims = _extractPageClaims(pageText);
    var studyLinks = 0;
    var links = document.querySelectorAll("a[href]");
    for (var li = 0; li < links.length; li++) {
      var href = (links[li].href || "").toLowerCase();
      if (href.indexOf("pubmed") !== -1 || href.indexOf("doi.org") !== -1 || href.indexOf("ncbi") !== -1) studyLinks++;
    }
    var extractedEvidence = studyLinks > 0 ? [{ type: "study_links", count: studyLinks }] : [];

    chrome.runtime.sendMessage({
      type: "SCAN_URL",
      payload: {
        url: _currentUrl,
        page_text: pageText,
        claims: extractedClaims,
        evidence: extractedEvidence,
        product_info: {
          productName: document.title.split("|")[0].split("-")[0].trim(),
          brandName:   "",
          pageUrl:     _currentUrl
        }
      }
    }, function(d) {
      clearTimeout(_scanTimeout);
      _scanDone = true;
      if (chrome.runtime.lastError) { showUnscored(_currentUrl); return; }
      var hasSignal = d && d.success && d.data && d.data.signal_color && !d.data.is_provisional;
      var isUnverifiable = d && d.success && d.data && d.data.leaderboard_data && d.data.leaderboard_data.scrape_status === "unverifiable";
      if (hasSignal) {
        showResult(d.data);
      } else if (isUnverifiable) {
        showUnverifiable();
      } else {
        showUnscored(_currentUrl);
      }
    });
  }

  // Track captured URLs in sessionStorage so we don't re-send same page in same session
  function _alreadyCaptured(url) {
    try {
      var key = "bhvd_captured";
      var captured = JSON.parse(sessionStorage.getItem(key) || "[]");
      var clean = url.split("?")[0].split("#")[0];
      if (captured.indexOf(clean) !== -1) return true;
      captured.push(clean);
      if (captured.length > 30) captured = captured.slice(-30);
      sessionStorage.setItem(key, JSON.stringify(captured));
      return false;
    } catch(_) { return false; }
  }

  // Always capture DOM on wellness pages — scored or not.
  // This feeds the aggregation pipeline so every page visit enriches brand data.
  function captureCurrentPage(url) {
    if (_isBlockedPath(url)) return;
    if (_alreadyCaptured(url)) return;
    var domText = document.body ? document.body.innerText : "";
    if (!domText || domText.length < 300) return;
    var safeText = _stripPii(domText.slice(0, 50000));
    chrome.runtime.sendMessage({ type: "DOM_CAPTURE", url: url, dom_text: safeText }, function() {
      if (chrome.runtime.lastError) {} // silent
    });
  }

  function poll(count) {
    if (count > 10) return;
    var _pollUrl = window.location.href;
    var _pollFallback = setTimeout(function() {
      if (!_isBlockedPath(_pollUrl)) {
        _hideAllPanelStates();
        document.getElementById("bhvd-unscored").style.display = "block";
      }
    }, 8000);
    chrome.runtime.sendMessage({ type: "LOOKUP_URL", url: _pollUrl }, function(d) {
      if (chrome.runtime.lastError) {
        // Service worker may have been sleeping — retry, but let fallback timer fire naturally
        if (count === 0) {
          // On first poll failure, still show something useful after a short delay
          _pollTimer = setTimeout(function() { poll(count + 1); }, 3000);
        } else {
          _pollTimer = setTimeout(function() { poll(count + 1); }, 5000);
        }
        return;
      }
      clearTimeout(_pollFallback);
      var currentUrl = window.location.href;
      if (d && d.status === "found" && d.data && d.data.leaderboard_data && d.data.leaderboard_data.scrape_status === "unverifiable") {
        showUnverifiable();
        // Still capture — site was unverifiable via crawler but user's browser can read it
        if (isWellnessPage()) captureCurrentPage(currentUrl);
      } else if (d && d.status === "found" && d.data && d.data.signal_color && !d.data.is_provisional) {
        showResult(d.data);
        // Capture enrichment data — scored brands benefit from more real-browser page coverage
        if (isWellnessPage()) captureCurrentPage(currentUrl);
      } else if (count === 0) {
        var snapUrl = currentUrl;
        if (!_isBlockedPath(snapUrl)) {
          var snapText    = document.body ? document.body.innerText.slice(0, 6000) : "";
          var snapClaims  = _extractPageClaims(snapText);
          var snapEvLinks = document.querySelectorAll('a[href*="pubmed"],a[href*="doi.org"],a[href*="ncbi.nlm"]').length;
          if (isWellnessPage()) {
            // Auto-open panel on wellness pages
            showNotYetAssessed(snapClaims.length, snapEvLinks, snapUrl);
            captureCurrentPage(snapUrl);
          } else {
            // Non-wellness: set state without auto-opening, so manual opens show content
            _hideAllPanelStates();
            document.getElementById("bhvd-unscored").style.display = "block";
          }
        }
      } else if (_scanned) {
        _pollTimer = setTimeout(function() { poll(count + 1); }, 5000);
      }
    });
  }

  chrome.runtime.onMessage.addListener(function(msg) {
    if (!msg) return;
    if (msg.type === "BHVD_SCANNING") {
      // Don't override a result already shown — slim poll may have resolved faster than doScan
      var resultEl = document.getElementById("bhvd-result");
      if (!resultEl || resultEl.style.display === "none" || resultEl.style.display === "") {
        showScanning();
      }
    }
    if (msg.type === "BHVD_RESULT" && msg.result && !msg.result.is_provisional) {
      clearTimeout(_pollTimer);
      showResult(msg.result);
    }
  });

  poll(0);

})();
