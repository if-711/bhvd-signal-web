// BHVD Signal — Injected Sidebar v4
// Redesigned: score front-and-center, dimension bars, evidence metrics, verdict badge

(function () {
  "use strict";
  if (document.getElementById("bhvd-signal-sidebar")) return;

  var API_URL = "https://bhvd-signal-api.fly.dev";

  function logDemandEvent(domain, eventType) {
    if (!domain) return;
    fetch(API_URL + "/api/demand/event", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ domain: domain, event_type: eventType }),
    }).catch(function() {});
  }

  var KNOWN_DOMAINS = [
    "ag1.com","ritual.com","thorne.com","onnit.com","whoop.com","ouraring.com",
    "joovv.com","therabody.com","hyperice.com","neurohacker.com","eightsleep.com",
    "momentouslabs.com","bulletproof.com","foursigmatic.com","higherdose.com",
    "mindbodygreen.com","goop.com","hims.com","hers.com","ro.co","hone.health",
    "athletic-greens.com","drinkag1.com","levelshealth.com","insidetracker.com",
    "noom.com","garmin.com","fitbit.com","oura.com",
    // neurotech
    "elemindtech.com","elemind.com","neurosity.co","muse-eeg.com","choosemuse.com",
    "emotiv.com","brainco.tech","kernel.com","flowneuro.com","narbis.com",
    "trustedsource.com","halo.sport","humm.com","myndlift.com",
    // sleep & recovery / sound wellness
    "dreem.com","kokoon.com","bose.com","sleepme.com","chilisleep.com","ooler.com",
    "sleepnumber.com","casper.com","helix.com","saatva.com",
    "soundhealth.life","sonus.com","somnox.com","kokoon.com","soundcore.com",
    "yogasleep.com","endel.io","noisli.com",
    // additional supplement/wellness
    "rawgarden.com","momentous.com","pendulum.life","seed.com","ritual.com","care/of",
    "athletic-greens.com","ag1.com","organifi.com","sunwarrior.com","vitalproteins.com"
  ];

  function isKnownWellnessDomain() {
    var host = window.location.hostname.replace(/^www\./, "");
    for (var i = 0; i < KNOWN_DOMAINS.length; i++) {
      if (host === KNOWN_DOMAINS[i] || host.endsWith("." + KNOWN_DOMAINS[i])) return true;
    }
    return false;
  }

  var BLOB = "M25.9998 0C28.1731 0 29.9538 1.72582 30.0217 3.8981C30.1312 7.40731 33.1026 10.2196 35.1071 13.102C36.0252 14.4222 36.5452 16.038 36.4956 17.7728L36.2914 24.9228C36.1757 28.9731 33.5493 32.7567 33.2607 36.7983L32.6148 45.8407C32.3669 49.3111 29.4792 52 26 52C22.5207 52 19.633 49.3112 19.3851 45.8407L18.7391 36.7982C18.4504 32.7566 15.8242 28.9731 15.7085 24.9228L15.5041 17.7728C15.4545 16.0382 15.9744 14.4226 16.8924 13.1025C18.8968 10.2198 21.8683 7.4075 21.9781 3.8981C22.046 1.72584 23.8265 3.83946e-05 25.9998 0Z";

  var SIG = {
    red:    { bg:"#120808", bd:"#5a1a1a", c:"#e74c3c", label:"Significant Evidence Gap",  verdict:"Marketing claims extend materially beyond the visible evidence base" },
    yellow: { bg:"#110e04", bd:"#5a3a0a", c:"#f39c12", label:"Moderate Evidence Gap",     verdict:"Some claims lack visible support"          },
    green:  { bg:"#060f08", bd:"#1a4a2a", c:"#27ae60", label:"Evidence Proportionate",    verdict:"Claims align with visible evidence"        },
  };

  // New verdict names — primary
  var VERDICT_COLOR = {
    "ALIGNED":"#27ae60","VALIDATED":"#2ecc71","GENERALLY ALIGNED":"#f39c12",
    "PARTIALLY ALIGNED":"#e67e22","OVEREXTENDED":"#e74c3c","EVIDENCE GAP":"#922b21",
    // Legacy backward compat for old DB records — remap to current names
    "INFLATED":"#e74c3c","HIGH CLAIM RISK":"#922b21",
    "REAL":"#27ae60","TIGHT":"#2ecc71","CREDIBLE":"#f39c12",
    "SOFT":"#e67e22","STRETCHED":"#e74c3c","HYPE":"#e74c3c","RED FLAG":"#922b21"
  };

  var VERDICT_LABEL = {
    "ALIGNED":"ALIGNED","VALIDATED":"VALIDATED","GENERALLY ALIGNED":"GENERALLY ALIGNED",
    "PARTIALLY ALIGNED":"PARTIALLY ALIGNED","OVEREXTENDED":"OVEREXTENDED","EVIDENCE GAP":"EVIDENCE GAP",
    // Legacy → display as current names
    "INFLATED":"OVEREXTENDED","HIGH CLAIM RISK":"EVIDENCE GAP",
    "REAL":"ALIGNED","TIGHT":"VALIDATED","CREDIBLE":"GENERALLY ALIGNED",
    "SOFT":"PARTIALLY ALIGNED","STRETCHED":"OVEREXTENDED","HYPE":"OVEREXTENDED","RED FLAG":"EVIDENCE GAP"
  };

  var STYLES = `
    #bhvd-signal-sidebar * { box-sizing:border-box; margin:0; padding:0; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; -webkit-font-smoothing:antialiased; }

    /* Tab — independently fixed so panel layout never affects its position */
    @keyframes bhvd-tab-in { from{opacity:0;transform:scale(0.7)} to{opacity:1;transform:scale(1)} }
    #bhvd-tab { position:fixed; right:24px; bottom:28px; z-index:2147483647; width:58px; height:58px; border-radius:50%; display:flex; align-items:center; justify-content:center; cursor:pointer; border:1px solid rgba(255,255,255,0.10); padding:0; box-shadow:0 8px 32px rgba(0,0,0,0.7); background:#07080e; transition:transform .15s ease; animation:bhvd-tab-in .4s cubic-bezier(.34,1.56,.64,1) both; }
    #bhvd-tab:hover { transform:scale(1.08); }
    #bhvd-tab-blob { flex-shrink:0; }
    #bhvd-blob-path { transition:fill .4s; fill:#1e2440; }
    #bhvd-tab-label { display:none; }

    /* Scanning pulse */
    @keyframes bhvd-pulse { 0%,100%{opacity:1} 50%{opacity:.2} }

    /* Glow animations */
    @keyframes bhvd-glow-dormant {
      0%,100% { filter: drop-shadow(0 0 3px rgba(42,48,100,0.3)); }
      50%      { filter: drop-shadow(0 0 9px rgba(58,66,130,0.7)); }
    }
    @keyframes bhvd-glow-red {
      0%,100% { filter: drop-shadow(0 0 4px rgba(231,76,60,0.35)); }
      50%      { filter: drop-shadow(0 0 16px rgba(231,76,60,1)) drop-shadow(0 0 5px rgba(231,76,60,0.6)); }
    }
    @keyframes bhvd-glow-yellow {
      0%,100% { filter: drop-shadow(0 0 4px rgba(243,156,18,0.35)); }
      50%      { filter: drop-shadow(0 0 16px rgba(243,156,18,1)) drop-shadow(0 0 5px rgba(243,156,18,0.6)); }
    }
    @keyframes bhvd-glow-green {
      0%,100% { filter: drop-shadow(0 0 4px rgba(39,174,96,0.35)); }
      50%      { filter: drop-shadow(0 0 16px rgba(39,174,96,1)) drop-shadow(0 0 5px rgba(39,174,96,0.6)); }
    }

    /* Hover card */
    #bhvd-hover-card { position:absolute; right:68px; bottom:0; background:#0d1022; border:1px solid rgba(255,255,255,0.1); border-radius:12px; padding:12px 15px; width:180px; display:none; pointer-events:none; box-shadow:-4px 4px 24px rgba(0,0,0,0.7); z-index:2147483648; }
    #bhvd-tab:hover #bhvd-hover-card { display:block; }
    .bhvd-hc-title { font-size:12px; font-weight:700; margin-bottom:4px; }
    .bhvd-hc-sub { font-size:10px; color:#7a82a0; line-height:1.45; }

    /* Panel — independently fixed, never affects tab position */
    @keyframes bhvd-panel-in { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
    #bhvd-panel { position:fixed; right:80px; bottom:100px; z-index:2147483646; width:0; overflow:hidden; transition:width .3s cubic-bezier(.22,1,.36,1); }
    #bhvd-panel.open { width:368px; animation:bhvd-panel-in .3s cubic-bezier(.22,1,.36,1) both; }
    #bhvd-panel-inner { width:368px; background:#07080e; border:1px solid rgba(255,255,255,0.08); border-radius:16px; overflow:hidden; max-height:88vh; overflow-y:auto; box-shadow:-12px 0 48px rgba(0,0,0,0.7); }
    #bhvd-panel-inner::-webkit-scrollbar { width:3px; }
    #bhvd-panel-inner::-webkit-scrollbar-thumb { background:rgba(255,255,255,0.06); border-radius:3px; }

    /* Header */
    .bhvd-hdr { padding:11px 22px; display:flex; align-items:center; justify-content:space-between; border-bottom:1px solid rgba(255,255,255,0.06); background:rgba(4,5,12,0.98); backdrop-filter:blur(12px); position:sticky; top:0; z-index:2; }
    .bhvd-hdr-logo { display:flex; align-items:center; gap:10px; font-size:9px; font-weight:800; letter-spacing:.16em; color:#6a7298; font-family:monospace; text-transform:uppercase; }
    .bhvd-close { background:none; border:none; color:#5a6288; font-size:20px; cursor:pointer; line-height:1; padding:4px 6px; border-radius:6px; transition:all .15s; }
    .bhvd-close:hover { color:#d0d8f0; background:rgba(255,255,255,0.06); }

    /* States */
    #bhvd-scanning { padding:52px 32px; text-align:center; display:none; }
    .bhvd-spin { width:30px; height:30px; border-radius:50%; border:2px solid rgba(255,255,255,0.05); border-top-color:#4a5272; animation:bhvd-spin .8s linear infinite; margin:0 auto 16px; }
    @keyframes bhvd-spin { to{transform:rotate(360deg)} }
    .bhvd-scan-txt { font-size:13px; color:#8892b0; font-weight:500; }
    .bhvd-scan-sub { font-size:11px; color:#5a6280; margin-top:6px; }
    #bhvd-unscored { padding:44px 32px; text-align:center; display:none; }
    .bhvd-us-icon { font-size:26px; margin-bottom:14px; color:#5a6280; }
    .bhvd-us-title { font-size:14px; font-weight:700; color:#d0d8f0; margin-bottom:8px; }
    .bhvd-us-body { font-size:12px; color:#8892b0; line-height:1.7; margin-bottom:18px; }
    .bhvd-snapshot-box { background:rgba(255,255,255,0.025); border:1px solid rgba(255,255,255,0.06); border-radius:10px; padding:16px 18px; margin:0 0 16px; text-align:left; }
    .bhvd-snapshot-row { display:flex; align-items:center; gap:12px; padding:4px 0; }
    .bhvd-snapshot-num { font-size:20px; font-weight:800; color:#c0c8e0; font-family:monospace; min-width:28px; }
    .bhvd-snapshot-lbl { font-size:11px; color:#7a82a0; }
    .bhvd-add-note { font-size:10px; color:#4a5272; line-height:1.65; border-top:1px solid rgba(255,255,255,0.05); padding-top:14px; margin-top:4px; }

    /* Unverifiable state */
    #bhvd-unverifiable { padding:44px 32px; text-align:center; display:none; }

    /* Low data integrity — cannot assess reliably */
    #bhvd-limited-data { padding:44px 32px; text-align:center; display:none; }
    /* Pending review — public_safe = false */
    #bhvd-pending { padding:44px 32px; text-align:center; display:none; }
    /* Legacy suppressed state */
    #bhvd-suppressed { padding:44px 32px; text-align:center; display:none; }
    .bhvd-uv-icon { font-size:24px; margin-bottom:14px; color:#4a5272; }
    .bhvd-uv-title { font-size:14px; font-weight:700; color:#d0d8f0; margin-bottom:8px; }
    .bhvd-uv-body { font-size:12px; color:#8892b0; line-height:1.7; }
    .bhvd-uv-note { font-size:10px; color:#4a5272; margin-top:16px; line-height:1.6; border-top:1px solid rgba(255,255,255,0.05); padding-top:16px; }

    /* Result — simplified reflex layout */
    #bhvd-result { display:none; }

    /* Collapsed layer */
    #bhvd-result-col { padding:22px 22px 20px; }
    .bhvd-rcol-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; }
    .bhvd-rcol-brand-row { display:flex; align-items:baseline; gap:8px; flex:1; min-width:0; overflow:hidden; }
    #bhvd-signal-word { font-size:9.5px; font-weight:900; letter-spacing:.14em; text-transform:uppercase; flex-shrink:0; }
    #bhvd-brand-name-col { font-size:18px; font-weight:800; color:#f0f2ff; letter-spacing:-.02em; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
    #bhvd-verdict-col { font-size:14px; color:#c0c8e0; line-height:1.55; margin-bottom:18px; }
    #bhvd-why-btn { background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.09); border-radius:8px; color:#8892b0; font-size:11.5px; font-weight:600; cursor:pointer; padding:9px 18px; font-family:inherit; transition:all .15s; letter-spacing:.01em; }
    #bhvd-why-btn:hover { background:rgba(255,255,255,0.08); color:#c0c8e0; border-color:rgba(255,255,255,0.18); }

    /* Expanded layer */
    #bhvd-result-exp { padding:20px 22px 0; }
    .bhvd-rexp-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; }
    #bhvd-brand-name-exp { font-size:15px; font-weight:800; color:#f0f2ff; letter-spacing:-.02em; }
    #bhvd-score-exp { font-size:13px; font-weight:700; font-family:monospace; margin-left:8px; }
    #bhvd-back-btn { background:none; border:none; color:#4a5272; font-size:11px; cursor:pointer; font-family:inherit; padding:4px 8px; border-radius:6px; transition:all .15s; flex-shrink:0; }
    #bhvd-back-btn:hover { color:#c0c8e0; background:rgba(255,255,255,0.06); }
    #bhvd-verdict-exp { font-size:13.5px; color:#a0a8c8; line-height:1.55; margin-bottom:16px; }
    #bhvd-top-finding { font-size:13px; color:#e0e8ff; font-weight:600; line-height:1.55; margin-bottom:10px; padding:12px 15px; background:rgba(255,255,255,0.03); border-radius:10px; border-left:3px solid rgba(255,255,255,0.3); }
    #bhvd-support-line { font-size:11.5px; color:#7a82a0; line-height:1.6; margin-bottom:4px; padding:0 2px; }

    /* Share icon */
    .bhvd-share-icon { background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.09); border-radius:9px; color:#4a5272; cursor:pointer; padding:8px 9px; line-height:0; display:flex; align-items:center; justify-content:center; transition:all .15s; flex-shrink:0; }
    .bhvd-share-icon:hover { background:rgba(255,255,255,0.09); color:#c0c8e0; border-color:rgba(255,255,255,0.18); }

    /* CTA */
    .bhvd-cta-sec { padding:14px 22px 16px; }
    .bhvd-cta-btn { display:block; width:100%; padding:13px; background:#0e1122; border:1px solid rgba(255,255,255,0.07); border-radius:10px; color:#b0b8d0; font-size:12px; font-weight:600; text-align:center; cursor:pointer; transition:all .15s; font-family:inherit; margin-bottom:9px; letter-spacing:.01em; }
    .bhvd-cta-btn:hover { background:#141828; border-color:rgba(255,255,255,0.14); color:#d0d8f0; }
    .bhvd-cta-btn.primary { background:#1a8fff; border-color:transparent; color:#fff; font-weight:700; letter-spacing:.02em; }
    .bhvd-cta-btn.primary:hover { background:#1480f0; }

    /* Share overlay */
    #bhvd-share-sheet { display:none; padding:26px 26px 28px; }
    @keyframes bhvd-share-up { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
    #bhvd-share-sheet.open { display:block; animation:bhvd-share-up .22s cubic-bezier(.22,1,.36,1) both; }
    .bhvd-share-hdr { font-size:9px; font-weight:800; letter-spacing:.2em; color:#4a5272; text-transform:uppercase; text-align:center; margin-bottom:16px; }
    .bhvd-share-card { background:#0b0d1a; border:1px solid rgba(255,255,255,0.07); border-radius:14px; padding:18px 18px 16px; margin-bottom:18px; }
    .bhvd-share-card-row { display:flex; align-items:flex-start; gap:14px; margin-bottom:12px; }
    .bhvd-share-card-score { font-size:34px; font-weight:900; font-family:monospace; line-height:1; letter-spacing:-.04em; flex-shrink:0; }
    .bhvd-share-card-score span { font-size:14px; opacity:.35; }
    .bhvd-share-card-right { flex:1; min-width:0; }
    .bhvd-share-card-name { font-size:15px; font-weight:800; color:#f0f2ff; letter-spacing:-.01em; line-height:1.2; }
    .bhvd-share-card-verdict { font-size:8px; font-weight:900; letter-spacing:.12em; margin-top:6px; display:inline-block; padding:3px 9px; border-radius:5px; border:1px solid; }
    .bhvd-share-act { display:flex; align-items:center; gap:13px; padding:13px 16px; border-radius:11px; border:1px solid rgba(255,255,255,0.07); background:#0b0d1a; color:#c0c8e0; font-size:12.5px; font-weight:600; cursor:pointer; font-family:inherit; transition:all .15s; text-align:left; width:100%; }
    .bhvd-share-act:hover { background:#141828; border-color:rgba(255,255,255,0.14); color:#e0e8ff; }
    .bhvd-share-act.x-btn { background:#000; border-color:#1c1c1c; }
    .bhvd-share-act.x-btn:hover { background:#0d0d0d; border-color:#333; }
    .bhvd-share-cancel { background:none; border:none; color:#8892b0; font-size:12px; cursor:pointer; width:100%; padding:12px; font-family:inherit; transition:color .15s; letter-spacing:.02em; }
    .bhvd-share-cancel:hover { color:#d0d8f0; }
  `;

  var styleEl = document.createElement("style");
  styleEl.textContent = STYLES;
  document.head.appendChild(styleEl);

  var sb = document.createElement("div");
  sb.id = "bhvd-signal-sidebar";
  sb.innerHTML =
    '<div id="bhvd-panel">' +
        '<div id="bhvd-panel-inner">' +
          '<div class="bhvd-hdr">' +
            '<div class="bhvd-hdr-logo">' +
              '<svg viewBox="0 0 52 52" width="22" height="22"><defs><linearGradient id="bhvdlg" x1="26" y1="0" x2="26" y2="52" gradientUnits="userSpaceOnUse"><stop stop-color="#00d4ff"/><stop offset="1" stop-color="#1a8fff"/></linearGradient></defs><path d="' + BLOB + '" fill="url(#bhvdlg)"/></svg>' +
              'NORM' +
            '</div>' +
            '<button class="bhvd-close" id="bhvd-close">\xd7</button>' +
          '</div>' +
          '<div id="bhvd-alpha-banner" style="padding:4px 18px;background:rgba(26,143,255,0.05);border-bottom:1px solid rgba(26,143,255,0.10);"><div style="font-size:8.5px;color:#5a7aaa;line-height:1.45;letter-spacing:.01em;">NORM scores reflect reviewed public marketing claims and visible evidence references — not product efficacy, safety, or regulatory status.</div></div>' +
          '<div id="bhvd-scanning"><div class="bhvd-spin"></div><div class="bhvd-scan-txt">Scanning page…</div><div class="bhvd-scan-sub">Analyzing claims and evidence</div></div>' +
          '<div id="bhvd-unscored"><div class="bhvd-us-icon">◎</div><div class="bhvd-us-title">Not in Public Record</div><div class="bhvd-us-body">This brand has not entered the public claim record yet.</div><div class="bhvd-snapshot-box"><div class="bhvd-snapshot-row"><span class="bhvd-snapshot-num" id="bhvd-snapshot-claims">—</span><span class="bhvd-snapshot-lbl">benefit claims detected on this page</span></div><div class="bhvd-snapshot-row"><span class="bhvd-snapshot-num" id="bhvd-snapshot-evidence">—</span><span class="bhvd-snapshot-lbl">evidence references detected</span></div></div><div class="bhvd-add-note">Claim snapshot captured for review. An alignment rating will only be shown after editorial assessment.</div></div>' +
          '<div id="bhvd-unverifiable"><div class="bhvd-uv-icon">◌</div><div class="bhvd-uv-title">Assessment limited by site access</div><div class="bhvd-uv-body">This brand limits independent reading. Results reflect visible content only — we couldn\'t fully access this site\'s pages.</div><div class="bhvd-uv-note">Ratings are based on publicly visible evidence only. A site that blocks independent reading cannot be fully assessed.</div></div>' +
          '<div id="bhvd-suppressed"><div class="bhvd-uv-icon">◑</div><div class="bhvd-uv-title">Limited visibility — rating withheld</div><div class="bhvd-uv-body">We captured too little data to assess this brand reliably. Publishing a rating with this level of visibility would not reflect adequate evidence.</div><div class="bhvd-uv-note">Try a product-specific page for better visibility coverage.</div></div>' +
          '<div id="bhvd-limited-data"><div class="bhvd-uv-icon">◌</div><div class="bhvd-uv-title">Insufficient Public Data</div><div class="bhvd-uv-body">The data captured from this brand is too sparse to support a reliable assessment. Publishing a rating with this level of coverage would not reflect adequate evidence.</div><div class="bhvd-uv-note">Try a product-specific page, or check back after we\'ve improved coverage for this brand.</div></div>' +
          '<div id="bhvd-pending"><div class="bhvd-uv-icon">◑</div><div class="bhvd-uv-title">Assessment in Progress</div><div class="bhvd-uv-body">This brand has not yet been cleared for public display. Ratings are verified before release to ensure they reflect adequate evidence coverage.</div><div class="bhvd-uv-note">This does not indicate a problem with the brand. Ratings are held until they meet our coverage threshold.</div></div>' +
          '<div id="bhvd-expired"><div class="bhvd-uv-icon">○</div><div class="bhvd-uv-title">Assessment Expired</div><div class="bhvd-uv-body">This brand\'s alignment rating has passed its validity window and is being re-evaluated. Brand claims may have changed since the last review.</div><div class="bhvd-uv-note">Check back shortly — re-evaluation in progress.</div></div>' +
          '<div id="bhvd-share-sheet"></div>' +
          '<div id="bhvd-result">' +
            '<div id="bhvd-result-col">' +
              '<div class="bhvd-rcol-header">' +
                '<div class="bhvd-rcol-brand-row">' +
                  '<span id="bhvd-signal-word"></span>' +
                  '<span id="bhvd-brand-name-col"></span>' +
                '</div>' +
                '<button class="bhvd-share-icon" id="bhvd-share-open"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="16"/></svg></button>' +
              '</div>' +
              '<div id="bhvd-verdict-col"></div>' +
              '<button id="bhvd-why-btn">Why →</button>' +
            '</div>' +
            '<div id="bhvd-result-exp" style="display:none">' +
              '<div class="bhvd-rexp-header">' +
                '<div><span id="bhvd-brand-name-exp"></span><span id="bhvd-score-exp"></span></div>' +
                '<button id="bhvd-back-btn">← Back</button>' +
              '</div>' +
              '<div id="bhvd-verdict-exp"></div>' +
              '<div id="bhvd-top-finding"></div>' +
              '<div id="bhvd-support-line" style="display:none"></div>' +
              '<div class="bhvd-cta-sec"><button class="bhvd-cta-btn primary" id="bhvd-cta-report">See full report →</button></div>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '<div id="bhvd-tab">' +
      '<div id="bhvd-hover-card"><div class="bhvd-hc-title" id="bhvd-hc-title">NORM</div><div class="bhvd-hc-sub" id="bhvd-hc-sub">Checking this page…</div></div>' +
      '<svg id="bhvd-tab-blob" viewBox="0 0 52 52" width="40" height="40"><path id="bhvd-blob-path" d="' + BLOB + '"/></svg>' +
    '</div>';

  document.body.appendChild(sb);

  var isOpen = false;
  var _provInterval = null;
  var _provPollTimer = null;

  document.getElementById("bhvd-tab").addEventListener("click", function () {
    isOpen = !isOpen;
    document.getElementById("bhvd-panel").classList.toggle("open", isOpen);
  });
  document.getElementById("bhvd-close").addEventListener("click", function () {
    isOpen = false;
    document.getElementById("bhvd-panel").classList.remove("open");
  });

  function setTab(sig, title, sub) {
    var path = document.getElementById("bhvd-blob-path");
    var blob = document.getElementById("bhvd-tab-blob");
    var tab  = document.getElementById("bhvd-tab");
    document.getElementById("bhvd-hc-title").textContent = title || "NORM";
    document.getElementById("bhvd-hc-sub").textContent   = sub   || "Checking this page…";
    if (SIG[sig]) {
      var s = SIG[sig];
      tab.style.background = s.bg; tab.style.borderColor = s.bd;
      path.style.fill = s.c;
      blob.style.filter = "";
      blob.style.animation = "bhvd-glow-" + sig + " 2.8s ease-in-out infinite";
      document.getElementById("bhvd-hc-title").style.color = s.c;
    } else if (sig === "scanning") {
      tab.style.background = "#0a0c14"; tab.style.borderColor = "rgba(255,255,255,0.08)";
      path.style.fill = "#4a5272";
      blob.style.filter = ""; blob.style.animation = "bhvd-pulse 1.2s ease infinite"; document.getElementById("bhvd-hc-title").style.color = "#8892b0";
    } else {
      tab.style.background = "#0a0c14"; tab.style.borderColor = "rgba(255,255,255,0.06)";
      path.style.fill = "#2a3050";
      blob.style.filter = ""; blob.style.animation = "bhvd-glow-dormant 3.5s ease-in-out infinite"; document.getElementById("bhvd-hc-title").style.color = "#8892b0";
    }
  }

  function showScanning() {
    setTab("scanning", "Scanning…", "Analyzing claims and evidence");
    document.getElementById("bhvd-scanning").style.display = "block";
    document.getElementById("bhvd-unscored").style.display = "none";
    document.getElementById("bhvd-result").style.display   = "none";
  }

  function showProvisional(url) {
    if (_provInterval)  { clearInterval(_provInterval);  _provInterval = null; }
    if (_provPollTimer) { clearTimeout(_provPollTimer);   _provPollTimer = null; }

    setTab("scanning", "Scoring…", "Multi-page AI analysis running");
    var scanEl  = document.getElementById("bhvd-scanning");
    var txtEl   = scanEl.querySelector(".bhvd-scan-txt");
    var subEl   = scanEl.querySelector(".bhvd-scan-sub");
    scanEl.style.display = "block";
    document.getElementById("bhvd-unscored").style.display = "none";
    document.getElementById("bhvd-result").style.display   = "none";
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }

    var secs = 60;
    var startTime = Date.now();

    function tick() {
      if (txtEl) txtEl.textContent = "Scoring in progress… " + secs + "s";
      if (subEl) subEl.textContent = "Running multi-page AI analysis";
    }
    tick();

    function doPoll() {
      chrome.runtime.sendMessage({ type: "LOOKUP_URL", url: url }, function(resp) {
        if (chrome.runtime.lastError) { scheduleNextPoll(); return; }
        if (resp && resp.status === "found" && resp.data && resp.data.signal_color && !resp.data.is_provisional) {
          if (_provInterval)  { clearInterval(_provInterval);  _provInterval = null; }
          if (_provPollTimer) { clearTimeout(_provPollTimer);   _provPollTimer = null; }
          var elapsed = Math.round((Date.now() - startTime) / 1000);
          if (txtEl && elapsed < 115) txtEl.textContent = "Scored in " + elapsed + "s!";
          setTimeout(function() { showResult(resp.data); }, elapsed < 115 ? 800 : 0);
        } else {
          scheduleNextPoll();
        }
      });
    }

    function scheduleNextPoll() {
      if (secs > 0) {
        _provPollTimer = setTimeout(doPoll, 10000);
      } else {
        // Countdown done, still scoring — keep polling every 15s, update text
        if (txtEl) txtEl.textContent = "Still scoring…";
        if (subEl) subEl.textContent = "Hang tight — results landing soon";
        _provPollTimer = setTimeout(doPoll, 15000);
      }
    }

    _provInterval = setInterval(function() {
      secs--;
      if (secs <= 0) {
        clearInterval(_provInterval); _provInterval = null;
        doPoll(); // check immediately at 0
      } else {
        tick();
        if (secs % 10 === 0) doPoll();
      }
    }, 1000);
  }

  function showUnverifiable() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-unverifiable").style.display = "block";
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
  }

  var _domCaptureSent = {};  // guard against duplicate captures per URL

  // Paths that must never be captured — checkout, auth, account, personal pages
  var _BLOCKED_PATHS = [
    "/checkout","/cart","/account","/order","/orders","/login","/signin",
    "/signup","/register","/profile","/subscription","/billing","/payment",
    "/my-","/my/","/purchases","/history","/address","/settings","/security",
    "/forgot-password","/reset-password","/2fa","/verify"
  ];

  function _isBlockedPath(url) {
    try {
      var path = new URL(url).pathname.toLowerCase();
      for (var i = 0; i < _BLOCKED_PATHS.length; i++) {
        if (path.indexOf(_BLOCKED_PATHS[i]) === 0 || path.indexOf(_BLOCKED_PATHS[i]) !== -1 && _BLOCKED_PATHS[i].indexOf("/my-") === 0) return true;
        if (path === _BLOCKED_PATHS[i] || path.startsWith(_BLOCKED_PATHS[i] + "/") || path.startsWith(_BLOCKED_PATHS[i].replace(/\/$/, "") + "/")) return true;
      }
    } catch(_) {}
    return false;
  }

  function _stripPii(text) {
    return text
      .replace(/\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b/g, "[email]")
      .replace(/\b(?:\+?1[\s\-.]?)?\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4}\b/g, "[phone]")
      .replace(/\b\d{4}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}\b/g, "[card]")
      .replace(/\b\d{3}-\d{2}-\d{4}\b/g, "[ssn]");
  }

  function tryDomCapture(url) {
    // Never capture blocked paths
    if (_isBlockedPath(url)) return;
    if (_domCaptureSent[url]) return;
    var domText = document.body ? document.body.innerText : "";
    if (!domText || domText.length < 500) return;
    _domCaptureSent[url] = true;
    var safeText = _stripPii(domText.slice(0, 50000));
    // Fire-and-forget — no UI change, no polling, no promise of a score
    chrome.runtime.sendMessage({ type: "DOM_CAPTURE", url: url, dom_text: safeText }, function() {
      if (chrome.runtime.lastError) {} // silent
    });
  }

  function showNotYetAssessed(claimCount, evidenceCount, url) {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-snapshot-claims").textContent   = claimCount  > 0 ? claimCount  : "0";
    document.getElementById("bhvd-snapshot-evidence").textContent = evidenceCount > 0 ? evidenceCount : "0";
    document.getElementById("bhvd-unscored").style.display = "block";

    var currentDomain = window.location.hostname.replace(/^www\./, "");
    var requestUrl = "https://trynorm.co/request?d=" + encodeURIComponent(currentDomain) + "&source=extension";

    var reqLink = document.getElementById("bhvd-unscored-request");
    if (!reqLink) {
      reqLink = document.createElement("a");
      reqLink.id = "bhvd-unscored-request";
      reqLink.setAttribute("target", "_blank");
      reqLink.setAttribute("rel", "noopener noreferrer");
      reqLink.setAttribute("style", "display:block;margin-top:12px;font-size:10.5px;color:#1a8fff;text-decoration:none;text-align:center;font-weight:600;letter-spacing:.01em;");
      reqLink.textContent = "Request an assessment →";
      document.getElementById("bhvd-unscored").appendChild(reqLink);
    }
    reqLink.href = requestUrl;

    logDemandEvent(currentDomain, "not_assessed_shown");
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
    if (url) tryDomCapture(url);
  }

  // Keep showUnscored as alias — called from legacy paths (unverifiable fallback etc.)
  function showUnscored(url) {
    showNotYetAssessed(0, 0, url);
  }

  function _hideAllPanelStates() {
    ["bhvd-scanning","bhvd-unscored","bhvd-unverifiable","bhvd-suppressed",
     "bhvd-limited-data","bhvd-pending","bhvd-expired","bhvd-result"]
      .forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.style.display = "none";
      });
  }

  function showSuppressed() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-suppressed").style.display = "block";
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
  }

  function showLimitedData() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-limited-data").style.display = "block";
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
  }

  function showPendingReview() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-pending").style.display = "block";
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
  }

  function showExpired() {
    setTab("dormant"); _hideAllPanelStates();
    document.getElementById("bhvd-expired").style.display = "block";
    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
  }

  function _esc(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function timeAgo(iso) {
    if (!iso) return "unknown";
    var diff = Date.now() - new Date(iso).getTime();
    var mins = Math.floor(diff / 60000);
    if (mins < 2)   return "just now";
    if (mins < 60)  return mins + "m ago";
    var hrs = Math.floor(mins / 60);
    if (hrs < 24)   return hrs + "h ago";
    return Math.floor(hrs / 24) + "d ago";
  }

  function truncateWords(text, n) {
    if (!text) return "";
    var words = text.trim().split(/\s+/);
    if (words.length <= n) {
      var t = text.trim();
      if (!/[.!?…]$/.test(t)) t += ".";
      return t;
    }
    return words.slice(0, n).join(" ") + "…";
  }

  function getVerdictSentence(sig) {
    var map = {
      green:  "Evidence is visible and consistent.",
      yellow: "Check claims against label before buying.",
      red:    "Claims exceed what is shown.",
    };
    return map[sig] || "Key information is not clearly shown.";
  }

  function getTopFinding(ld, r, sig) {
    if (ld.gap_map && ld.gap_map.length > 0) {
      var preferred = (sig === "red" || sig === "yellow")
        ? ld.gap_map.filter(function(g) { return g.status === "gap" || g.status === "partial"; })
        : ld.gap_map.filter(function(g) { return g.status === "aligned"; });
      var pool = preferred.length ? preferred : ld.gap_map;
      if (pool[0] && pool[0].claim) return truncateWords(pool[0].claim, 12);
    }
    var fullText = ld.why_this_verdict || r.consumer_summary || "";
    if (fullText) {
      var sentences = fullText.replace(/\s+/g, " ").trim().split(/\.\s+/);
      for (var i = 0; i < sentences.length; i++) {
        var sent = sentences[i].trim();
        if (sent.length > 15) return truncateWords(sent, 12);
      }
    }
    var defaults = {
      green:  "Key claims match visible evidence references.",
      yellow: "Some benefit claims lack clinical backing.",
      red:    "Marketing language exceeds the evidence shown.",
    };
    return defaults[sig] || "Evidence gaps found across reviewed claims.";
  }

  function getSupportLine(ld, r, sig) {
    if ((sig === "green" || sig === "yellow") && ld.strengths) {
      return truncateWords(ld.strengths, 10);
    }
    var fullText = ld.why_this_verdict || r.consumer_summary || "";
    if (fullText) {
      var sentences = fullText.replace(/\s+/g, " ").trim().split(/\.\s+/);
      var nonEmpty = sentences.filter(function(s) { return s.trim().length > 15; });
      if (nonEmpty.length >= 2) return truncateWords(nonEmpty[1].trim(), 10);
    }
    return null;
  }

  function showResult(r) {
    var sig = r.signal_color || "yellow";
    var s   = SIG[sig] || SIG.yellow;
    var ld  = r.leaderboard_data || {};

    var dataIntegrity = ld.data_integrity || (
      r.confidence === "high" ? "high" : r.confidence === "medium" ? "medium" : "low"
    );
    var isReviewed = ld.review_status === "reviewed" && ld.total_score != null && ld.public_safe !== false;
    if (dataIntegrity === "low" && !isReviewed) { showLimitedData(); return; }

    var validUntil = r.valid_until || ld.valid_until || null;
    if (validUntil && Date.now() > new Date(validUntil).getTime()) { showExpired(); return; }

    _hideAllPanelStates();

    var score     = ld.total_score != null ? Math.round(ld.total_score) : Math.round(100 - (r.claim_support_risk || 50));
    var brandName = r.brand_name || (r.domain || window.location.hostname).replace(/^www\./, "").split(".")[0];
    var domain    = (r.domain || window.location.hostname).replace(/^www\./, "");
    var brandPage = "https://trynorm.co/brand?d=" + encodeURIComponent(domain) + "&source=extension&t=" + Date.now();

    var verdictSentence = getVerdictSentence(sig);
    var topFinding      = getTopFinding(ld, r, sig);
    var supportLine     = getSupportLine(ld, r, sig);

    setTab(sig, brandName, verdictSentence);

    // ── Collapsed state ──
    var sigWordEl = document.getElementById("bhvd-signal-word");
    sigWordEl.textContent = sig.toUpperCase();
    sigWordEl.style.setProperty("color", s.c, "important");
    document.getElementById("bhvd-brand-name-col").textContent = brandName;
    document.getElementById("bhvd-verdict-col").textContent    = verdictSentence;

    // ── Expanded state ──
    document.getElementById("bhvd-brand-name-exp").textContent = brandName;
    var scoreExpEl = document.getElementById("bhvd-score-exp");
    scoreExpEl.textContent = score + "/100";
    scoreExpEl.style.setProperty("color", s.c, "important");
    document.getElementById("bhvd-verdict-exp").textContent = verdictSentence;

    var topFindingEl = document.getElementById("bhvd-top-finding");
    topFindingEl.textContent = topFinding;
    topFindingEl.style.setProperty("border-left-color", s.c, "important");

    var supportLineEl = document.getElementById("bhvd-support-line");
    if (supportLine) {
      supportLineEl.textContent = supportLine;
      supportLineEl.style.display = "";
    } else {
      supportLineEl.style.display = "none";
    }

    // ── Layer toggle ──
    var colEl = document.getElementById("bhvd-result-col");
    var expEl = document.getElementById("bhvd-result-exp");
    document.getElementById("bhvd-why-btn").onclick = function() {
      colEl.style.display = "none";
      expEl.style.display = "block";
    };
    document.getElementById("bhvd-back-btn").onclick = function() {
      expEl.style.display = "none";
      colEl.style.display = "block";
    };

    // ── CTA ──
    document.getElementById("bhvd-cta-report").onclick = function() {
      logDemandEvent(domain, "extension_click");
      window.open(brandPage, "_blank");
    };

    // ── Share sheet ──
    var verdict        = ld.bhvd_verdict || null;
    var verdictDisplay = verdict ? (VERDICT_LABEL[verdict] || verdict) : s.label;
    var verdictC       = verdict ? (VERDICT_COLOR[verdict] || s.c) : s.c;
    var shareSheet     = document.getElementById("bhvd-share-sheet");
    var resultEl       = document.getElementById("bhvd-result");

    function generateXShareText(bn, sc, link) {
      var hooks    = ["Before you buy " + bn + " —", "Thinking about " + bn + "?", "If you’re using " + bn + " —", "Quick check on " + bn + " —"];
      var insights = ["Most people never check what this actually means.", "This gets misunderstood a lot.", "Almost no one verifies this.", "Looks simple — it’s not."];
      var features = ["There’s an instant check for this.", "Runs automatically on product pages.", "No digging. It surfaces instantly.", "Tap. Check. Done."];
      var hook    = hooks[Math.floor(Math.random() * hooks.length)];
      var insight = insights[Math.floor(Math.random() * insights.length)];
      var feature = features[Math.floor(Math.random() * features.length)];
      return hook + "\n\nSignal: " + sc + "/100\n\nI ran this through NORM.\n\n" + insight + "\n\n" + feature + "\n\n→ " + link;
    }
    var _shareText = generateXShareText(brandName, score, brandPage);

    shareSheet.innerHTML =
      '<div class="bhvd-share-hdr">Share this signal</div>' +
      '<div class="bhvd-share-card">' +
        '<div class="bhvd-share-card-row">' +
          '<div class="bhvd-share-card-score" style="color:' + s.c + '">' + score + '<span>/100</span></div>' +
          '<div class="bhvd-share-card-right">' +
            '<div class="bhvd-share-card-name">' + _esc(brandName) + '</div>' +
            '<div class="bhvd-share-card-verdict" style="color:' + verdictC + ';border-color:' + verdictC + '44;background:' + verdictC + '18">' + _esc(verdictDisplay) + '</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<textarea id="bhvd-share-ta" style="width:100%;background:#07080e;border:1px solid rgba(255,255,255,.07);border-radius:8px;padding:10px;font-size:11px;line-height:1.7;color:#c0c8e0;white-space:pre-wrap;min-height:110px;max-height:170px;overflow-y:auto;resize:none;outline:none;font-family:inherit;box-sizing:border-box" readonly></textarea>' +
      '<div style="display:flex;gap:5px;margin-top:8px">' +
        '<button class="bhvd-share-act x-btn" id="bhvd-share-x" style="flex:1;font-size:10px;font-weight:700">Post 𝕏</button>' +
        '<button class="bhvd-share-act" id="bhvd-share-copy" style="flex:1;font-size:10px">Copy</button>' +
        '<button class="bhvd-share-act" id="bhvd-share-native" style="flex:1;font-size:10px">Share</button>' +
      '</div>' +
      '<div style="font-size:9px;color:#4a5272;text-align:center;margin-top:5px;font-family:inherit;letter-spacing:.04em">Send this to someone using it.</div>' +
      '<div id="bhvd-copy-ok" style="font-size:9px;color:#27ae60;text-align:center;min-height:13px;margin-top:3px"></div>' +
      '<button class="bhvd-share-cancel" id="bhvd-share-cancel">← Back</button>';

    document.getElementById("bhvd-share-ta").value = _shareText;

    document.getElementById("bhvd-share-open").onclick = function() {
      _shareText = generateXShareText(brandName, score, brandPage);
      document.getElementById("bhvd-share-ta").value = _shareText;
      resultEl.style.display = "none";
      shareSheet.classList.add("open");
      document.getElementById("bhvd-panel-inner").scrollTop = 0;
    };
    document.getElementById("bhvd-share-cancel").onclick = function() {
      shareSheet.classList.remove("open");
      resultEl.style.display = "block";
    };
    document.getElementById("bhvd-share-copy").onclick = function() {
      var ta = document.getElementById("bhvd-share-ta");
      var ok = document.getElementById("bhvd-copy-ok");
      navigator.clipboard.writeText(ta.value).then(function() {
        ok.textContent = "✓ Copied"; setTimeout(function() { ok.textContent = ""; }, 2000);
      });
    };
    document.getElementById("bhvd-share-x").onclick = function() {
      var ta = document.getElementById("bhvd-share-ta");
      var txt = ta.value.replace(/→ https?:\/\/\S+$/, "").trim();
      window.open("https://twitter.com/intent/tweet?text=" + encodeURIComponent(txt) + "&url=" + encodeURIComponent(brandPage), "_blank");
    };
    document.getElementById("bhvd-share-native").onclick = function() {
      var ta = document.getElementById("bhvd-share-ta");
      if (navigator.share) {
        navigator.share({ title: brandName + " — Signal: " + score + "/100", text: ta.value, url: brandPage }).catch(function() {});
      } else {
        var ok = document.getElementById("bhvd-copy-ok");
        navigator.clipboard.writeText(ta.value).then(function() {
          ok.textContent = "✓ Copied"; setTimeout(function() { ok.textContent = ""; }, 2000);
        });
      }
    };

    colEl.style.display = "block";
    expEl.style.display = "none";
    document.getElementById("bhvd-scanning").style.display = "none";
    document.getElementById("bhvd-unscored").style.display = "none";
    document.getElementById("bhvd-result").style.display   = "block";

    if (!isOpen) { isOpen = true; document.getElementById("bhvd-panel").classList.add("open"); }
  }

  var _pollTimer  = null;
  var _scanned    = false;

  function isWellnessPage() {
    var host = window.location.hostname.replace(/^www\./, "");
    for (var i = 0; i < KNOWN_DOMAINS.length; i++) {
      if (host === KNOWN_DOMAINS[i] || host.endsWith("." + KNOWN_DOMAINS[i])) return true;
    }
    var text = (document.title + " " + document.body.innerText.slice(0, 2000)).toLowerCase();
    var kw = ["supplement","vitamin","nootropic","adaptogen","skincare","serum","wearable",
              "sleep tracker","fitness tracker","probiotic","collagen","creatine","ashwagandha",
              "neurostimulation","brain stimulation","biohacking","longevity","biomarker",
              "recovery","gut health","hormone","cortisol","melatonin","electrolyte",
              "greens powder","protein powder","pre-workout","immune support","red light",
              "infrared","sauna","pemf","heart rate","hrv","spo2","circadian","rem sleep",
              "clinically proven","third party tested","fda cleared","supplement facts",
              // neurotech / sleep devices
              "eeg","neurofeedback","brain waves","brainwave","sleep quality","deep sleep",
              "sleep stages","cognitive performance","cognitive enhancement","neural",
              "transcranial","tDCS","neurostimul","audio stimulation","sleep score",
              // broader wellness signals
              "cognitive","mental performance","stress relief","mood support",
              "clinical study","clinical trial","peer reviewed","randomized controlled"];
    for (var j = 0; j < kw.length; j++) {
      if (text.indexOf(kw[j]) !== -1) return true;
    }
    return false;
  }

  var _HIGH = ["clinically proven","scientifically proven","proven to","guaranteed",
               "eliminates","reverses","100% effective","treats","cures","prevents disease"];
  var _MED  = ["improves","boosts","enhances","reduces","optimizes","supports","promotes",
               "strengthens","increases","helps","designed to","formulated to","shown to"];

  function _extractPageClaims(text) {
    var claims = [];
    var seen = {};
    var lines = text.split(/[\n.!?]+/);
    for (var i = 0; i < lines.length && claims.length < 25; i++) {
      var line = lines[i].trim();
      if (line.length < 12 || line.length > 350) continue;
      var key = line.slice(0, 50).toLowerCase().replace(/\s+/g, " ");
      if (seen[key]) continue;
      var ll = line.toLowerCase();
      var intensity = "low";
      for (var h = 0; h < _HIGH.length; h++) { if (ll.indexOf(_HIGH[h]) !== -1) { intensity = "high"; break; } }
      if (intensity === "low") {
        for (var m = 0; m < _MED.length; m++) { if (ll.indexOf(_MED[m]) !== -1) { intensity = "medium"; break; } }
      }
      if (intensity !== "low") { seen[key] = true; claims.push({ text: line.slice(0, 250), zone: "body", intensity: intensity }); }
    }
    return claims;
  }

  function triggerScan() {
    if (_scanned) return;
    _scanned = true;
    showScanning();
    var _currentUrl = window.location.href;
    var _scanDone = false;

    // Fallback: if no provisional result within 12s, show submit state
    var _scanTimeout = setTimeout(function() {
      if (!_scanDone) showUnscored(_currentUrl);
    }, 12000);

    var pageText = document.body ? document.body.innerText.slice(0, 6000) : "";
    var extractedClaims = _extractPageClaims(pageText);
    var studyLinks = 0;
    var links = document.querySelectorAll("a[href]");
    for (var li = 0; li < links.length; li++) {
      var href = (links[li].href || "").toLowerCase();
      if (href.indexOf("pubmed") !== -1 || href.indexOf("doi.org") !== -1 || href.indexOf("ncbi") !== -1) studyLinks++;
    }
    var extractedEvidence = studyLinks > 0 ? [{ type: "study_links", count: studyLinks }] : [];

    chrome.runtime.sendMessage({
      type: "SCAN_URL",
      payload: {
        url: _currentUrl,
        page_text: pageText,
        claims: extractedClaims,
        evidence: extractedEvidence,
        product_info: {
          productName: document.title.split("|")[0].split("-")[0].trim(),
          brandName:   "",
          pageUrl:     _currentUrl
        }
      }
    }, function(d) {
      clearTimeout(_scanTimeout);
      _scanDone = true;
      if (chrome.runtime.lastError) { showUnscored(_currentUrl); return; }
      var hasSignal = d && d.success && d.data && d.data.signal_color && !d.data.is_provisional;
      var isUnverifiable = d && d.success && d.data && d.data.leaderboard_data && d.data.leaderboard_data.scrape_status === "unverifiable";
      if (hasSignal) {
        showResult(d.data);
      } else if (isUnverifiable) {
        showUnverifiable();
      } else {
        showUnscored(_currentUrl);
      }
    });
  }

  // Track captured URLs in sessionStorage so we don't re-send same page in same session
  function _alreadyCaptured(url) {
    try {
      var key = "bhvd_captured";
      var captured = JSON.parse(sessionStorage.getItem(key) || "[]");
      var clean = url.split("?")[0].split("#")[0];
      if (captured.indexOf(clean) !== -1) return true;
      captured.push(clean);
      if (captured.length > 30) captured = captured.slice(-30);
      sessionStorage.setItem(key, JSON.stringify(captured));
      return false;
    } catch(_) { return false; }
  }

  // Always capture DOM on wellness pages — scored or not.
  // This feeds the aggregation pipeline so every page visit enriches brand data.
  function captureCurrentPage(url) {
    if (_isBlockedPath(url)) return;
    if (_alreadyCaptured(url)) return;
    var domText = document.body ? document.body.innerText : "";
    if (!domText || domText.length < 300) return;
    var safeText = _stripPii(domText.slice(0, 50000));
    chrome.runtime.sendMessage({ type: "DOM_CAPTURE", url: url, dom_text: safeText }, function() {
      if (chrome.runtime.lastError) {} // silent
    });
  }

  function poll(count) {
    if (count > 10) return;
    chrome.runtime.sendMessage({ type: "LOOKUP_URL", url: window.location.href }, function(d) {
      if (chrome.runtime.lastError) {
        _pollTimer = setTimeout(function() { poll(count + 1); }, 5000);
        return;
      }
      var currentUrl = window.location.href;
      if (d && d.status === "found" && d.data && d.data.leaderboard_data && d.data.leaderboard_data.scrape_status === "unverifiable") {
        showUnverifiable();
        // Still capture — site was unverifiable via crawler but user's browser can read it
        if (isWellnessPage()) captureCurrentPage(currentUrl);
      } else if (d && d.status === "found" && d.data && d.data.signal_color && !d.data.is_provisional) {
        showResult(d.data);
        // Capture enrichment data — scored brands benefit from more real-browser page coverage
        if (isWellnessPage()) captureCurrentPage(currentUrl);
      } else if (count === 0 && isWellnessPage()) {
        var snapUrl = currentUrl;
        if (!_isBlockedPath(snapUrl)) {
          var snapText    = document.body ? document.body.innerText.slice(0, 6000) : "";
          var snapClaims  = _extractPageClaims(snapText);
          var snapEvLinks = document.querySelectorAll('a[href*="pubmed"],a[href*="doi.org"],a[href*="ncbi.nlm"]').length;
          showNotYetAssessed(snapClaims.length, snapEvLinks, snapUrl);
          captureCurrentPage(snapUrl);
        }
      } else if (_scanned) {
        _pollTimer = setTimeout(function() { poll(count + 1); }, 5000);
      }
    });
  }

  chrome.runtime.onMessage.addListener(function(msg) {
    if (!msg) return;
    if (msg.type === "BHVD_SCANNING") showScanning();
    if (msg.type === "BHVD_RESULT" && msg.result && !msg.result.is_provisional) {
      clearTimeout(_pollTimer);
      showResult(msg.result);
    }
  });

  poll(0);

})();
