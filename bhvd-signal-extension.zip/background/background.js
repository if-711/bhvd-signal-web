// NORM by BHVD — Background Service Worker

var API_URL = "https://bhvd-signal-api.fly.dev";

var tabResults = {};
var tabStates = {};

// Leaderboard index: domain → entry. Refreshed once per session.
var _lbIndex = null;
var _lbIndexPromise = null;

function getLbIndex() {
  if (_lbIndex) return Promise.resolve(_lbIndex);
  if (_lbIndexPromise) return _lbIndexPromise;
  _lbIndexPromise = fetch(API_URL + "/api/leaderboard/all?limit=500&offset=0")
    .then(function(r) { return r.json(); })
    .then(function(d) {
      _lbIndex = {};
      var entries = d && d.data && Array.isArray(d.data.entries) ? d.data.entries : [];
      entries.forEach(function(e) { if (e.domain) _lbIndex[e.domain] = e; });
      return _lbIndex;
    })
    .catch(function() { _lbIndex = {}; return _lbIndex; });
  return _lbIndexPromise;
}

// Overlay leaderboard total_score onto a lookup result when the leaderboard
// has a reviewed entry for the same domain with a different (better) record.
function mergeLeaderboardScore(data) {
  if (!data || !data.domain) return data;
  var domain = data.domain.replace(/^www\./, "");
  if (!_lbIndex) return data;
  var lbEntry = _lbIndex[domain] || _lbIndex["www." + domain];
  if (!lbEntry) return data;
  var lbScore = lbEntry.leaderboard_data && lbEntry.leaderboard_data.total_score;
  var curScore = data.leaderboard_data && data.leaderboard_data.total_score;
  if (lbScore != null && lbScore !== curScore) {
    data = JSON.parse(JSON.stringify(data));
    if (!data.leaderboard_data) data.leaderboard_data = {};
    data.leaderboard_data.total_score = lbScore;
    // Also carry over reviewed fields from the leaderboard entry
    var lbLd = lbEntry.leaderboard_data || {};
    ["bhvd_verdict","review_status","public_safe","reviewed_at"].forEach(function(k) {
      if (lbLd[k] != null) data.leaderboard_data[k] = lbLd[k];
    });
    data.signal_color = lbEntry.signal_color || data.signal_color;
  }
  return data;
}

console.log("[BHVD Background] Service worker started");

function getIconPath(state) {
  var s = (state === "red" || state === "yellow" || state === "green" || state === "scanning") ? state : "dormant";
  return {
    "16":  "icons/" + s + "16.png",
    "32":  "icons/" + s + "32.png",
    "48":  "icons/" + s + "48.png",
    "128": "icons/" + s + "128.png"
  };
}

function setIcon(tabId, state) {
  tabStates[tabId] = state;
  chrome.action.setIcon({ tabId: tabId, path: getIconPath(state) }).catch(function(){});
}

function isWellness(url) {
  var wellness = ["supplement","vitamin","protein","collagen","skincare","serum",
    "moisturizer","retinol","fitness","workout","sleep","recovery","wearable",
    "tracker","probiotic","omega","magnesium","whey","nootropic","adaptogen",
    "mushroom","greens","electrolyte","infrared","sauna","massage","pemf",
    "ag1.com","ritual.com","thorne.com","onnit.com","whoop.com","ouraring.com",
    "joovv.com","therabody.com","hyperice.com","neurohacker.com","eightsleep.com",
    "momentouslabs.com","bulletproof.com","foursigmatic.com","higherdose.com"];
  var u = url.toLowerCase();
  for (var i = 0; i < wellness.length; i++) {
    if (u.indexOf(wellness[i]) !== -1) return true;
  }
  return false;
}

function doScan(tabId, msg) {
  var url = msg.url || "";
  if (!isWellness(url)) {
    console.log("[BHVD] Not wellness:", url);
    return;
  }

  console.log("[BHVD] Scanning:", url);
  setIcon(tabId, "scanning");

  // Send scanning state to sidebar
  chrome.tabs.sendMessage(tabId, { type: "BHVD_SCANNING" }).catch(function(){});

  // Clear any cached provisional result so we get the latest from API
  delete tabResults[tabId];

  // Pre-fetch leaderboard index (no-op if already cached), then lookup
  getLbIndex().then(function() {
    return fetch(API_URL + "/api/lookup?url=" + encodeURIComponent(url));
  })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d.status === "found" && d.data) {
        handleResult(tabId, mergeLeaderboardScore(d.data));
      } else {
        // Queue and do provisional scan
        fetch(API_URL + "/api/scan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            url: url,
            page_text: msg.pageText || "",
            claims: msg.claims || [],
            evidence: msg.evidence || [],
            product_info: msg.productInfo || {}
          })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
          if (d.success && d.data) {
            handleResult(tabId, d.data);
          } else {
            setIcon(tabId, "dormant");
          }
        })
        .catch(function(e) {
          console.log("[BHVD] Scan error:", e);
          setIcon(tabId, "dormant");
        });
      }
    })
    .catch(function(e) {
      console.log("[BHVD] Lookup error:", e);
      setIcon(tabId, "dormant");
    });
}

function handleResult(tabId, data) {
  tabResults[tabId] = data;
  var sig = data.signal_color || "dormant";
  setIcon(tabId, sig);
  console.log("[BHVD] Result:", sig, data.claim_support_risk);
  chrome.tabs.sendMessage(tabId, { type: "BHVD_RESULT", result: data }).catch(function(){});
}

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  console.log("[BHVD] Message received:", msg && msg.type);
  var tabId = sender.tab ? sender.tab.id : null;

  if (msg.type === "PAGE_CONTENT" && tabId) {
    doScan(tabId, msg);
    return false;
  }

  if (msg.type === "GET_RESULT") {
    sendResponse({ result: tabResults[msg.tabId], state: tabStates[msg.tabId] || "dormant" });
    return true;
  }

  if (msg.type === "GET_SIDEBAR_STATE") {
    var tid = sender.tab ? sender.tab.id : null;
    sendResponse({ result: tabResults[tid], state: tabStates[tid] || "dormant" });
    return true;
  }

  if (msg.type === "LOOKUP_URL") {
    var lookupTarget = msg.url;
    console.log("[BHVD] LOOKUP_URL for:", lookupTarget);
    getLbIndex().then(function() {
      return fetch(API_URL + "/api/lookup?url=" + encodeURIComponent(lookupTarget));
    })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        if (d.status === "found" && d.data) {
          d.data = mergeLeaderboardScore(d.data);
        }
        console.log("[BHVD] Lookup result:", d && d.status, d && d.data && d.data.signal_color);
        sendResponse(d);
        if (d.status === "found" && d.data && tabId) {
          tabResults[tabId] = d.data;
          setIcon(tabId, d.data.signal_color || "dormant");
        }
      })
      .catch(function(e) {
        console.log("[BHVD] Lookup fetch error:", e);
        sendResponse(null);
      });
    return true;
  }

  if (msg.type === "GET_LEADERBOARD") {
    fetch(API_URL + "/api/leaderboard/" + msg.category + "?limit=50")
      .then(function(r) { return r.json(); })
      .then(function(d) { sendResponse({ success: true, data: d.data }); })
      .catch(function(e) { sendResponse({ success: false, error: e.message }); });
    return true;
  }

  if (msg.type === "SCAN_URL") {
    fetch(API_URL + "/api/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(msg.payload)
    })
      .then(function(r) { return r.json(); })
      .then(function(d) { sendResponse(d); })
      .catch(function(e) { sendResponse(null); });
    return true;
  }

  if (msg.type === "QUEUE_URL") {
    fetch(API_URL + "/api/queue", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: msg.url })
    })
      .then(function(r) { return r.json(); })
      .then(function(d) { sendResponse(d); })
      .catch(function() { sendResponse(null); });
    return true;
  }

  // DOM capture — extension sends rendered page text when crawler can't access site
  if (msg.type === "DOM_CAPTURE") {
    console.log("[BHVD] DOM_CAPTURE for:", msg.url, "— chars:", msg.dom_text && msg.dom_text.length);
    fetch(API_URL + "/api/dom-capture", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: msg.url, dom_text: msg.dom_text })
    })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        sendResponse(d);
        if (d && d.data && tabId) {
          tabResults[tabId] = d.data;
          setIcon(tabId, d.data.signal_color || "scanning");
        }
      })
      .catch(function(e) {
        console.log("[BHVD] DOM capture error:", e);
        sendResponse(null);
      });
    return true;
  }
});

chrome.tabs.onRemoved.addListener(function(tabId) {
  delete tabResults[tabId];
  delete tabStates[tabId];
});

chrome.tabs.onUpdated.addListener(function(tabId, info) {
  if (info.status === "loading") {
    delete tabResults[tabId];
    setIcon(tabId, "dormant");
  }
});

console.log("[BHVD Background] Ready");
